(function () {
  "use strict";
  const {api, esc, fmt, spinBtn, registerModule, toast, t, applyPrefs} = window.P2;
  const root = document.getElementById("settings-root");

  // Declarative settings schema: [tab, key, type, label, hint, options]
  const PAGES = [
    "guide", "general", "game", "price", "overlay", "ai", "kb", "updates", "diag", "data", "accounts"];
  const PAGE_TITLE = {guide: "Путеводитель по настройкам", general: "Общие", game: "Игра и аккаунт", price: "Прайс-чек", overlay: "Оверлей и хоткеи", ai: "ИИ и API",
    kb: "База знаний", updates: "Обновления и обучение", diag: "Диагностика", data: "Данные", accounts: "Учётные записи"};
  const F = [
    ["general", "language", "select", "Язык", "Интерфейс и ответы ассистентов", [["ru", "Русский"], ["uk", "Українська"], ["en", "English"]]],
    ["general", "accent", "select", "Акцент темы", "", [["violet", "Фиолетовый"], ["purple", "Пурпурный"], ["indigo", "Индиго"], ["magenta", "Маджента"]]],
    ["general", "font_scale", "range", "Масштаб интерфейса", "%", [80, 130, 5]],
    ["general", "compact", "toggle", "Компактный режим", "меньше отступов"],
    ["general", "start_page", "select", "Стартовая страница", "", "modules"],
    ["general", "toasts", "toggle", "Уведомления", "всплывающие подсказки"],
    ["general", "notify_levelup", "toggle", "Уведомлять о новом уровне", ""],
    ["general", "notify_death", "toggle", "Уведомлять о смерти", "с подсказкой усилить защиту"],
    ["general", "notify_patch", "toggle", "Уведомлять о новом патче/лиге", "и готовом мета-отчёте"],
    ["general", "sound", "toggle", "Звук", "короткий сигнал на события"],
    ["price", "trade_status", "select", "Листинги", "", [["securable", "Только мгновенный выкуп"], ["online", "Продавец онлайн"], ["any", "Все"]]],
    ["price", "strictness", "range", "Строгость фильтров по умолчанию", "% от значений модов предмета", [60, 100, 1]],
    ["price", "max_filters", "number", "Максимум фильтров модов", ""],
    ["price", "max_listings", "number", "Сколько лотов загружать", "больше = точнее, но дольше (лимиты GGG)"],
    ["price", "ilvl_filter", "toggle", "Фильтр по item level", "±5 от предмета"],
    ["price", "auto_clipboard", "toggle", "Авто-проверка из буфера обмена", "Ctrl+C в игре сразу оценивает предмет"],
    ["price", "price_unit", "select", "Показывать цены в", "", [["ex", "Exalted"], ["div", "Divine"], ["chaos", "Chaos"]]],
    ["overlay", "hotkeys_enabled", "toggle", "Включить хоткеи в игре", ""],
    ["overlay", "hk_price", "hotkey", "Прайс-чек предмета под курсором", "по умолчанию ctrl+d"],
    ["overlay", "hk_mapcheck", "hotkey", "Проверка вейстоуна", "по умолчанию ctrl+alt+d"],
    ["overlay", "hk_toggle", "hotkey", "Показать/скрыть оверлей", "по умолчанию ctrl+shift+space"],
    ["overlay", "act_overlay", "toggle", "Гид по локации поверх игры", "маленькое окно в кампании: куда идти, кого бить, что пропустить"],
    ["overlay", "hk_act", "hotkey", "Показать/скрыть гид по локации", "по умолчанию ctrl+shift+g"],
    ["overlay", "live_on_top", "toggle", "Окно живого поиска поверх игры", "кнопка «⚡ Живой поиск» в слежке: официальный трейд GGG в режиме Live; игра — в оконном режиме без рамки"],
    ["overlay", "hk_hideout", "hotkey", "В убежище (/hideout)", "одна клавиша — команда в чат игры; по умолчанию f5, пусто — выключено"],
    ["overlay", "hk_exit", "hotkey", "К выбору персонажа (/exit)", "по умолчанию выключено: случайное нажатие закончит забег"],
    ["overlay", "chat_custom", "text", "Своя команда в чат", "например /kills или @last спасибо, удачи!"],
    ["overlay", "hk_custom", "hotkey", "Клавиша своей команды", "пусто — выключено"],
    ["overlay", "overlay_position", "select", "Где показывать", "", [["cursor", "Рядом с курсором"], ["fixed", "Там, куда перетащил"]]],
    ["overlay", "overlay_width", "number", "Ширина оверлея", "px"],
    ["overlay", "overlay_height", "number", "Высота оверлея", "px"],
    ["overlay", "overlay_autohide", "number", "Автоскрытие", "секунд, 0 — не скрывать"],
    ["ai", "answer_detail", "select", "Подробность ответов", "", [["short", "Кратко"], ["normal", "Обычно"], ["detailed", "Подробно"]]],
    ["ai", "temperature", "range", "Креативность (temperature)", "ниже — точнее, выше — разнообразнее", [0, 1, 0.05]],
    ["ai", "ollama_background", "toggle", "Фоновая работа на Ollama", "дайджесты патчей/Reddit локально — экономит облачные квоты"],
    ["ai", "cache_hours", "number", "Кэш ответов", "часов (повторные вопросы без трат квоты)"],
    ["ai", "kb_chunks", "number", "Фрагментов из базы знаний в ответ", ""],
    ["kb", "prices_refresh_min", "number", "Обновлять цены каждые", "минут"],
    ["kb", "meta_refresh_hours", "number", "Проверять патчи/новости/Reddit каждые", "часов"],
    ["kb", "reddit_enabled", "toggle", "Собирать обсуждения Reddit", ""],
    ["kb", "subreddits", "text", "Сабреддиты", "через запятую"],
    ["kb", "wiki_enabled", "toggle", "Загружать данные из poe2wiki", "уники, омены, ноды, эндгейм"],
  ];
  const ENV_PAGE = {game: ["POE_LEAGUE", "POE_ACCOUNT", "POESESSID", "POE_OAUTH_CLIENT_ID", "POE_CLIENT_LOG"], ai: null, kb: []};
  const ENV_HINT = {POE_LEAGUE: "пусто = текущая лига автоматически", POE_ACCOUNT: "ссылка pathofexile.com/account/view-profile/… или Name#1234 (профиль должен быть открыт)", POESESSID: "cookie pathofexile.com, держи в секрете",
    POE_OAUTH_CLIENT_ID: "если зарегистрировал приложение у GGG", POE_CLIENT_LOG: "путь к logs\\Client.txt", LLM_ORDER: "жёсткий порядок для всех задач (обычно пусто)",
    LLM_EXTRA: "свои API: name|https://host/v1|model|ENV_VAR|ctx; ещё…", CF_ACCOUNT_ID: "для Cloudflare Workers AI", OLLAMA_URL: "http://localhost:11434", OLLAMA_MODEL: "текстовая модель (быстрая, для фона)",
    OLLAMA_VISION_MODEL: "модель для скриншотов", OLLAMA_NUM_CTX: "контекст в токенах (8192 для 8 ГБ видеопамяти)"};

  root.innerHTML = `<div class="split" style="grid-template-columns:220px minmax(0,1fr)">
    <div class="card" style="padding:8px"><div class="nav" id="st-tabs">${PAGES.map(p => `<button data-p="${p}"><span class="lbl">${esc(t(PAGE_TITLE[p]))}</span></button>`).join("")}</div></div>
    <div id="st-page"></div></div>`;
  const $ = s => root.querySelector(s);
  let prefs = {}, defaults = {}, env = {}, modules = [], page = "guide";

  function field([, key, type, label, hint, opts]) {
    const v = prefs[key], id = `sp-${key}`;
    let ctl = "";
    if (type === "toggle") ctl = `<label class="row" style="gap:8px;cursor:pointer"><input type="checkbox" id="${id}" ${v ? "checked" : ""} style="accent-color:var(--accent);width:18px;height:18px"></label>`;
    else if (type === "select") {
      const options = opts === "modules" ? modules.map(m => [m.id, m.title]) : opts;
      ctl = `<select class="inp" id="${id}" style="width:240px">${options.map(([k, l]) => `<option value="${k}" ${String(v) === String(k) ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>`;
    } else if (type === "range") ctl = `<div class="row" style="width:260px"><input type="range" id="${id}" min="${opts[0]}" max="${opts[1]}" step="${opts[2]}" value="${v}" style="flex:1;accent-color:var(--accent)"><span class="mono small" id="${id}-v">${v}</span></div>`;
    else if (type === "number") ctl = `<input class="inp" type="number" id="${id}" value="${v}" style="width:120px">`;
    else if (type === "hotkey") ctl = `<input class="inp mono" id="${id}" value="${esc(v)}" style="width:200px" placeholder="нажми сочетание…" data-hk>`;
    else ctl = `<input class="inp" id="${id}" value="${esc(v)}" style="width:320px">`;
    return `<div class="row" style="padding:11px 0;border-bottom:1px solid var(--line)"><div style="flex:1;min-width:200px"><b style="font-weight:560">${esc(t(label))}</b>
      ${hint ? `<div class="tiny faint">${esc(hint)}</div>` : ""}</div>${ctl}${prefs[key] !== defaults[key] ? `<button class="btn sm ghost" data-reset="${key}" title="по умолчанию: ${esc(defaults[key])}">↺</button>` : ""}</div>`;
  }
  function envField(k) {
    const isKey = k.includes("KEY") || k.includes("TOKEN");
    return `<div class="row" style="padding:11px 0;border-bottom:1px solid var(--line);align-items:flex-start"><div style="flex:1;min-width:200px"><b style="font-weight:560">${esc(k)}</b>
      <div class="tiny faint">${esc(ENV_HINT[k] || (isKey ? "можно несколько ключей через запятую" : ""))}</div></div>
      <div style="display:flex;flex-direction:column;gap:6px;width:360px">${envControl(k)}
      ${isKey && k !== "POESESSID" ? `<div class="keyinfo" data-kv="${esc(k)}"></div>` : ""}</div></div>`;
  }

  // settings that have a known set of values are dropdowns, not text fields
  let ch = null;
  function envControl(k) {
    const cur = env[k] || "";
    const opts = !ch ? null : {
      POE_LEAGUE: [["", "Авто (текущая лига)"], ...ch.leagues.map(l => [l, l])],
      POE_CLIENT_LOG: [["", "Авто-поиск"], ...ch.client_logs.map(l => [l, l])],
      OLLAMA_MODEL: ch.ollama_models.map(m => [m, m]),
      OLLAMA_VISION_MODEL: ch.ollama_models.map(m => [m, m]),
    }[k];
    if (opts) {
      const list = opts.some(([v]) => v === cur) || !cur ? opts : [[cur, cur], ...opts];
      return `<select class="inp" data-env="${esc(k)}">${list.map(([v, l]) => `<option value="${esc(v)}" ${v === cur ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>`;
    }
    const ph = k === "POE_ACCOUNT" ? "вставь ссылку на профиль или Name#1234" : "";
    return `<input class="inp mono" data-env="${esc(k)}" value="${esc(cur)}" placeholder="${esc(ph)}">`;
  }

  // «срок действия + квота» next to every key: provider API where available, otherwise local counting
  async function fillKeyInfo(refresh) {
    let info;
    try { info = await api.get(`/api/settings/keyinfo${refresh ? "?refresh=true" : ""}`); } catch (_) { return; }
    root.querySelectorAll(".keyinfo").forEach(box => {
      const rows = info[box.dataset.kv] || [];
      box.innerHTML = rows.map(r => {
        const exp = r.invalid ? `<span class="tag red">ключ недействителен</span>`
          : r.days_left != null ? `<span class="tag ${r.days_left < 7 ? "red" : r.days_left < 30 ? "amber" : "green"}" title="${esc(r.expiry_source || "")}">⏳ ${r.days_left} дн. (до ${esc(r.expires)})</span>`
          : r.expires === "бессрочно" ? `<span class="tag green" title="${esc(r.expiry_source || "")}">⏳ бессрочно</span>`
          : `<span class="tag" title="провайдер не сообщает срок — укажи вручную">⏳ срок неизвестен</span>`;
        const q = r.quota || {};
        const pct = q.limit ? Math.max(0, Math.min(100, 100 * (q.remaining ?? 0) / q.limit)) : null;
        return `<div style="padding:6px 8px;border:1px solid var(--line);border-radius:8px;background:var(--sunk)">
          <div class="row" style="gap:6px"><span class="tiny mono faint">…${esc(r.tail)}</span><span class="tiny faint">${esc(r.provider)}</span>${exp}
            <button class="btn sm ghost" data-exp="${esc(r.provider)}|${esc(r.tail)}" title="указать дату окончания вручную">✎</button></div>
          <div class="tiny" style="margin-top:4px">📊 ${esc(q.text || "нет данных")}</div>
          ${pct != null ? `<div class="bar" style="margin-top:4px"><i style="width:${pct}%;${pct < 15 ? "background:var(--red)" : ""}"></i></div>` : ""}</div>`;
      }).join("") || `<div class="tiny faint">ключ не задан</div>`;
    });
    root.querySelectorAll("[data-exp]").forEach(b => b.onclick = async () => {
      const [provider, tail] = b.dataset.exp.split("|");
      const v = await window.P2.dialog({title: "Срок действия ключа", text: `${provider} …${tail}: укажи дату окончания (пусто — сбросить).`,
                                        input: {type: "date"}, ok: "Сохранить"});
      if (v === null) return;
      try { await api.post("/api/settings/keyinfo/expiry", {provider, tail, expires: v.trim()}); fillKeyInfo(true); }
      catch (e) { toast("err", "Дата", e.message); }
    });
  }

  async function render() {
    root.querySelectorAll("#st-tabs button").forEach(b => b.classList.toggle("on", b.dataset.p === page));
    const P = $("#st-page");
    const fields = F.filter(f => f[0] === page).map(field).join("");
    let extra = "";
    if (page === "game") extra = `<div class="card" style="margin-top:16px"><h3>Аккаунт и игра (.env)</h3>${ENV_PAGE.game.map(envField).join("")}
      <div class="row end" style="margin-top:12px"><button class="btn primary" id="st-env-save">${esc(t("Сохранить"))}</button></div></div>`;
    if (page === "ai") extra = await aiPage();
    if (page === "accounts") extra = await accountsPage();
    if (page === "guide") extra = await guidePage();
    if (page === "price") extra = `<div class="card" style="margin-top:16px"><h3>Опасные моды вейстоунов</h3><div class="small faint" style="margin-bottom:8px">Регулярное выражение на строку — совпадения подсвечиваются красным в проверке карты.</div>
      <textarea class="inp" id="st-danger" rows="8">${esc((await api.get("/api/price/danger")).join("\n"))}</textarea><button class="btn" id="st-danger-save" style="margin-top:8px">Сохранить список</button></div>`;
    if (page === "overlay") { const s = await api.get("/api/status"); const hk = s.hotkeys || {};
      extra = `<div class="card" style="margin-top:16px"><h3>Статус</h3>${hk.enabled ? `<span class="tag green">хоткеи активны</span>` : `<span class="tag amber">хоткеи выключены</span>`} ${hk.error ? `<span class="tag red">${esc(hk.error)}</span>` : ""}
        <div class="small muted" style="margin-top:10px">Оверлей работает в окне приложения (ярлык «POE2 Helper»). Игра должна быть в режиме <b>Windowed Fullscreen</b> — поверх эксклюзивного полноэкранного режима окна не рисуются. Хоткей сам нажимает в игре Ctrl+Alt+C (расширенное копирование с тирами модов).</div>
        <div class="row" style="margin-top:10px"><button class="btn sm" id="st-ov-show">Показать оверлей</button><button class="btn sm" id="st-ov-hide">Скрыть</button></div></div>`; }
    if (page === "updates") {
      const [u, l] = await Promise.all([api.get("/api/update/status"), api.get("/api/learn/stats")]);
      const ago = ts => ts ? new Date(ts * 1000).toLocaleString() : "ещё не было";
      extra = `<div class="card glow"><div class="row"><h3 style="margin:0">Самообновление</h3><span class="spacer"></span>
        <button class="btn sm" id="st-upd">Быстрая проверка</button><button class="btn sm primary" id="st-full">Проверить актуальность (всё)</button></div>
        <div class="small muted" style="margin:8px 0">Полное обновление всего — каждую ночь в 04:00 (или при запуске, если ночное пропущено). Быстрая проверка данных игры, дерева и PoB — каждые 6 часов и сразу при новом патче или лиге.</div>
        <div class="grid g3"><div class="stat"><b style="font-size:18px">${esc(u.tree_version || "?")}</b><span>версия дерева</span></div>
          <div class="stat"><b style="font-size:18px">${esc(u.pob.version || "нет")}</b><span>Path of Building</span></div>
          <div class="stat"><b style="font-size:14px">${ago(u.checked)}</b><span>последняя проверка</span></div></div>
        <div class="tiny faint" style="margin-top:10px">${(u.log || []).slice(-8).map(esc).join("<br>") || "журнал пуст"}</div></div>
        <div class="card" style="margin-top:16px"><div class="row"><h3 style="margin:0">Самообучение</h3><span class="spacer"></span><button class="btn sm" id="st-reflect">Сделать выводы сейчас</button></div>
        <div class="small muted" style="margin:8px 0">Тула копит твой реальный опыт: оценки ответов 👍/👎 с поправками, итоги попыток крафта, изменения билда между аудитами. Раз в 6 часов локальная модель (бесплатно) сводит это в выводы, а все ассистенты читают их как базу знаний. Сами модели не переобучаются — учится база знаний тулы.</div>
        <div class="grid g4"><div class="stat"><b>${l.feedback.total}</b><span>оценок (👍${l.feedback.up} / 👎${l.feedback.down})</span></div>
          <div class="stat"><b>${l.craft.attempts}</b><span>попыток крафта (${l.craft.hits} удачных)</span></div>
          <div class="stat"><b>${l.builds.audits}</b><span>аудитов (${fmt.n(l.builds.builds, "билд|билда|билдов")})</span></div>
          <div class="stat"><b>${l.learned_notes}</b><span>выученных заметок</span></div></div>
        ${Object.keys(l.providers).length ? `<div class="small muted" style="margin-top:10px">Оценки по моделям: ${Object.entries(l.providers).map(([p, v]) => `${esc(p)} 👍${v.up}/👎${v.down}`).join(" · ")}</div>` : ""}</div>`;
    }
    if (page === "diag") {
      const d = await api.get("/api/diag");
      extra = `<div class="card glow"><h3>Диагностика <span class="muted small">v${esc(d.version)} · Python ${esc(d.python)} · аптайм ${Math.round(d.uptime_s / 60)} мин</span></h3>
        <table class="tbl"><tbody>${d.services.map(s => `<tr><td>${esc(s.name)}</td><td>${s.ok ? `<span class="tag green">ok</span>` : `<span class="tag red">${esc(s.error || "HTTP " + s.code)}</span>`}</td><td class="num">${s.ms != null ? s.ms + " мс" : ""}</td></tr>`).join("")}
        <tr><td>Фоновые задачи</td><td colspan="2">${Object.entries(d.tasks).map(([k, v]) => `<span class="tag ${v === "running" ? "green" : "red"}">${esc(k)}</span>`).join(" ")}</td></tr>
        <tr><td>Client.txt</td><td colspan="2">${d.log_file.connected ? `<span class="tag green">подключён</span>` : `<span class="tag amber">не найден</span>`} <span class="tiny faint">${esc(d.log_file.path || "")}</span></td></tr>
        <tr><td>Лимиты трейда GGG</td><td colspan="2" class="small">${Object.entries(d.trade).map(([k, v]) => `${k}: ${v.wait ? `ждать ${v.wait} с` : "свободно"}`).join(" · ")}</td></tr>
        <tr><td>База знаний</td><td colspan="2">${fmt.n(d.kb.docs, "документ|документа|документов")}</td></tr><tr><td>Свободно на диске</td><td colspan="2">${d.disk_free_gb} ГБ</td></tr></tbody></table></div>
        <div class="card" style="margin-top:16px"><h3>Журнал (последние события)</h3><div class="mono tiny" style="max-height:360px;overflow:auto">${d.recent_log.slice().reverse().map(r => `<div style="color:${r.level === "ERROR" ? "var(--red)" : r.level === "WARNING" ? "var(--amber)" : "var(--muted)"}">${new Date(r.t * 1000).toLocaleTimeString()} ${esc(r.level)} ${esc(r.name)}: ${esc(r.msg)}</div>`).join("") || "пусто"}</div>
        <div class="tiny faint" style="margin-top:8px">Полный лог: ${esc([d.data_dir, "logs", "app.log"].join((d.data_dir || "").includes("/") ? "/" : "\\"))}</div></div>`;
    }
    if (page === "data") extra = `<div class="card"><h3>Данные</h3>
      ${[["cache", "Очистить кэш ответов ИИ", "повторные вопросы снова пойдут в API"], ["usage", "Сбросить счётчики квот", "если провайдер сам сбросил лимит раньше"],
         ["gamedata", "Перекачать игровые данные", "RePoE, дерево пассивок — после патча"], ["sessions", "Удалить все сессии ассистентов", "билды, крафты, чаты, отчёты"]]
        .map(([k, l, h]) => `<div class="row" style="padding:11px 0;border-bottom:1px solid var(--line)"><div style="flex:1"><b style="font-weight:560">${l}</b><div class="tiny faint">${h}</div></div><button class="btn sm danger" data-clear="${k}">Выполнить</button></div>`).join("")}
      <div class="row" style="padding:11px 0"><div style="flex:1"><b style="font-weight:560">Настройки</b><div class="tiny faint">экспорт/импорт JSON (без ключей)</div></div>
        <button class="btn sm" id="st-export">Экспорт</button><label class="btn sm">Импорт<input type="file" id="st-import" accept=".json" hidden></label><button class="btn sm danger" id="st-reset">${esc(t("Сбросить"))} всё</button></div></div>`;
    P.innerHTML = (fields ? `<div class="card glow"><h3>${esc(t(PAGE_TITLE[page]))}</h3>${fields}<div class="row end" style="margin-top:12px"><button class="btn primary" id="st-save">${esc(t("Сохранить"))}</button></div></div>` : "") + extra;
    wire();
  }

  // a new PC to a working tool: every outside piece, where it stands, and the button that does it
  const ST = {ok: ["green", "готово"], todo: ["red", "нужно сделать"], warn: ["amber", "можно лучше"], info: ["", "совет"]};
  async function guidePage() {
    const {steps, installing} = await api.get("/api/setup/steps");
    const done = steps.filter(s => s.status === "ok").length, need = steps.filter(s => !s.optional);
    if (installing.running) setTimeout(() => page === "guide" && render(), 3000);
    const keys = s => `<div style="margin-top:8px">${s.action.keys.map(k => `<div class="row" style="gap:8px;padding:6px 0;border-top:1px solid var(--line);flex-wrap:wrap">
        <div style="flex:1;min-width:220px"><b>${esc(k.name)}</b> ${k.set ? `<span class="tag green">есть</span>` : ""}<div class="tiny faint">${esc(k.how)} · ${esc(k.gives)}</div></div>
        <a class="btn sm" href="${esc(k.url)}" target="_blank" rel="noopener">Получить ключ ↗</a>
        <input class="inp mono" data-key="${esc(k.var)}" placeholder="вставь ключ" style="width:220px"></div>`).join("")}
        <div class="row end" style="margin-top:8px"><button class="btn primary sm" id="gd-keys">Сохранить ключи</button></div></div>`;
    const btn = s => !s.action ? "" : s.action.keys ? "" : s.action.url ? `<a class="btn sm" href="${esc(s.action.url)}" target="_blank" rel="noopener">${esc(s.action.label)} ↗</a>`
      : `<button class="btn sm primary" data-gd="${esc(s.action.post)}">${esc(s.action.label)}</button>`;
    return `<div class="card glow"><h3>Путеводитель по настройкам <span class="muted small">${done} из ${steps.length} готово</span></h3>
      <div class="small muted" style="margin-bottom:6px">Всё, что тула берёт извне, по шагам. Что можно — делается одной кнопкой; обязательных шагов ${need.length}.</div>
      ${steps.map((s, i) => `<div style="padding:12px 0;border-bottom:1px solid var(--line)"><div class="row" style="gap:10px">
        <b style="width:22px">${i + 1}.</b><div style="flex:1"><b>${esc(s.title)}</b>${s.optional ? ` <span class="tiny faint">необязательно</span>` : ""}
        <div class="small">${esc(s.detail)}</div>${s.help ? `<div class="tiny faint" style="margin-top:3px">${esc(s.help)}</div>` : ""}</div>
        <span class="tag ${ST[s.status][0]}">${ST[s.status][1]}</span>${btn(s)}</div>${s.action && s.action.keys ? keys(s) : ""}</div>`).join("")}
      <div class="row end" style="margin-top:10px"><button class="btn sm ghost" id="gd-refresh">Проверить заново</button></div></div>`;
  }
  function wireGuide() {
    root.querySelectorAll("[data-gd]").forEach(b => b.onclick = async () => {
      spinBtn(b, true);
      try { await api.post(b.dataset.gd); toast("ok", b.textContent, "готово"); } catch (e) { toast("err", b.textContent, e.message); }
      spinBtn(b, false); setTimeout(render, 1500);
    });
    root.querySelector("#gd-refresh")?.addEventListener("click", render);
    root.querySelector("#gd-keys")?.addEventListener("click", async () => {
      const values = {};
      root.querySelectorAll("[data-key]").forEach(i => { if (i.value.trim()) values[i.dataset.key] = i.value.trim(); });
      if (!Object.keys(values).length) return toast("err", "Ключи", "ничего не вписано");
      try { await api.post("/api/settings/env", {values}); toast("ok", "Ключи сохранены", "зашифрованно на этом ПК"); render(); } catch (e) { toast("err", "Ключи", e.message); }
    });
  }

  // who may open the tool: the creator's own record, the testers' logins made for their PC, revocation
  async function accountsPage() {
    const a = await api.get("/api/access/state");
    if (!a.has_key) return `<div class="card glow"><h3>Учётные записи</h3>
      <div class="small muted" style="margin-bottom:10px">Сейчас тула открыта без входа. Создай ключ создателя — после этого копии тестеров откроются только по логину и паролю, которые выдашь ты. Ключ хранится зашифрованным только на этом ПК; его открытая часть попадёт в репозиторий (закоммить и отправь «пуш в мейн»). Этот ПК остаётся открытым.</div>
      <button class="btn primary" id="acc-key">Создать ключ создателя</button></div>`;
    if (!a.creator) return `<div class="card glow"><h3>Учётная запись</h3>
      <div class="dp-kv"><span>Вход</span><b>${esc(a.login || "—")}</b></div><div class="dp-kv"><span>Доступ до</span><b>${esc(a.until || "—")}</b></div>
      <div class="dp-kv"><span>Код этого ПК</span><b class="mono">${esc(a.machine)}</b></div><div class="dp-kv"><span>Создатель</span><b>${esc(a.creator_name)}</b></div>
      <button class="btn sm" id="acc-out" style="margin-top:10px">Выйти</button></div>`;
    const d = await api.get("/api/access/accounts");
    const row = r => `<tr><td><b>${esc(r.login)}</b>${r.note ? `<div class="tiny faint">${esc(r.note)}</div>` : ""}</td><td class="mono tiny">${esc(r.machine)}</td>
      <td>${r.revoked ? `<span class="tag red">отозван</span>` : r.expired ? `<span class="tag amber">истёк ${esc(r.until)}</span>` : `<span class="tag green">до ${esc(r.until)}</span>`}</td>
      <td class="num">${r.revoked ? "" : `<button class="btn sm" data-pw="${esc(r.login)}">Пароль</button> <button class="btn sm danger" data-rv="${esc(r.login)}">Отозвать</button>`}</td></tr>`;
    return `<div class="card glow"><h3>Учётные записи</h3>
      <div class="dp-kv"><span>${esc(d.creator)}</span><b>создатель · этот ПК (${esc(d.machine)})</b></div>
      <table class="tbl" style="margin-top:10px"><thead><tr><th>Логин</th><th>Код ПК</th><th>Срок</th><th></th></tr></thead><tbody>${d.accounts.map(row).join("") || `<tr><td colspan="4" class="faint small">Тестеров пока нет</td></tr>`}</tbody></table></div>
      <div class="card" style="margin-top:16px"><h3>Добавить тестера</h3>
      <div class="small muted" style="margin-bottom:8px">Тестер запускает свою копию — на экране входа видит «код этого ПК» и присылает его тебе. Пароль подойдёт только на том ПК и до указанного дня.</div>
      <div class="row" style="flex-wrap:wrap;gap:8px;align-items:flex-end">
        <label class="fld"><span>Логин тестера</span><input class="inp" id="acc-login" placeholder="латиница, напр. vasya" style="width:180px"></label>
        <label class="fld"><span>Код его ПК</span><input class="inp mono" id="acc-machine" placeholder="ABCD-EFGH-IJKL" style="width:180px"></label>
        <label class="fld"><span>Доступ, дней</span><input class="inp" type="number" id="acc-days" value="30" min="1" max="365" style="width:100px"></label>
        <label class="fld"><span>Заметка (для себя)</span><input class="inp" id="acc-note" placeholder="кто это" style="width:200px"></label>
        <button class="btn primary" id="acc-add">Создать</button></div><div id="acc-out-box" style="margin-top:10px"></div>
      <div class="tiny faint" style="margin-top:8px">Отзыв записывается в список репозитория и доходит до копий тестеров после «пуш в мейн».</div></div>
      <div class="card" style="margin-top:16px"><h3>📦 Дайджест тестеров (Telegram)</h3>
      <div class="small muted" style="margin-bottom:8px">Копия каждого тестера раз в день около 20:00 шлёт всё, что у неё было: журнал, ошибки, Доктор,
        что нажимал, ответы ИИ. Тула раз в 5 минут забирает это в <span class="mono">data/testers/</span> и собирает один файл <span class="mono">DIGEST.md</span>.
        Нужны два бота (@BotFather → /newbot): «тестеры» только пишет в твой приватный канал, «приёмник» его читает — оба админы канала.
        Канал можно не вписывать: добавь ботов админами, отправь в канал любое сообщение — тула возьмёт id оттуда.</div>
      <div id="dg-state" class="small" style="margin-bottom:8px"></div>
      <div class="row" style="flex-wrap:wrap;gap:8px;align-items:flex-end">
        <label class="fld"><span>Токен бота «тестеры»</span><input class="inp mono" id="dg-t" placeholder="123456:ABC…" style="width:230px" autocomplete="off"></label>
        <label class="fld"><span>Токен бота «приёмник»</span><input class="inp mono" id="dg-i" placeholder="123456:XYZ…" style="width:230px" autocomplete="off"></label>
        <label class="fld"><span>Канал (можно пусто — найду сам)</span><input class="inp" id="dg-c" placeholder="пусто или -100…" style="width:200px"></label>
        <button class="btn primary" id="dg-save">Сохранить и проверить</button><button class="btn" id="dg-pull">Забрать сейчас</button></div></div>`;
  }
  function showCreds(x) {
    const text = `POE2 Helper
Логин: ${x.login}
Пароль: ${x.password}
Доступ до: ${x.until}`;
    const box = root.querySelector("#acc-out-box");
    box.innerHTML = `<div class="kb node"><span class="ki">🔑</span><div class="kt"><b class="kh">${esc(x.login)} · до ${esc(x.until)}</b>
      <div class="mono tiny" style="word-break:break-all;margin:4px 0">${esc(x.password)}</div><button class="btn sm" id="acc-copy">Скопировать логин и пароль</button></div></div>`;
    box.querySelector("#acc-copy").onclick = () => navigator.clipboard.writeText(text).then(() => toast("ok", "Скопировано", "отправь тестеру сам"));
  }
  function wireAccounts() {
    root.querySelector("#acc-key")?.addEventListener("click", async () => {
      try { const r = await api.post("/api/access/create_key"); toast("ok", "Ключ создан", r.public_file); render(); } catch (e) { toast("err", "Ключ", e.message); }
    });
    root.querySelector("#acc-out")?.addEventListener("click", async () => { await api.post("/api/access/logout"); location.reload(); });
    root.querySelector("#acc-add")?.addEventListener("click", async () => {
      try {
        const x = await api.post("/api/access/accounts", {login: root.querySelector("#acc-login").value, machine: root.querySelector("#acc-machine").value,
                                                          days: +root.querySelector("#acc-days").value || 30, note: root.querySelector("#acc-note").value});
        await render(); showCreds(x);
      } catch (e) { toast("err", "Учётная запись", e.message); }
    });
    // the testers' daily digest: both bots and the channel go into the encrypted store; the check posts and reads back
    const dgShow = async () => {
      const box = root.querySelector("#dg-state");
      if (!box) return;
      try {
        const d = await api.get("/api/access/digest");
        box.innerHTML = (d.testers_bot && d.inbox_bot && d.channel
          ? `<span class="up">● настроено</span>: канал ${esc(d.channel)}` : `<span class="muted">○ ещё не настроено — заполни три поля ниже</span>`)
          + (d.inbox && d.inbox.last ? ` · забрано ${window.P2.fmt.ago(d.inbox.last)}` : "")
          + (d.inbox && d.inbox.error ? ` · <span class="down">${esc(d.inbox.error)}</span>` : "")
          + (d.testers.length ? ` · тестеры: ${d.testers.map(esc).join(", ")}` : "")
          + (d.digest ? `<div class="tiny faint mono">${esc(d.digest)}</div>` : "");
      } catch (e) { box.textContent = e.message; }
    };
    dgShow();
    root.querySelector("#dg-save")?.addEventListener("click", async e => {
      const btn = e.currentTarget; window.P2.spinBtn(btn, true, "Проверяю…");
      try {
        const r = await api.post("/api/access/digest", {testers_token: root.querySelector("#dg-t").value, inbox_token: root.querySelector("#dg-i").value,
                                                        channel: root.querySelector("#dg-c").value});
        root.querySelector("#dg-t").value = ""; root.querySelector("#dg-i").value = "";
        r.ok ? toast("ok", "Дайджест тестеров работает", r.note) : toast("err", "Дайджест тестеров", r.error);
      } catch (err) { toast("err", "Дайджест тестеров", err.message); }
      window.P2.spinBtn(btn, false); dgShow();
    });
    root.querySelector("#dg-pull")?.addEventListener("click", async e => {
      const btn = e.currentTarget; window.P2.spinBtn(btn, true, "Забираю…");
      try { const r = await api.post("/api/access/digest/pull", {}); toast(r.error ? "err" : "ok", "Дайджест тестеров", r.error || `архивов ${r.files}, сообщений ${r.messages}`); }
      catch (err) { toast("err", "Дайджест тестеров", err.message); }
      window.P2.spinBtn(btn, false); dgShow();
    });
    root.querySelectorAll("[data-pw]").forEach(b => b.onclick = async () => showCreds(await api.post("/api/access/password", {login: b.dataset.pw})));
    root.querySelectorAll("[data-rv]").forEach(b => b.onclick = async () => {
      if (!confirm(`Отозвать доступ ${b.dataset.rv}?`)) return;
      try { await api.post("/api/access/revoke", {login: b.dataset.rv}); toast("ok", "Отозвано", "дойдёт до тестера после «пуш в мейн»"); render(); } catch (e) { toast("err", "Отзыв", e.message); }
    });
  }

  async function aiPage() {
    const [prov, prof, bud, mods] = await Promise.all([api.get("/api/settings/providers"), api.get("/api/settings/profiles"),
      api.get("/api/settings/budget"), api.get("/api/settings/models")]);
    setTimeout(() => fillKeyInfo(false), 0);
    const ROLE = {chat: "Чат и ассистенты", big: "Отчёты, аудит, планы", light: "Подсказки и оценки"};
    const roles = `<div class="card glow" style="margin-top:16px"><h3>Роли и запас квоты на сегодня</h3>
      <div class="small muted" style="margin-bottom:10px">Каждая роль — своя цепочка моделей. Внутри уровня берётся та, у которой больше всего осталось квоты, так что нагрузка распределяется равномерно. Фоновые задачи (сжатие патчей, выводы) останавливаются, когда у провайдера остаётся меньше 40% квоты, обычные задачи — меньше 15%, а чат расходует до последних 3%. Последний рубеж каждой роли — локальная Ollama, поэтому тула работает всегда, даже при нулевых облачных квотах.</div>
      <div class="grid g3">${Object.entries(bud).map(([k, v]) => `<div class="stat"><b style="font-size:22px">${v.requests_left.toLocaleString("ru")}</b><span>${ROLE[k]} — запросов в облаке</span>
        <div class="tiny faint" style="margin-top:4px">${v.providers.map(esc).join(" → ")}${v.fallback ? "" : ` <span class="down">(нет Ollama!)</span>`}</div></div>`).join("")}</div></div>`;
    const rows = prov.map(p => {
      const left = p.id === "ollama" ? "∞" : p.limit_today ? Math.max(0, p.limit_today - p.req_today) : "—";
      const pct = p.limit_today ? Math.min(100, 100 * p.req_today / p.limit_today) : 0;
      const remote = (p.remote || [])[0];
      const rem = remote ? Object.entries(remote).filter(([k]) => k.startsWith("remaining")).map(([k, v]) => `${k.replace("remaining-", "")}: ${v}`).join(", ") : "";
      const m = mods[p.id] || {};
      const options = [...new Set([p.model, ...(m.listed || [])])];
      const modelCell = p.configured && options.length > 1 && p.id !== "ollama"
        ? `<select class="inp" data-model="${esc(p.id)}" style="margin-top:4px;padding:4px 8px;font-size:12px">${options.map(o => `<option ${o === p.model ? "selected" : ""}>${esc(o)}</option>`).join("")}</select>`
        : `<div class="tiny faint">${esc(p.model)}</div>`;
      const status = !p.configured ? "" : p.disabled ? `<span class="tag red" title="${esc(p.disabled)}">✗ ${esc(p.disabled.slice(0, 48))}</span>`
        : `<span class="tag green" title="${esc(m.detail || "")}">✓ работает</span>`;
      return `<tr data-id="${p.id}"><td><b>${esc(p.id)}</b>${p.vision ? ` <span class="tag">vision</span>` : ""}${modelCell}<div class="st-res small" style="margin-top:4px">${status}</div></td>
        <td>${p.configured ? `<span class="tag green">${p.keys} ключ.</span>` : `<a class="small" href="${esc(p.signup)}" target="_blank">${["xai", "cerebras"].includes(p.id) ? "платно/карта ↗" : "получить бесплатно ↗"}</a>`}</td>
        <td style="width:180px">${p.configured ? `<div class="row small"><span class="mono">${p.req_today}/${p.id === "ollama" ? "∞" : p.limit_today}</span><span class="spacer"></span><b>${esc(t("Остаток квоты"))}: ${left}</b></div>${p.id === "ollama" ? "" : `<div class="bar" style="margin-top:4px"><i style="width:${pct}%;${pct > 85 ? "background:var(--red)" : ""}"></i></div>`}${rem ? `<div class="tiny faint" title="данные из заголовков провайдера">API: ${esc(rem)}</div>` : ""}` : ""}</td>
        <td class="num">${Math.round(p.ctx / 1000)}k</td><td class="st-res small">${p.cooling ? `<span class="tag amber">кулдаун</span>` : ""}</td></tr>`;
    }).join("");
    const envKeys = Object.keys(env).filter(k => !ENV_PAGE.game.includes(k));
    return roles + `<div class="card" style="margin-top:16px"><div class="row"><h3 style="margin:0">Провайдеры и квоты (сегодня)</h3><span class="spacer"></span><button class="btn sm" id="st-check">${esc(t("Проверить все"))}</button></div>
      <div class="small faint" style="margin:8px 0">Счётчики считаются локально по бесплатным лимитам (их можно переопределить в .env: GROQ_RPD=…), плюс реальные остатки из заголовков API, где провайдер их отдаёт. При 429 ключ уходит в кулдаун, запрос идёт к следующему.</div>
      <table class="tbl"><thead><tr><th>Провайдер, модель, статус</th><th>Ключи</th><th>Использовано / осталось</th><th style="text-align:right">Контекст</th><th></th></tr></thead><tbody>${rows}</tbody></table>
      <div class="small muted" style="margin-top:12px">${Object.entries(prof).map(([k, v]) => `<div><b>${k}</b>: ${v.map(esc).join(" → ") || "<span style='color:var(--red)'>нет провайдеров</span>"}</div>`).join("")}</div></div>
      <div class="card" style="margin-top:16px"><h3>Ключи API <span class="tag green">🔒 зашифрованы (Windows DPAPI), только на этом ПК</span></h3>
      <div class="tiny faint" style="margin-bottom:6px">Инструкция по каждому ключу — файл API_KEYS_GUIDE.md в папке тулы. Не отправляй ключи в чаты. Сервисы, которые просят карту, можно пропустить.</div>${envKeys.map(envField).join("")}
      <div class="row end" style="margin-top:12px"><button class="btn primary" id="st-env-save">${esc(t("Сохранить"))}</button></div></div>`;
  }

  function collect() {
    const out = {};
    F.forEach(([, key, type]) => {
      const el = $(`#sp-${key}`); if (!el) return;
      out[key] = type === "toggle" ? el.checked : (type === "number" || type === "range") ? +el.value : el.value.trim();
    });
    return out;
  }

  function wire() {
    wireAccounts();
    wireGuide();
    root.querySelectorAll("input[type=range]").forEach(r => r.oninput = () => { const v = root.querySelector(`#${r.id}-v`); if (v) v.textContent = r.value; });
    root.querySelectorAll("[data-hk]").forEach(inp => inp.onkeydown = e => {
      e.preventDefault();
      if (["Control", "Alt", "Shift", "Meta"].includes(e.key)) return;
      const key = e.code === "Space" ? "space" : e.key.length === 1 ? e.key.toLowerCase() : e.key.toLowerCase();
      inp.value = [e.ctrlKey && "ctrl", e.altKey && "alt", e.shiftKey && "shift", key].filter(Boolean).join("+");
    });
    root.querySelectorAll("[data-reset]").forEach(b => b.onclick = async () => { prefs = await api.post("/api/settings/prefs", {values: {[b.dataset.reset]: defaults[b.dataset.reset]}}); applyPrefs(prefs); render(); });
    const save = $("#st-save");
    if (save) save.onclick = async () => { prefs = await api.post("/api/settings/prefs", {values: collect()}); applyPrefs(prefs); toast("ok", t("Сохранено")); render(); };
    const es = $("#st-env-save");
    if (es) es.onclick = async () => { const values = {}; root.querySelectorAll("[data-env]").forEach(i => values[i.dataset.env] = i.value.trim()); await api.post("/api/settings/env", {values}); env = await api.get("/api/settings/env"); toast("ok", t("Сохранено"), "применено без перезапуска"); render(); };
    const ck = $("#st-check");
    // «Проверить все»: every provider is re-tested and gets a working free model picked automatically,
    // then roles and quotas are redrawn — so a fixed or new key starts working right away
    if (ck) ck.onclick = async () => {
      spinBtn(ck, true, "Проверяю ключи и подбираю модели…");
      try {
        const res = await api.post("/api/settings/models/select");
        const ok = Object.entries(res).filter(([, v]) => v.configured && !v.disabled).map(([k]) => k);
        const bad = Object.entries(res).filter(([, v]) => v.configured && v.disabled).map(([k]) => k);
        toast(ok.length ? "ok" : "err", `Работают: ${ok.join(", ") || "только Ollama"}`, bad.length ? `Не работают: ${bad.join(", ")} — причина в таблице` : "");
      } catch (e) { toast("err", "Проверка", e.message); }
      render();
    };
    root.querySelectorAll("[data-model]").forEach(sel => sel.onchange = async () => {
      await api.post("/api/settings/models/set", {provider: sel.dataset.model, model: sel.value});
      toast("ok", `${sel.dataset.model}: ${sel.value}`, "модель выбрана вручную");
    });
    const ds = $("#st-danger-save");
    if (ds) ds.onclick = async () => { await api.post("/api/price/danger", {patterns: $("#st-danger").value.split("\n").map(s => s.trim()).filter(Boolean)}); toast("ok", t("Сохранено")); };
    const sh = $("#st-ov-show"); if (sh) sh.onclick = () => api.post("/api/price/overlay/show");
    const hi = $("#st-ov-hide"); if (hi) hi.onclick = () => api.post("/api/price/overlay/hide");
    root.querySelectorAll("[data-clear]").forEach(b => b.onclick = async () => { if (!await window.P2.dialog({title: `${b.closest(".row").querySelector("b").textContent}?`, ok: "Выполнить", danger: true})) return; await api.post(`/api/settings/clear/${b.dataset.clear}`); toast("ok", "Готово"); });
    const ex = $("#st-export");
    if (ex) ex.onclick = () => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([JSON.stringify(prefs, null, 1)], {type: "application/json"})); a.download = "poe2helper-settings.json"; a.click(); };
    const im = $("#st-import");
    if (im) im.onchange = async () => { const txt = await im.files[0].text(); prefs = await api.post("/api/settings/prefs", {values: JSON.parse(txt)}); applyPrefs(prefs); toast("ok", "Импортировано"); render(); };
    const up = $("#st-upd");
    if (up) up.onclick = async () => { spinBtn(up, true, "Проверяю…"); try { await api.post("/api/update/check"); toast("ok", "Проверка обновлений завершена"); } catch (e) { toast("err", "Обновление", e.message); } render(); };
    const fu = $("#st-full");
    if (fu) fu.onclick = () => document.getElementById("chip-fresh").click();
    const rf = $("#st-reflect");
    if (rf) rf.onclick = async () => { spinBtn(rf, true, "Думаю…"); const r = await api.post("/api/learn/reflect"); toast("ok", r.notes ? "Выводы добавлены в базу знаний" : "Пока мало данных для выводов"); render(); };
    const rs = $("#st-reset");
    if (rs) rs.onclick = async () => { if (!await window.P2.dialog({title: "Сбросить все настройки по умолчанию?", ok: "Сбросить", danger: true})) return; prefs = await api.post("/api/settings/prefs/reset"); applyPrefs(prefs); render(); };
  }

  root.querySelectorAll("#st-tabs button").forEach(b => b.onclick = () => { page = b.dataset.p; render(); });
  registerModule({id: "settings", onShow: async () => {
    const [p, e, m] = await Promise.all([api.get("/api/settings/prefs"), api.get("/api/settings/env"), api.get("/api/modules")]);
    prefs = p.values; defaults = p.defaults; env = e; modules = m;
    try { ch = await window.P2.choices(true); } catch (_) { ch = null; }
    render();
  }});
})();
