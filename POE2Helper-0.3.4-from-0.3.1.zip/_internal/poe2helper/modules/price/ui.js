(function () {
  "use strict";
  const {api, esc, fmt, md, itemCard, spinBtn, stream, toast, registerModule, onLive} = window.P2;
  const root = document.getElementById("price-root");
  root.innerHTML = `
    <div class="row" style="margin-bottom:16px"><div class="seg" id="pr-tabs"><button class="on" data-t="check">Прайс-чек</button><button data-t="market">Биржа (poe.ninja)</button><button data-t="watch">👁 Слежка</button></div>
      <span class="spacer"></span><span class="small muted">В игре: <kbd>Ctrl D</kbd> — цена, <kbd>Ctrl Alt D</kbd> — проверка вейстоуна, <kbd>Ctrl Shift Space</kbd> — оверлей</span></div>
    <div id="pr-check">
      <div class="split-r">
        <div class="grid">
          <div class="card glow"><div class="row" style="margin-bottom:10px"><h3 style="margin:0">Предмет</h3><span class="spacer"></span>
            <label class="small muted row" style="gap:6px"><input type="checkbox" id="pr-auto" checked> авто из буфера</label></div>
            <textarea class="inp" id="pr-text" rows="9" placeholder="Наведи на предмет в игре → Ctrl+C (или Ctrl+Alt+C для тиров) — текст появится тут сам"></textarea>
            <div class="row" style="margin-top:10px"><span class="small muted">Строгость фильтров</span>
              <input type="range" id="pr-strict" min="60" max="100" value="85" style="flex:1;accent-color:#a855f7"><span class="mono small" id="pr-strict-v">85%</span>
              <button class="btn primary" id="pr-go">Оценить</button></div></div>
          <div id="pr-result"></div>
        </div>
        <div class="grid"><div id="pr-item"></div><div class="card" id="pr-ai-card" hidden><h3>✦ ИИ-оценка<span class="spacer"></span><span class="tiny faint" id="pr-ai-who"></span></h3><div class="md small" id="pr-ai"></div></div></div>
      </div>
    </div>
    <div id="pr-watch" hidden><div class="card"><div class="row"><h3 style="margin:0">Слежка за ценами</h3><span class="spacer"></span><span class="small muted" id="pr-w-info"></span></div>
      <div class="small muted" style="margin:6px 0 10px">Нажми «👁 Следить» у любой карточки предмета или результата прайс-чека — тула будет проверять трейд и сообщит, когда появится лот не дороже твоего лимита.</div>
      <div id="pr-w-list"></div></div></div>
    <div id="pr-market" hidden>
      <div class="row" style="margin-bottom:12px"><div class="seg" id="pr-types"></div></div>
      <div class="card"><table class="tbl"><thead><tr><th>Предмет</th><th style="text-align:right">Exalted</th><th style="text-align:right">Divine</th><th style="text-align:right">Объём (div)</th><th style="text-align:right">7 дней</th></tr></thead><tbody id="pr-mk"></tbody></table></div>
    </div>`;

  const $ = s => root.querySelector(s);
  let disabled = [], enabled = [], mins = {}, maxs = {}, last = null;
  $("#pr-strict").oninput = e => $("#pr-strict-v").textContent = e.target.value + "%";
  root.querySelectorAll("#pr-tabs button").forEach(b => b.onclick = () => {
    root.querySelectorAll("#pr-tabs button").forEach(x => x.classList.toggle("on", x === b));
    $("#pr-check").hidden = b.dataset.t !== "check"; $("#pr-market").hidden = b.dataset.t !== "market"; $("#pr-watch").hidden = b.dataset.t !== "watch";
    if (b.dataset.t === "market") loadMarket();
    if (b.dataset.t === "watch") loadWatch();
  });

  async function check(text) {
    if (text) $("#pr-text").value = text;
    text = $("#pr-text").value.trim();
    if (!text) return;
    const btn = $("#pr-go"); spinBtn(btn, true, "Ищу…");
    $("#pr-result").innerHTML = `<div class="card"><div class="skel"></div><div class="skel"></div><div class="skel"></div></div>`;
    try {
      if (/Item Class: Waystones|Waystone/.test(text) && /Rarity: (Magic|Rare)/.test(text)) mapcheck(text);
      const r = await api.post("/api/price/check", {text, strictness: $("#pr-strict").value / 100, disabled, enabled, mins, maxs});
      last = r; render(r, text);
    } catch (e) {
      $("#pr-result").innerHTML = `<div class="card" style="color:var(--red)">${esc(e.message)}</div>`;
      const m = /подожди (\d+)/.exec(e.message);
      if (m) countdown(+m[1]);
    }
    spinBtn(btn, false);
  }

  function render(r, text) {
    $("#pr-item").innerHTML = itemCard(r.item);
    let h = "";
    if (r.exchange) {
      const x = r.exchange;
      h = `<div class="card"><h3>Биржа</h3><div class="grid g3"><div class="stat"><b>${fmt.ex(x.exalted)}</b><span>Exalted</span></div>
        <div class="stat"><b>${fmt.div(x.divine)}</b><span>Divine</span></div><div class="stat"><b>${fmt.pct(x.change7d) || "—"}</b><span>за 7 дней</span></div></div>
        ${x.source ? `<div class="small muted" style="margin-top:8px">Источник: живая биржа trade2 (${(x.offers || []).length} предложений)</div>` : ""}</div>`;
    } else if (r.trade) {
      const t = r.trade, s = t.summary || {};
      h = `<div class="card"><div class="row"><h3 style="margin:0">Трейд</h3><span class="tag">${fmt.n(t.total, "лот|лота|лотов")}</span><span class="spacer"></span>
          <a class="btn sm" href="${t.url}" target="_blank">Открыть на сайте ↗</a>
          ${r.item.rarity !== "Unique" ? `<button class="btn sm" data-p2act="craft" data-spec="${esc(JSON.stringify({cls: r.item.item_class, base: r.item.base, mods: (r.item.mods.explicit || []).slice(0, 6)}))}">⚒ Скрафтить похожее</button>` : ""}
          <button class="btn sm ghost" data-p2act="watch" data-spec="${esc(JSON.stringify({cls: r.item.item_class, base: r.item.rarity === "Unique" ? r.item.base : "", unique: r.item.rarity === "Unique" ? r.item.name : "", mods: r.item.rarity === "Unique" ? [] : (r.item.mods.explicit || []).slice(0, 5)}))}">👁 Следить</button>
          ${!r.item.corrupted && ["Rare", "Unique"].includes(r.item.rarity) ? `<button class="btn sm" id="pr-vaal" title="Тот же поиск среди осквернённых и неосквернённых: сколько рынок даёт за Vaal">🎲 Vaal: что даёт рынок</button>` : ""}
          <button class="btn sm primary" id="pr-ai-go">✦ ИИ-оценка</button></div>
        <div id="pr-vaal-out"></div>
        ${filterRows(t.filters || [])}
        ${adviceHtml(t.advice, r)}
        <div class="grid g3" style="margin:14px 0"><div class="stat big"><b>${s.count ? fmt.ex(s.median_ex) : "—"}</b><span>${s.confidence === "low" || (t.advice && t.advice.ok === false) ? "цена похожих лотов, ex" : "реальная цена, ex"}</span></div>
          <div class="stat"><b>${s.count ? fmt.ex(s.min_ex) : "—"}</b><span>минимум, ex</span></div>
          <div class="stat"><b>${s.count ? fmt.div(s.median_div) : "—"}</b><span>в Divine</span></div></div>
        ${s.count ? `<div class="small muted" style="margin-bottom:8px">Точность: <b>${{high: "высокая", medium: "средняя", low: "низкая — мало лотов"}[s.confidence] || "?"}</b> · по одному лоту на продавца, явные «приманки» отброшены</div>` : ""}
        <table class="tbl"><thead><tr><th>Цена</th><th>Предмет</th><th>Моды</th></tr></thead><tbody>
        ${t.listings.slice(0, 15).map(l => `<tr><td class="num" style="white-space:nowrap">${l.amount} ${esc(l.currency)}${l.divine ? `<div class="tiny faint">${fmt.div(l.divine)} div</div>` : ""}</td>
          <td>${esc(l.name || "")} <span class="faint">${esc(l.base)}</span> <span class="tiny faint">i${l.ilvl}</span><div class="tiny"><span class="${l.status === "online" || l.status === "мгновенный выкуп" ? "up" : "faint"}">● ${esc(l.status)}</span> <span class="faint">${esc(l.account || "")}</span></div></td>
          <td class="tiny muted">${(l.mods_ru || l.mods).slice(0, 4).map(esc).join("<br>")}</td></tr>`).join("") || `<tr><td colspan="3" class="muted">Ничего не найдено — ослабь фильтры</td></tr>`}
        </tbody></table></div>`;
    }
    $("#pr-result").innerHTML = h;
    const again = $("#pr-refilter");
    if (again) again.onclick = () => {
      disabled = []; enabled = []; mins = {}; maxs = {};
      root.querySelectorAll(".pr-f").forEach(row => {
        const id = row.dataset.id, on = row.querySelector("[data-on]").checked, was = row.dataset.was === "1";
        if (on && !was) enabled.push(id);
        if (!on && was) disabled.push(id);
        if (row.dataset.def === "1" && on) enabled.push(id);
        const lo = row.querySelector("[data-lo]").value, hi = row.querySelector("[data-hi]").value;
        if (lo !== "") mins[id] = +lo;
        if (hi !== "") maxs[id] = +hi;
      });
      check();
    };
    const ai = $("#pr-ai-go"); if (ai) ai.onclick = () => explain(text, r);
    const vaal = $("#pr-vaal");
    if (vaal) vaal.onclick = async () => {
      spinBtn(vaal, true, "Два поиска…");
      try {
        const v = await api.post("/api/price/vaal", {text, strictness: $("#pr-strict").value / 100, disabled, enabled, mins, maxs});
        const side = (x, label) => `<div class="stat"><b>${x.count ? fmt.ex(x.median_ex) : "—"}</b><span>${label}, ex · ${fmt.n(x.total || 0, "лот|лота|лотов")}</span></div>`;
        const d = v.delta_pct;
        $("#pr-vaal-out").innerHTML = `<div class="kb ${d != null && d > 15 ? "node" : "warn"}" style="margin-top:8px"><span class="ki">🎲</span><div class="kt">
          <b class="kh">${d == null ? "Мало лотов, чтобы сравнить" : d > 0 ? `Осквернённые похожие дороже на ${d}%` : `Осквернённые похожие дешевле на ${-d}%`}</b>
          <div class="grid g3" style="margin:8px 0">${side(v.plain, "без порчи")}${side(v.corrupted, "осквернённые")}</div>
          <div class="tiny muted">${esc(v.note)}. Удачный исход стоит столько, сколько осквернённые с тем же; неудачный — предмет остаётся каким был, но больше не меняется.</div></div></div>`;
      } catch (e) { toast("err", "Vaal", e.message); }
      spinBtn(vaal, false);
    };
    root.querySelectorAll("[data-pn]").forEach(b => b.onclick = async () => { await navigator.clipboard.writeText(b.dataset.pn); toast("ok", "Скопировано", b.dataset.pn); });
    const fin = $("#pr-fin");
    if (fin) fin.onclick = async () => {
      spinBtn(fin, true, "Считаю по рынку…");
      try {
        const f = await api.post("/api/price/finish", {text});
        $("#pr-fin-out").innerHTML = `<div class="kb ${f.verdict === "craft" ? "node" : "warn"}" style="margin-top:8px"><span class="ki">💹</span><div class="kt"><b class="kh">${esc(f.text)}</b>
          ${(f.options || []).slice(0, 4).map(o => `<div class="tiny">${esc(o.action)}: цена ${fmt.ex(o.cost_ex)} ex · в среднем вернёт ${fmt.ex(o.ev_ex)} ex · <b class="${o.net_ex > 0 ? "up" : "down"}">${o.net_ex > 0 ? "+" : ""}${fmt.ex(o.net_ex)} ex</b></div>`).join("")}</div></div>`;
      } catch (e) { toast("err", "Докрафт", e.message); }
      spinBtn(fin, false);
    };
  }

  // the mods as in Sidekick: prefixes and suffixes with their tiers, each on or off, with its own numbers; the price is below
  function filterRows(fs) {
    if (!fs.length) return `<div class="faint small" style="margin:10px 0">Фильтров нет: поиск по базе и имени</div>`;
    const row = f => f.id ? `<div class="row pr-f" data-id="${esc(f.id)}" data-was="${f.on && !f.default_off ? 1 : 0}" data-def="${f.default_off ? 1 : 0}" style="gap:8px;padding:3px 0;${f.on ? "" : "opacity:.6"}">
        <input type="checkbox" data-on ${f.on ? "checked" : ""}>
        <span style="flex:1;min-width:0">${esc(f.text_ru || f.text)}${f.tier ? ` <span class="tiny faint" title="${esc(f.range || "")}">T${f.tier}${f.tiers ? `/${f.tiers}` : ""}</span>` : ""}</span>
        <input class="inp" data-lo type="number" step="any" value="${f.min ?? ""}" placeholder="от" style="width:74px"><input class="inp" data-hi type="number" step="any" value="${f.max ?? ""}" placeholder="до" style="width:74px"></div>`
      : `<div class="tiny faint" style="padding:3px 0" title="этого мода нет в базе трейда">? ${esc(f.text_ru || f.text)} — не фильтруется</div>`;
    const group = (title, list) => list.length ? `<div class="small" style="margin-top:8px"><b>${title}</b></div>${list.map(row).join("")}` : "";
    const pseudo = fs.filter(f => f.kind === "pseudo"), rest = fs.filter(f => f.kind !== "pseudo");
    return `<div style="margin:12px 0">` + group("Префиксы", rest.filter(f => f.side === "prefix")) + group("Суффиксы", rest.filter(f => f.side === "suffix"))
      + group("Сумма со всех модов", pseudo) + group("Остальное", rest.filter(f => f.side !== "prefix" && f.side !== "suffix"))
      + `<button class="btn sm primary" id="pr-refilter" style="margin-top:8px">🔎 Пересчитать цену</button></div>`;
  }
  // the listing price is computed, not written by the model: asking prices are all the trade site shows, so no sale is promised
  function adviceHtml(a, r) {
    if (!a) return "";
    const fin = r.item.rarity === "Rare" && !r.item.corrupted ? `<button class="btn sm" id="pr-fin" title="около 6 поисков на трейде">💹 Докрафтить или продать?</button><div id="pr-fin-out"></div>` : "";
    if (!a.ok) return `<div class="kb warn" style="margin:12px 0"><span class="ki">⚠</span><div class="kt"><b class="kh">Точной цены нет</b>${esc(a.why)}${fin ? `<div style="margin-top:6px">${fin}</div>` : ""}</div></div>`;
    const tag = (p, label) => `<div class="stat big"><b>${esc(p.text)}</b><span>${label}</span><button class="btn sm ghost" data-pn="${esc(p.note)}" style="margin-top:4px">📋 ${esc(p.note)}</button></div>`;
    return `<div class="card" style="margin:12px 0;border-color:var(--accent)"><div class="small"><b>Выставляй за</b></div>
      <div class="grid g2" style="margin:8px 0">${tag(a.fast, "быстрая продажа")}${a.usual ? tag(a.usual, "если готов подождать") : ""}</div>
      <div class="tiny faint">${esc(a.why)} Трейд показывает запросы, а не сделки: продажу гарантировать нельзя, но дешевле этой цены похожих нет.</div>
      ${a.sold ? `<div class="tiny" style="margin-top:4px">📈 Твои лоты этой базы: ${fmt.n(a.sold.n, "пропал|пропали|пропали")} с трейда (скорее всего проданы), обычно за ${a.sold.hours} ч при цене ${fmt.div(a.sold.div)} div</div>` : ""}${fin ? `<div style="margin-top:8px">${fin}</div>` : ""}</div>`;
  }
  function countdown(sec) {
    const btn = $("#pr-go"); btn.disabled = true;
    const tick = () => { if (sec <= 0) { btn.disabled = false; btn.textContent = "Оценить"; return; } btn.textContent = `Лимит GGG: ${sec--} с`; setTimeout(tick, 1000); };
    tick();
  }

  async function explain(text, r) {
    $("#pr-ai-card").hidden = false; const out = $("#pr-ai"); out.innerHTML = `<div class="skel"></div>`;
    let acc = "";
    await stream("/api/price/explain", {text, result: r}, {
      onProvider: p => $("#pr-ai-who").textContent = p,
      onText: t => { acc += t; out.innerHTML = md(acc); }, onReplace: t => { acc = t; out.innerHTML = md(acc); },
      onError: e => out.innerHTML += `<p style="color:var(--red)">${esc(e)}</p>`,
    });
  }

  async function mapcheck(text) {
    const r = await api.post("/api/price/mapcheck", {text});
    $("#pr-ai-card").hidden = false; $("#pr-ai-who").textContent = "проверка вейстоуна";
    // red: the player's own pattern or a mod that kills THIS build by its PoB numbers; amber: worth a look, with the reason
    const red = m => m.danger || m.level === "danger", amber = m => !red(m) && m.level === "caution";
    $("#pr-ai").innerHTML = `<div class="row" style="margin-bottom:8px">${r.safe ? `<span class="tag green">безопасно для билда</span>` : `<span class="tag red">ОПАСНЫЕ МОДЫ</span>`}${r.mods.some(amber) ? `<span class="tag amber">есть на что смотреть</span>` : ""}</div>` +
      r.mods.map(m => `<div style="padding:3px 0;color:${red(m) ? "var(--red)" : amber(m) ? "var(--amber)" : "var(--text)"}">${red(m) ? "⚠ " : amber(m) ? "△ " : ""}${esc(m.text_ru || m.text)}${m.why ? ` <span class="tiny muted">— ${esc(m.why)}</span>` : ""}</div>`).join("") +
      `<div class="tiny faint" style="margin-top:8px">${r.build ? "Красное и жёлтое — по цифрам PoB твоего билда: запас над капом, лич, реген, слой защиты, максимальный удар. " : "Билда персонажа нет — общие правила. "}Свой список опасных модов — в Настройках</div>`;
  }

  $("#pr-go").onclick = () => { disabled = []; enabled = []; check(); };
  onLive(st => {
    const c = st.clip || {};
    if (!c.text || c.action === "pob" || !$("#pr-auto").checked || c.text === $("#pr-text").value.trim()) return;
    disabled = []; enabled = [];
    if (c.action === "mapcheck") { $("#pr-text").value = c.text; mapcheck(c.text); } else check(c.text);
  });
  window.P2.priceCheck = t => { disabled = []; enabled = []; check(t); };

  async function loadWatch() {
    const d = await api.get("/api/price/watch");
    $("#pr-w-info").textContent = `${d.watches.length} из ${d.max} · проверка раз в ${d.interval_min} мин`;
    $("#pr-w-list").innerHTML = d.watches.map(w => `<div class="card" style="padding:12px;margin-bottom:10px"><div class="row"><b>${esc(w.title)}</b>
        ${w.spec.budget ? `<span class="tag">≤ ${esc(w.spec.budget)}</span>` : ""}
        ${w.live && w.live.status === "on" ? `<span class="tag green" title="новые лоты приходят от GGG за секунды">⚡ живой поиск</span>`
          : w.live && w.live.status === "нужен вход" ? `<span class="tag" title="${esc(w.live.error || "")}">живой поиск ждёт входа на pathofexile2.com</span>` : ""}<span class="spacer"></span>
        <span class="tiny faint">${w.last_check ? "проверено " + fmt.ago(w.last_check) : "ещё не проверялось"}${w.total != null ? " · лотов: " + w.total : ""}</span>
        ${w.url ? `<a class="btn sm" href="${esc(w.url)}" target="_blank">трейд ↗</a><button class="btn sm primary" data-wl="${w.id}" title="официальная страница трейда GGG в режиме Live в окне тулы: новые лоты за секунды, со звуком сайта; окно можно держать поверх игры (игра в оконном режиме без рамки)">⚡ Живой поиск</button>` : ""}<button class="btn sm" data-wc="${w.id}">Проверить</button><button class="btn sm ghost danger" data-wd="${w.id}">✕</button></div>
      ${w.error ? `<div class="small" style="color:var(--red)">${esc(w.error)}</div>` : ""}
      ${(w.hits || []).slice(0, 5).map(h => `<div class="row small" style="padding:3px 0"><span class="tag green">${esc(h.price)}</span>${esc(h.name || "")} <span class="faint">${esc(h.base || "")}</span>
        <span class="spacer"></span><span class="tiny faint">${fmt.ago(h.time)}</span>${h.whisper ? `<button class="btn sm" data-wh="${esc(h.whisper)}">✉</button>` : ""}</div>`).join("") || `<div class="tiny faint">Новых лотов пока нет</div>`}</div>`).join("")
      || `<div class="muted small">Слежек нет.</div>`;
    root.querySelectorAll("[data-wc]").forEach(b => b.onclick = async () => { spinBtn(b, true, "…"); await api.post(`/api/price/watch/${b.dataset.wc}/check`).catch(e => toast("err", "Слежка", e.message)); loadWatch(); });
    root.querySelectorAll("[data-wd]").forEach(b => b.onclick = async () => { await api.del(`/api/price/watch/${b.dataset.wd}`); loadWatch(); });
    root.querySelectorAll("[data-wl]").forEach(b => b.onclick = async () => {
      try { const r = await api.post(`/api/price/watch/${b.dataset.wl}/live`);
        toast("ok", r.reopened ? "Окно живого поиска уже открыто" : "Живой поиск открыт", "новые лоты появятся в окне сами; если не вошёл для трейда — войди в нём или в «Персонажах»"); }
      catch (e) { toast("err", "Живой поиск", e.message); }
    });
    root.querySelectorAll("#pr-w-list [data-wh]").forEach(b => b.onclick = () => { navigator.clipboard?.writeText(b.dataset.wh); toast("ok", "Сообщение продавцу скопировано"); });
  }

  async function loadMarket(type) {
    const types = await api.get("/api/price/types");
    type = type || $("#pr-types").dataset.cur || "Currency";
    $("#pr-types").dataset.cur = type;
    $("#pr-types").innerHTML = types.map(t => `<button class="${t === type ? "on" : ""}">${t}</button>`).join("");
    $("#pr-types").querySelectorAll("button").forEach(b => b.onclick = () => loadMarket(b.textContent));
    $("#pr-mk").innerHTML = `<tr><td colspan="5"><div class="skel"></div><div class="skel"></div></td></tr>`;
    try {
      const ov = await api.get(`/api/price/overview?type=${type}`);
      $("#pr-mk").innerHTML = ov.rows.map(r => `<tr><td>${r.image ? `<img src="${r.image}" loading="lazy">` : ""}${esc(r.name)}</td><td class="num">${fmt.ex(r.exalted)}</td>
        <td class="num">${fmt.div(r.divine)}</td><td class="num">${r.volume != null ? fmt.div(r.volume) : ""}</td><td class="num">${fmt.pct(r.change7d)}</td></tr>`).join("") || `<tr><td class="muted" colspan="5">Нет данных для этой категории</td></tr>`;
    } catch (e) { toast("err", "poe.ninja", e.message); }
  }
  registerModule({id: "price"});
})();
