/* POE2 Helper — shell: modules, routing, live channel, shared components (window.P2). */
(function () {
  "use strict";
  const $ = (s, r = document) => r.querySelector(s);
  const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"}[c]));

  // ───── api ─────
  const READ_TIMEOUT = 180000;
  async function req(method, url, body) {
    const press = pressStart();
    try { const data = await reqRaw(method, url, body, !!press); pressEnd(press, null); return data; }
    catch (e) { pressEnd(press, e); throw e; }
  }
  // ───── every button answers (F328): busy while the requests it started run, ✓ / ✕ after, «ещё работает» when slow ─────
  // The player: «клиент должен понимать, сработала ли кнопка, зависла или не рабочая». No handler has to remember it:
  // a click marks its button, the requests that start within PRESS_MS of it (or chained right after one of them) belong to it.
  const PRESS_MS = 400, CHAIN_MS = 200, SLOW_MS = 10000;
  let pressed = null, toastsShown = 0;
  document.addEventListener("click", e => {
    const b = e.target.closest && e.target.closest("button, .btn");
    if (b && !b.disabled) pressed = {btn: b, t: performance.now(), pending: 0, error: null, toasts: toastsShown, end: null, slow: null, last: 0};
  }, true);
  function pressStart() {
    const p = pressed, now = performance.now();
    if (!p || !p.btn.isConnected || (now - p.t > PRESS_MS && !(p.pending || (p.last && now - p.last < CHAIN_MS)))) return null;
    clearTimeout(p.end);
    if (!p.pending++ && !p.btn.classList.contains("p2-busy")) {
      p.btn.classList.remove("p2-ok", "p2-err", "p2-slow");
      // a handler that shows its own spinner (spinBtn) keeps it; the rest get ours
      if (!p.btn.querySelector(".spin")) p.btn.classList.add("p2-busy");
      p.btn.setAttribute("aria-busy", "true");
      p.slow = setTimeout(() => { if (p.pending) { p.btn.classList.add("p2-slow"); p.btn.title = "ещё работает…"; } }, SLOW_MS);
    }
    return p;
  }
  function pressEnd(p, err) {
    if (!p) return;
    if (err) p.error = err;
    p.last = performance.now();
    if (--p.pending > 0) return;
    p.end = setTimeout(() => {  // a handler chaining its next request right away keeps the button busy
      if (p.pending) return;
      clearTimeout(p.slow);
      const b = p.btn;
      b.classList.remove("p2-busy", "p2-slow");
      b.removeAttribute("aria-busy");
      if (b.title === "ещё работает…") b.title = "";
      if (!b.isConnected) return;
      b.classList.add(p.error ? "p2-err" : "p2-ok");
      setTimeout(() => b.classList.remove("p2-ok", "p2-err"), 1400);
      // an error the handler didn't show: said once, with the button's own words
      if (p.error && toastsShown === p.toasts) toast("err", (b.textContent || "Действие").trim().slice(0, 40) || "Действие", humanError(p.error));
      if (pressed === p) pressed = null;
    }, CHAIN_MS);
  }
  // what the player reads instead of a protocol's English
  function humanError(e) {
    const m = String((e && e.message) || e || "");
    if (/Not Found|Method Not Allowed|HTTP 40[45]/.test(m)) return "Это действие сервер тулы не знает — обнови тулу (похоже, старая версия)";
    if (/Failed to fetch|NetworkError|Load failed/.test(m)) return "Тула не отвечает — она запущена? Если да, обнови страницу (F5)";
    if (/HTTP 5\d\d|Internal Server Error/.test(m)) return "Внутренняя ошибка тулы — она уже записана в «Доктор» → «Ошибки за сутки»";
    return m;
  }
  async function reqRaw(method, url, body, byPlayer) {
    // a read that gets no answer says so: a lost connection left a spinner turning for ever
    const signal = method === "GET" && AbortSignal.timeout ? AbortSignal.timeout(READ_TIMEOUT) : undefined;
    // «X-P2-User»: a request the player's click started — the only kind that makes background work step aside (F333)
    const r = await fetch(method === "GET" ? url : lane(url), {method, signal, headers: {"X-P2": "1", ...(byPlayer ? {"X-P2-User": "1"} : {}), ...(body ? {"Content-Type": "application/json"} : {})}, body: body ? JSON.stringify(body) : undefined})
      .catch(e => { throw e.name === "TimeoutError" ? new Error("Тула не ответила за 3 минуты: проверь, что приложение запущено, и обнови страницу") : e; });
    let data = null;
    try { data = await r.json(); } catch (_) { /* empty body */ }
    if (r.status >= 500 && !url.startsWith("/api/errors")) reportError(`${method} ${url}`, (data && data.error) || `HTTP ${r.status}`, "");
    if (!r.ok || (data && data.error && !Array.isArray(data))) throw new Error((data && (data.error || data.detail && JSON.stringify(data.detail))) || `HTTP ${r.status}`);
    return data;
  }
  // the browser's 6 connections per address: calls that may run for minutes never take them from the tabs' quick ones
  let laneNo = 0;
  const lane = (u, no) => /^(127\.0\.0\.1|localhost)$/.test(location.hostname) ? `http://l${no ?? 1 + (laneNo++ % 3)}.localhost:${location.port}${u}` : u;
  const api = {get: u => req("GET", u), post: (u, b) => req("POST", u, b || {}), del: u => req("DELETE", u)};
  // Client.txt time «2026/10/26 09:08:12» → «09:08» today, «25.10 11:20» for older events
  function evTime(t) {
    const d = String(t || ""), day = d.slice(0, 10).replace(/\//g, "-");
    const today = new Date(Date.now() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 10);
    return day === today ? d.slice(11, 16) : `${d.slice(8, 10)}.${d.slice(5, 7)} ${d.slice(11, 16)}`;
  }
  // every page error goes to the tool's error journal («Доктор»), not only to the console nobody sees
  const reported = new Set();
  function reportError(where, message, stack) {
    const key = where + "|" + message;
    if (reported.has(key) || /ResizeObserver|Script error\.?$/.test(message || "")) return;
    reported.add(key);
    fetch("/api/errors", {method: "POST", headers: {"X-P2": "1", "Content-Type": "application/json"},
      body: JSON.stringify({where, message: String(message || "").slice(0, 400), stack: String(stack || "").slice(0, 1500)})}).catch(() => {});
  }
  window.addEventListener("error", e => reportError(location.hash || "/", e.message, e.error && e.error.stack));
  window.addEventListener("unhandledrejection", e => { const r = e.reason || {}; reportError(location.hash || "/", r.message || String(r), r.stack); });
  // item art: a unique the CDN has no picture for (Skysliver: 403) falls back to its base's art («…#fb=<url>»), else hides
  document.addEventListener("error", e => {
    const img = e.target;
    if (!img || img.tagName !== "IMG") return;
    const fb = (img.getAttribute("src") || "").match(/#fb=(.+)$/);
    if (fb) { e.stopPropagation(); img.src = decodeURIComponent(fb[1]); }  // the img's own onerror must not hide it
    else if (img.dataset.name) {  // no picture anywhere: the item's name where it stood, never an empty box («много шмота без картинок»)
      const s = document.createElement("span"); s.className = "img-miss"; s.textContent = img.dataset.name; img.replaceWith(s);
    } else if (!img.getAttribute("onerror")) img.style.visibility = "hidden";
  }, true);

  const localStorageGet = k => { try { return localStorage.getItem(k); } catch (_) { return null; } };
  const localStorageSet = (k, v) => { try { localStorage.setItem(k, v); } catch (_) {} };
  function toast(kind, title, body) {
    toastsShown++;
    if (window.P2 && window.P2.prefs && window.P2.prefs().toasts === false && kind !== "err") return;
    const t = document.createElement("div");
    t.className = `toast ${kind}`;
    t.innerHTML = `<b>${esc(title)}</b>${body ? `<span class="muted small">${esc(body)}</span>` : ""}`;
    $("#toasts").appendChild(t);
    setTimeout(() => { t.style.opacity = "0"; t.style.transition = ".3s"; setTimeout(() => t.remove(), 300); }, kind === "err" ? 7000 : 3800);
  }

  // SSE over POST (fetch streaming): {provider} / {t} / {error} / {done}
  async function stream(url, body, h) {
    const r = await fetch(lane(url), {method: "POST", headers: {"Content-Type": "application/json", "X-P2": "1", "X-P2-User": "1"}, body: JSON.stringify(body || {})});
    if (!r.ok) { h.onError && h.onError(`HTTP ${r.status}`); return; }
    const rd = r.body.getReader(), dec = new TextDecoder();
    let buf = "";
    for (;;) {
      const {value, done} = await rd.read();
      if (done) break;
      buf += dec.decode(value, {stream: true});
      let i;
      while ((i = buf.indexOf("\n\n")) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 2);
        if (!line.startsWith("data:")) continue;
        const ev = JSON.parse(line.slice(5));
        if (ev.tool) h.onTool && h.onTool(ev.tool);
        else if (ev.t) h.onText && h.onText(ev.t);
        else if (ev.replace !== undefined) h.onReplace ? h.onReplace(ev.replace) : h.onText && h.onText("");  // the check took made-up lines out
        else if (ev.provider) h.onProvider && h.onProvider(ev.provider);
        else if (ev.error) h.onError && h.onError(ev.error);
        else if (ev.done) h.onDone && h.onDone();
      }
    }
  }

  // ───── tiny markdown ─────
  // Action cards: models wrap concrete suggestions in fenced blocks (```item {...}``` etc.); the UI turns them into
  // cards with buttons — trade search with filters, craft plan with odds, show node on the tree, build this…
  const CARD_RE = /```(item|node|gem|build)\s*([\s\S]*?)```/g;
  // the check's own words about one thing: the clause of the tail that names it («+# to Spirit» не бывает на шлеме)
  function tailReason(tail, name) {
    if (!tail || !name) return "";
    const part = tail.split(/;\s|\n/).find(x => x.includes(`«${name}»`));
    return part ? part.replace(/^[-\s]*(?:Не сходится с данными игры и твоим билдом:\s*)?/, "").replace(/\*\*/g, "").trim().slice(0, 180) : "";
  }
  function cardHtml(type, raw, tail) {
    let d;
    try { d = JSON.parse(raw.trim()); } catch (_) { return ""; }
    // a mod the check refuted is marked in the card itself and left out of the trade / craft search: a search for a mod
    // that can't roll there finds nothing, and the reason stood only under the answer (HANDOFF 6)
    const refuted = type === "item" ? (d.mods || []).filter(m => typeof m === "string" && tailReason(tail, m)) : [];
    if (refuted.length) d = {...d, mods: d.mods.filter(m => !refuted.includes(m))};
    const spec = esc(JSON.stringify(d));
    if (type === "item") {
      const mods = (d.mods || []).map(m => `<div class="tiny">• ${esc(m)}</div>`).join("")
        + refuted.map(m => `<div class="tiny" style="color:var(--red)" title="убран из поиска и крафта">✖ <s>${esc(m)}</s> — ${esc(tailReason(tail, m).replace(`«${m}»`, "").replace(/^\s*[—-]\s*/, "").trim() || "не подтверждено проверкой")}</div>`).join("");
      return `<div class="act-card"><div class="row"><b>🛡 ${esc(d.slot || d.cls || "Предмет")}${d.unique ? ": " + esc(d.unique) : d.base ? ": " + esc(d.base) : ""}</b>
        ${d.budget ? `<span class="tag">${esc(d.budget)}</span>` : ""}</div>${d.why ? `<div class="small muted">${esc(d.why)}</div>` : ""}${mods}
        <div class="row" style="margin-top:6px"><button class="btn sm primary" data-p2act="trade" data-spec="${spec}">🔎 Трейд с фильтрами</button>
        ${d.unique ? "" : `<button class="btn sm" data-p2act="craft" data-spec="${spec}">⚒ Скрафтить: шансы и шаги</button>`}
        ${d.slot ? `<button class="btn sm" data-p2act="upgrade" data-spec="${spec}">📈 Подобрать по PoB</button>` : ""}
        <button class="btn sm ghost" data-p2act="watch" data-spec="${spec}">👁 Следить</button></div></div>`;
    }
    if (type === "node") return `<div class="act-card"><b>🌳 ${esc(d.name)}</b>${d.cost ? ` <span class="tag">${esc(d.cost)} оч.</span>` : ""}
      ${d.why ? `<div class="small muted">${esc(d.why)}</div>` : ""}<div class="row" style="margin-top:6px"><button class="btn sm" data-p2act="node" data-spec="${spec}">Показать на древе</button></div></div>`;
    if (type === "gem") {
      const g = window.P2 && window.P2.gemIndex ? window.P2.gemIndex.get(String(d.name || "").toLowerCase()) : null;
      if (window.P2 && window.P2.gemIndex && !g) return `<div class="act-card" style="border-color:rgba(248,113,113,.5)"><b>⚠ ${esc(d.name)}</b> <span class="small" style="color:#fca5a5">такого камня в PoE2 нет — ИИ ошибся, совет пропусти</span></div>`;
      return `<div class="act-card"><div class="row" style="gap:8px">${g && g.icon ? `<img src="${esc(g.icon)}" style="width:30px;height:30px">` : ""}<b>💎 ${esc(g ? g.ru : d.name)}</b>${g && g.ru !== g.en ? ` <span class="tiny faint">${esc(g.en)}</span>` : ""}</div>${d.replace ? ` <span class="muted small">вместо ${esc(d.replace)}</span>` : ""}
      ${d.why ? `<div class="small muted">${esc(d.why)}</div>` : ""}<div class="row" style="margin-top:6px"><button class="btn sm" data-p2act="trade" data-spec="${esc(JSON.stringify({cls: "gem", base: d.name}))}">🔎 Цена камня</button></div></div>`;
    }
    if (type === "build") return `<div class="act-card"><b>⚔ ${esc([d.ascendancy, d.skill].filter(Boolean).join(" · "))}</b>
      ${d.why ? `<div class="small muted">${esc(d.why)}</div>` : ""}<div class="row" style="margin-top:6px"><button class="btn sm primary" data-p2act="build" data-spec="${spec}">Собрать этот билд</button></div></div>`;
    return "";
  }
  // what the check under the answer refuted can't be acted on: the card stays visible, its buttons are gone
  function refutedCard(type, raw, tail) {
    if (!tail) return "";
    let d; try { d = JSON.parse(raw); } catch (_) { return ""; }
    const name = d.name || d.unique || d.base || "";
    const hit = (name && (tail.includes(`«${name}»`) || tail.includes(`${name} (`) || tail.includes(`, ${name}`) || tail.includes(`: ${name}`)))
      || (type === "item" && d.slot && tail.includes(`слот «${d.slot}»`));
    const why = tailReason(tail, name) || (type === "item" && d.slot ? tailReason(tail, d.slot) : "");
    return hit ? `<div class="act-card" style="opacity:.75;border-color:rgba(251,113,133,.45)"><b>🚫 ${esc(name || d.slot || "")}</b><div class="small" style="color:var(--red)">${esc(why || "Проверка тулой это не подтвердила")}</div><div class="tiny faint">действие отключено</div></div>` : "";
  }
  // models write maths as LaTeX: «3253 при норме $\ge$ 4275», «перчатки $\rightarrow$ гемы» stood on the screen as is
  const TEX = {ge: "≥", geq: "≥", le: "≤", leq: "≤", rightarrow: "→", to: "→", Rightarrow: "⇒", leftarrow: "←", times: "×", approx: "≈",
    pm: "±", cdot: "·", neq: "≠", infty: "∞", "%": "%", text: "", mathrm: "", textbf: ""};
  const untex = s => s.replace(/\$([^$\n]{1,60})\$/g, (m, x) => /\\[a-zA-Z%]/.test(x) ? x.replace(/\\([a-zA-Z]+|%)/g, (_, c) => TEX[c] ?? c).replace(/[{}]/g, "").trim() : m)
    .replace(/\\(geq?|leq?|rightarrow|Rightarrow|leftarrow|times|approx|pm|neq)\b/g, (_, c) => TEX[c]);
  function md(src) {
    src = untex(String(src || "").replace(/<think>[\s\S]*?<\/think>/g, ""));
    const cards = [];
    const tail = (String(src).split("**Проверка тулой:**")[1] || "");
    src = src.replace(CARD_RE, (_, type, raw) => { cards.push(refutedCard(type, raw, tail) || cardHtml(type, raw, tail)); return `\n@@CARD${cards.length - 1}@@\n`; });
    return mdBase(src).replace(/<p>@@CARD(\d+)@@<\/p>|@@CARD(\d+)@@/g, (_, a, b) => cards[+(a ?? b)] || "");
  }
  // lines that start with one of these icons become coloured blocks — the assistant uses them for key points
  const SEM = {"⚠": ["warn"], "❗": ["warn"], "✅": ["act"], "💰": ["money"], "⭐": ["reward"], "⏭": ["skip"], "⚔": ["boss"],
    "💎": ["gem"], "🛡": ["item"], "🌳": ["node"], "ℹ": ["info"], "🔥": ["boss"], "📈": ["node"]};
  function mdBase(src) {
    const lines = esc(src).split("\n");
    let out = "", list = null, inCode = false, table = [];
    const inline = s => s.replace(/`([^`]+)`/g, "<code>$1</code>").replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
      .replace(/(^|[^*])\*([^*\n]+)\*/g, "$1<em>$2</em>").replace(/\[([^\]]+)\]\((https?:[^)]+)\)/g, '<a href="$2" target="_blank">$1</a>');
    const flushList = () => { if (list) { out += `</${list}>`; list = null; } };
    const flushTable = () => {
      if (!table.length) return;
      const rows = table.filter(r => !/^\|?\s*:?-+/.test(r.replace(/\|/g, "").trim() ? r.split("|")[1] || "" : r));
      out += "<table>" + rows.map((r, i) => "<tr>" + r.replace(/^\||\|$/g, "").split("|").map(c => i ? `<td>${inline(c.trim())}</td>` : `<th>${inline(c.trim())}</th>`).join("") + "</tr>").join("") + "</table>";
      table = [];
    };
    for (const raw of lines) {
      const l = raw;
      if (l.trim().startsWith("```")) { flushList(); flushTable(); out += inCode ? "</pre>" : "<pre>"; inCode = !inCode; continue; }
      if (inCode) { out += l + "\n"; continue; }
      if (/^\s*\|.*\|\s*$/.test(l)) { flushList(); if (!/^\s*\|[\s:|-]+\|\s*$/.test(l)) table.push(l.trim()); continue; }
      flushTable();
      let m;
      if ((m = l.match(/^(#{1,4})\s+(.*)/))) { flushList(); out += `<h${m[1].length + 1}>${inline(m[2])}</h${m[1].length + 1}>`; }
      else if ((m = l.match(/^\s*(?:[-*•]\s+)?(⚠️?|✅|💰|⭐|⏭|⚔|💎|🛡|🌳|ℹ️?|❗|🔥|📈)\s*(.*)/u)) && SEM[m[1].replace("️", "")]) { flushList();
        const k = SEM[m[1].replace("️", "")]; out += `<div class="kb ${k[0]}"><span class="ki">${m[1]}</span><div class="kt">${inline(m[2])}</div></div>`; }
      else if ((m = l.match(/^\s*[-*•]\s+(.*)/))) { if (list !== "ul") { flushList(); out += "<ul>"; list = "ul"; } out += `<li>${inline(m[1])}</li>`; }
      else if ((m = l.match(/^\s*\d+[.)]\s+(.*)/))) { if (list !== "ol") { flushList(); out += "<ol>"; list = "ol"; } out += `<li>${inline(m[1])}</li>`; }
      else if (!l.trim()) { flushList(); }
      else { flushList(); out += `<p>${inline(l)}</p>`; }
    }
    flushList(); flushTable();
    if (inCode) out += "</pre>";
    return out;
  }

  const fmt = {
    ex: v => v == null ? "—" : v >= 100 ? Math.round(v).toLocaleString("ru") : v >= 1 ? v.toFixed(1) : v.toFixed(2),
    div: v => v == null ? "—" : v >= 10 ? v.toFixed(1) : v >= 0.1 ? v.toFixed(2) : v.toFixed(4),
    pct: v => v == null ? "" : `<span class="${v >= 0 ? "up" : "down"}">${v >= 0 ? "▲" : "▼"} ${Math.abs(v).toFixed(0)}%</span>`,
    // «2 лота», «5 лотов», «21 лот», «1,5 базы»: n(v, "лот|лота|лотов") — never «2 лотов»
    n: (v, forms) => {
      const [one, few, many] = forms.split("|"), a = Math.abs(v), i = Math.floor(a);
      const w = i !== a ? few : i % 10 === 1 && i % 100 !== 11 ? one : i % 10 >= 2 && i % 10 <= 4 && (i % 100 < 12 || i % 100 > 14) ? few : many;
      return `${Number.isInteger(v) ? v.toLocaleString("ru") : v} ${w}`;  // «2.5» like every price, «1 234» for counts
    },
    ago: ts => { const s = Date.now() / 1000 - ts; return s < 60 ? "только что" : s < 3600 ? `${Math.round(s / 60)} мин назад` : s < 86400 ? `${Math.round(s / 3600)} ч назад` : `${Math.round(s / 86400)} д назад`; },
  };

  function itemCard(it) {
    const r = it.rarity === "Currency" ? "Currency" : it.rarity;
    let h = `<div class="item r-${esc(r)}"><div class="ihead">${esc(it.name)}${it.base && it.base !== it.name ? `<br>${esc(it.base)}` : ""}</div>`;
    const props = [it.item_class, it.ilvl ? `Уровень предмета: ${it.ilvl}` : "", it.quality ? `Качество: +${it.quality}%` : ""].filter(Boolean);
    h += `<div class="isec prop">${props.map(esc).join(" · ")}</div>`;
    const tierOf = t => (it.tiers || []).find(x => x.text === t);
    for (const kind of ["enchant", "implicit", "rune", "fractured", "explicit", "desecrated", "crafted"]) {
      const mods = (it.mods || {})[kind];
      if (!mods) continue;
      const ru = (it.mods_ru || {})[kind] || [];  // the Russian client's wording; tiers are found by the English line
      h += `<div class="isec">` + mods.map((m, i) => { const t = tierOf(m); return `<div class="mod ${kind}">${esc(ru[i] || m)}${t && t.tier ? `<span class="tiers">${t.kind === "prefix" ? "P" : t.kind === "suffix" ? "S" : ""}T${t.tier}</span>` : ""}</div>`; }).join("") + `</div>`;
    }
    if (it.corrupted) h += `<div class="isec corr">Осквернено</div>`;
    return h + "</div>";
  }

  function spinBtn(btn, on, label) {
    if (!btn) return;  // a button gone from the page (re-rendered) or a currentTarget read after an await
    if (on) { btn.dataset.label = btn.innerHTML; btn.disabled = true; btn.innerHTML = `<span class="spin"></span>${label || ""}`; }
    else { btn.disabled = false; if (btn.dataset.label) btn.innerHTML = btn.dataset.label; }
  }

  // ───── in-app dialog (instead of window.prompt/confirm, which look foreign and may be blocked in the app window) ─────
  // dialog({title, text, input: {type: "text"|"date"|"select"|"textarea", value, placeholder, options: [[v, label]]},
  //         ok, danger}) -> Promise<value | true | null>
  function dialog(o) {
    return new Promise(resolve => {
      const wrap = document.createElement("div");
      wrap.className = "palette";
      const inp = o.input || null;
      const field = !inp ? "" : inp.type === "select"
        ? `<select class="inp" id="dlg-in">${inp.options.map(([v, l]) => `<option value="${esc(v)}" ${String(v) === String(inp.value ?? "") ? "selected" : ""}>${esc(l)}</option>`).join("")}</select>`
        : inp.type === "textarea" ? `<textarea class="inp" id="dlg-in" rows="4" placeholder="${esc(inp.placeholder || "")}">${esc(inp.value || "")}</textarea>`
        : `<input class="inp" id="dlg-in" type="${inp.type || "text"}" value="${esc(inp.value || "")}" placeholder="${esc(inp.placeholder || "")}">`;
      wrap.innerHTML = `<div class="pal-box" style="width:min(460px,92vw);padding:18px">
        <h3 style="font-size:15px;margin-bottom:8px">${esc(o.title || "")}</h3>
        ${o.text ? `<div class="small muted" style="margin-bottom:12px">${esc(o.text)}</div>` : ""}${field}
        <div class="row end" style="margin-top:14px"><button class="btn ghost" data-a="no">Отмена</button>
          <button class="btn ${o.danger ? "danger" : "primary"}" data-a="ok">${esc(o.ok || "OK")}</button></div></div>`;
      document.body.appendChild(wrap);
      const el = wrap.querySelector("#dlg-in");
      const done = v => { wrap.remove(); resolve(v); };
      wrap.querySelector("[data-a=ok]").onclick = () => done(el ? el.value : true);
      wrap.querySelector("[data-a=no]").onclick = () => done(null);
      wrap.onclick = e => { if (e.target === wrap) done(null); };
      wrap.onkeydown = e => { if (e.key === "Escape") done(null); if (e.key === "Enter" && (!el || el.tagName !== "TEXTAREA")) done(el ? el.value : true); };
      (el || wrap.querySelector("[data-a=ok]")).focus();
    });
  }

  // ───── dropdowns: everything that can be picked instead of typed ─────
  let choicesCache = null, choicesAt = 0;
  async function choices(refresh) {
    if (!refresh && choicesCache && Date.now() - choicesAt < 120000) return choicesCache;
    choicesCache = await api.get("/api/choices"); choicesAt = Date.now();
    return choicesCache;
  }
  // <select> with an optional «Своё…» entry that reveals a text field; read it back with selectValue()
  function selectHtml(name, options, o = {}) {
    const opts = options.map(x => Array.isArray(x) ? x : [x, x]);
    return `<div class="p2-select" data-name="${esc(name)}"><select class="inp">${o.empty !== false ? `<option value="">${esc(o.empty || "— выбери —")}</option>` : ""}
      ${opts.map(([v, l]) => `<option value="${esc(v)}" ${o.value === v ? "selected" : ""}>${esc(l)}</option>`).join("")}
      ${o.custom ? `<option value="__custom">✎ ${esc(o.customLabel || "Своё…")}</option>` : ""}</select>
      ${o.custom ? `<input class="inp" style="margin-top:6px" hidden placeholder="${esc(o.placeholder || "")}">` : ""}</div>`;
  }
  function wireSelects(root) {
    root.querySelectorAll(".p2-select").forEach(w => {
      const s = w.querySelector("select"), i = w.querySelector("input");
      if (i) s.onchange = () => { i.hidden = s.value !== "__custom"; if (!i.hidden) i.focus(); };
    });
  }
  function selectValue(root, name) {
    const w = root.querySelector(`.p2-select[data-name="${name}"]`);
    if (!w) return "";
    const s = w.querySelector("select");
    return s.value === "__custom" ? (w.querySelector("input")?.value || "").trim() : s.value;
  }
  // build source picker: my character (PoB), PoB builds, account characters, or a pasted code/link
  async function sourcePicker(el, o = {}) {
    const c = await choices();
    const prev = el.querySelector("select")?.value;
    const groups = [];
    const mine = [...c.characters].sort((a, b) => (b.id === c.active) - (a.id === c.active));
    if (mine.length) groups.push(`<optgroup label="Мои персонажи">${mine.map(ch => ch.build_file
      ? `<option value="file:${esc(ch.build_file)}">${ch.id === c.active ? "★ " : ""}${esc(ch.name)} — ${esc(ch.class_ru || ch.class || "")} ${ch.level || ""}${ch.id === c.active ? " (активный)" : ""}</option>`
      : `<option value="need:${esc(ch.id)}">${ch.id === c.active ? "★ " : ""}${esc(ch.name)} — ${esc(ch.class_ru || ch.class || "")} ${ch.level || ""} · ⤓ загрузить билд с аккаунта</option>`).join("")}</optgroup>`);
    const linked = new Set(c.characters.map(ch => ch.build_file).filter(Boolean));
    const free = c.builds.filter(b => !linked.has(b.file));
    if (free.length) groups.push(`<optgroup label="Другие билды Path of Building">${free.map(b => `<option value="file:${esc(b.file)}">${esc(b.name)} — ${esc(b.ascendancy || b.class || "")} ${b.level || ""}</option>`).join("")}</optgroup>`);
    el.innerHTML = `<select class="inp">${o.none ? `<option value="">${esc(o.none)}</option>` : ""}${groups.join("")}
      <option value="code:">📋 Вставить PoB-код или ссылку pobb.in / poe.ninja…</option></select>
      <input class="inp" style="margin-top:6px" hidden placeholder="eNrt… или https://pobb.in/…">`;
    const s = el.querySelector("select"), i = el.querySelector("input");
    if (prev && !prev.startsWith("need:") && [...s.options].some(op => op.value === prev)) s.value = prev;
    else {
      // default: a real build; else «no build» when the tab allows it; else the active character (loads on use)
      const first = [...s.options].find(op => op.value.startsWith("file:"));
      const need = [...s.options].find(op => op.value === `need:${c.active}`);
      s.value = o.preferNone ? "" : first ? first.value : o.none !== undefined ? "" : need ? need.value : "code:";
    }
    let last = s.value;
    s.onchange = async () => {
      i.hidden = s.value !== "code:"; if (!i.hidden) i.focus();
      if (!s.value.startsWith("need:")) { last = s.value; o.onChange && o.onChange(sourceValue(el)); return; }
      // a character without a build: fetch it from the account right here instead of a dead option
      const pid = s.value.slice(5);
      s.disabled = true;
      try {
        const file = await window.P2.loadBuild(pid);
        await sourcePicker(el, o);
        const s2 = el.querySelector("select");
        if (file && [...s2.options].some(op => op.value === `file:${file}`)) s2.value = `file:${file}`;
        toast("ok", "Билд загружен", "шмот, камни и древо персонажа теперь в туле");
        o.onChange && o.onChange(sourceValue(el));
      } catch (err) {
        s.disabled = false; s.value = last; i.hidden = s.value !== "code:";
        toast("err", "Билд не загрузился", err.message);
      }
    };
    i.hidden = s.value !== "code:";
  }
  function sourceValue(el) {
    const v = el.querySelector("select")?.value || "";
    if (v === "code:") { const code = el.querySelector("input").value.trim(); return code ? {code} : null; }
    if (v.startsWith("file:")) return {file: v.slice(5)};
    if (v.startsWith("character:")) return {character: v.slice(10)};
    if (v.startsWith("need:")) return {need: v.slice(5)};
    return null;
  }

  // ───── reusable assistant panel: sessions + plan checklist + streaming chat ─────
  function assistantPanel(root, cfg) {
    root.innerHTML = `
      <div class="split">
        <div class="grid">
          <div class="card glow"><h3>${esc(cfg.newTitle || "Новый")}</h3><div class="ap-form"></div>
            <button class="btn primary ap-create" style="width:100%">${esc(cfg.createLabel || "Создать")}</button></div>
          <div class="card"><h3>История <span class="muted small ap-count"></span></h3><div class="sessions ap-list"></div></div>
        </div>
        <div class="ap-main"><div class="card empty">${cfg.emptyHtml || "Создай сессию слева — ассистент проведёт пошагово."}</div></div>
      </div>`;
    root.querySelector(".ap-form").innerHTML = cfg.formHtml;
    cfg.onForm && cfg.onForm(root.querySelector(".ap-form"));
    let cur = null;

    async function loadList() {
      const list = await api.get(`/api/sessions?kind=${cfg.kind}`);
      root.querySelector(".ap-count").textContent = list.length || "";
      root.querySelector(".ap-list").innerHTML = list.length ? list.map(s => `
        <div class="sess ${cur && cur.id === s.id ? "on" : ""}" data-id="${s.id}"><b>${esc(s.title)}</b>
        <span>${s.steps ? `${s.done}/${s.steps} шагов · ` : ""}${fmt.ago(s.updated)}</span></div>`).join("")
        : `<div class="faint small">Пока пусто</div>`;
      root.querySelectorAll(".sess").forEach(el => el.onclick = () => open(el.dataset.id));
    }

    function renderPlan() {
      const steps = cur.steps || [];
      const done = steps.filter(s => s.done).length;
      const curIdx = steps.findIndex(s => !s.done);
      return `<div class="card"><div class="row"><h3 style="margin:0">План</h3><span class="muted small">${done}/${steps.length}</span><span class="spacer"></span>
          <button class="btn sm ap-plan">${steps.length ? "Пересобрать" : "Составить план"}</button>
          ${steps.length ? `<button class="btn sm primary ap-next">Следующий шаг →</button>` : ""}</div>
          ${steps.length ? `<div class="progress" style="margin:12px 0"><i style="width:${steps.length ? 100 * done / steps.length : 0}%"></i></div>` : ""}
          ${cur.plan_check ? `<div class="small md" style="margin:8px 0;color:#fde68a">${md(cur.plan_check.replace(/^\s*---\s*/, ""))}</div>` : ""}
          <div class="plan">${steps.map((s, i) => `<div class="step ${s.done ? "done" : ""} ${i === curIdx ? "cur open" : ""}" data-i="${i}">
            <div class="cb">✓</div><div><div class="st-title">${i + 1}. ${esc(s.title)} ${s.cost ? `<span class="tag" style="margin-left:6px">${esc(s.cost)}</span>` : ""}</div>
            <div class="st-det">${md(s.details)}${s.item ? `<div class="row" style="margin-top:6px">
              <button class="btn sm primary" data-p2act="trade" data-spec="${esc(JSON.stringify(s.item))}">🔎 Трейд с фильтрами</button>
              <button class="btn sm" data-p2act="craft" data-spec="${esc(JSON.stringify(s.item))}">⚒ Скрафтить</button></div>` : ""}</div></div></div>`).join("") || `<div class="faint small">Нажми «Составить план» — ассистент разложит цель на шаги, по которым можно идти и отмечать прогресс.</div>`}</div></div>`;
    }

    function render() {
      const main = root.querySelector(".ap-main");
      main.innerHTML = `<div class="split-r">
        <div class="card chat"><div class="row" style="margin-bottom:8px"><b>${esc(cur.title)}</b><span class="spacer"></span>
          <button class="btn sm ghost ap-ctx" title="Что ассистент знает">Контекст</button>
          <button class="btn sm ghost danger ap-del">Удалить</button></div>
          ${cfg.chips ? `<div class="chips">${cfg.chips.map(c => `<button>${esc(c)}</button>`).join("")}</div>` : ""}
          <div class="msgs"></div>
          <div class="composer"><div class="thumbs"></div>
            <textarea rows="1" placeholder="${esc(cfg.placeholder || "Спроси или вставь предмет (Ctrl+C в игре), PoB-ссылку, скрин (Ctrl+V)…")}"></textarea>
            <button class="btn primary ap-send" title="Отправить (Enter)"><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button></div>
        </div>
        <div class="ap-plan-wrap">${renderPlan()}</div></div>`;
      const msgs = main.querySelector(".msgs");
      msgs.innerHTML = (cur.messages || []).map((m, i) => msgHtml(m.role, m.content, m.provider, i, m.rating)).join("") || `<div class="empty">Задай вопрос или начни с плана справа.</div>`;
      wireRatings(msgs);
      msgs.scrollTop = msgs.scrollHeight;
      wireChat(main);
      wirePlan(main);
      if (cfg.onOpen) cfg.onOpen(cur, main);
      main.querySelector(".ap-del").onclick = async () => { if (!await dialog({title: "Удалить сессию?", text: cur.title, ok: "Удалить", danger: true})) return; await api.del(`/api/sessions/${cur.id}`); cur = null; main.innerHTML = `<div class="card empty">Удалено</div>`; loadList(); };
      main.querySelector(".ap-ctx").onclick = () => { const t = cur.context.text || "(пусто)"; addMsg(msgs, "ai", "**Контекст сессии:**\n```\n" + t.slice(0, 6000) + "\n```"); };
      main.querySelectorAll(".chips button").forEach(b => b.onclick = () => send(main, b.textContent));
    }

    function msgHtml(role, text, provider, idx, rating) {
      if (role === "user") return `<div class="msg user">${esc(text.length > 1800 ? text.slice(0, 1800) + "…" : text)}</div>`;
      const rate = idx == null ? "" : `<span class="spacer"></span><span class="rate" data-i="${idx}">
        <button class="btn sm ghost ${rating > 0 ? "on" : ""}" data-r="1" title="Полезно — запомнить">👍</button>
        <button class="btn sm ghost ${rating < 0 ? "on" : ""}" data-r="-1" title="Неверно — поправить, тула запомнит">👎</button></span>`;
      return `<div class="msg ai"><div class="who" style="display:flex;align-items:center;gap:6px">✦ ${esc(provider || "ассистент")}${rate}</div><div class="body md">${md(text)}</div></div>`;
    }
    function wireRatings(box) {
      box.querySelectorAll(".rate button").forEach(b => b.onclick = async () => {
        const i = +b.parentElement.dataset.i, r = +b.dataset.r;
        let comment = "";
        if (r < 0) {
          comment = await dialog({title: "Что не так в ответе?", text: "Напиши, как правильно — тула запомнит и учтёт это в следующих ответах.",
                                  input: {type: "textarea", placeholder: "Например: этот омен уже не работает так, правильно…"}, ok: "Запомнить"});
          if (comment === null) return;
        }
        try { await api.post("/api/learn/feedback", {session: cur.id, index: i, rating: r, comment});
          b.parentElement.querySelectorAll("button").forEach(x => x.classList.toggle("on", x === b));
          toast("ok", r > 0 ? "Запомнил, что это полезно" : "Спасибо — поправка сохранена в базе знаний"); }
        catch (e) { toast("err", "Не сохранилось", e.message); }
      });
    }
    function addMsg(msgs, role, text) {
      msgs.querySelector(".empty")?.remove();
      msgs.insertAdjacentHTML("beforeend", msgHtml(role, text));
      msgs.scrollTop = msgs.scrollHeight;
      return msgs.lastElementChild;
    }

    function wirePlan(main) {
      const wrap = main.querySelector(".ap-plan-wrap");
      wrap.querySelectorAll(".step").forEach(el => {
        el.onclick = e => { if (!e.target.classList.contains("cb")) { el.classList.toggle("open"); return; }
          const i = +el.dataset.i; api.post(`/api/sessions/${cur.id}/step`, {index: i, done: !cur.steps[i].done}).then(s => { cur = s; wrap.innerHTML = renderPlan(); wirePlan(main); loadList(); }); };
      });
      const pb = wrap.querySelector(".ap-plan");
      pb.onclick = async () => {
        spinBtn(pb, true, "Думаю…");
        try { cur = await api.post(`/api/sessions/${cur.id}/plan`); wrap.innerHTML = renderPlan(); wirePlan(main); loadList(); toast("ok", "План готов", fmt.n(cur.steps.length, "шаг|шага|шагов")); }
        catch (e) { toast("err", "Не вышло составить план", e.message); spinBtn(pb, false); }
      };
      const nb = wrap.querySelector(".ap-next");
      if (nb) nb.onclick = () => runStream(main, `/api/sessions/${cur.id}/next`, {}, "Что делать на текущем шаге?");
    }

    let images = [];
    function wireChat(main) {
      const ta = main.querySelector("textarea"), thumbs = main.querySelector(".thumbs");
      ta.oninput = () => { ta.style.height = "auto"; ta.style.height = Math.min(220, ta.scrollHeight) + "px"; };
      ta.onkeydown = e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(main, ta.value); } };
      ta.onpaste = e => {
        for (const f of e.clipboardData.files || []) if (f.type.startsWith("image/")) {
          const rd = new FileReader();
          rd.onload = () => { images.push(rd.result.split(",")[1]); thumbs.insertAdjacentHTML("beforeend", `<img src="${rd.result}">`); };
          rd.readAsDataURL(f);
        }
      };
      main.querySelector(".ap-send").onclick = () => send(main, ta.value);
    }
    function send(main, text) {
      text = text.trim();
      if (!text && !images.length) return;
      const ta = main.querySelector("textarea"); ta.value = ""; ta.style.height = "auto";
      const imgs = images; images = []; main.querySelector(".thumbs").innerHTML = "";
      runStream(main, `/api/sessions/${cur.id}/chat`, {text: text || "Что на скриншоте?", images: imgs}, text || "🖼 скриншот");
    }
    async function runStream(main, url, body, shown) {
      try { return await streamInto(main, url, body, shown); }
      finally { if (cfg.onOpen && cur) cfg.onOpen(cur, main); }  // the answer may have changed what the tab shows
    }
    async function streamInto(main, url, body, shown) {
      const msgs = main.querySelector(".msgs");
      addMsg(msgs, "user", shown);
      const el = addMsg(msgs, "ai", ""); el.classList.add("typing");
      const bodyEl = el.querySelector(".body"), who = el.querySelector(".who");
      let acc = "";
      setBusy(cfg.kind, true);
      const toolsEl = document.createElement("div"); toolsEl.className = "agent-tools"; bodyEl.before(toolsEl);
      await stream(url, body, {
        onProvider: p => who.textContent = "✦ " + p,
        onTool: t => { toolsEl.insertAdjacentHTML("beforeend", `<span class="agent-tool">${esc(t)}</span>`); msgs.scrollTop = msgs.scrollHeight; },
        onText: t => { if (!acc) toolsEl.classList.add("done"); acc += t; bodyEl.innerHTML = md(acc); msgs.scrollTop = msgs.scrollHeight; },
        onReplace: t => { acc = t; bodyEl.innerHTML = md(acc); },
        onError: e => { bodyEl.innerHTML += `<p style="color:var(--red)">${esc(e)}</p>`; },
        onDone: () => {},
      });
      el.classList.remove("typing");
      setBusy(cfg.kind, false);
      cur = await api.get(`/api/sessions/${cur.id}`);
      const last = cur.messages.length - 1;
      if (last >= 0 && cur.messages[last].role === "assistant") {
        who.insertAdjacentHTML("beforeend", `<span class="spacer"></span><span class="rate" data-i="${last}"><button class="btn sm ghost" data-r="1" title="Полезно">👍</button><button class="btn sm ghost" data-r="-1" title="Неверно — поправить">👎</button></span>`);
        who.style.display = "flex"; who.style.alignItems = "center"; who.style.gap = "6px";
        wireRatings(el);
      }
      loadList();
    }

    async function open(id) { cur = await api.get(`/api/sessions/${id}`); render(); loadList(); }

    root.querySelector(".ap-create").onclick = async e => {
      const btn = e.currentTarget;
      const body = cfg.collect(root.querySelector(".ap-form"));
      if (!body) return;
      spinBtn(btn, true, "Собираю данные…");
      let created = false;
      try { const s = await api.post(cfg.newUrl, body); await open(s.id); created = true; }
      catch (err) { toast("err", "Ошибка", err.message); }
      spinBtn(btn, false);
      if (!created || cfg.kickoff === false) return;
      // start working right away: a first full answer from the chosen parameters, then the step plan
      const main = root.querySelector(".ap-main");
      const kick = typeof cfg.kickoff === "function" ? cfg.kickoff(body)
        : "Начинай: по выбранным параметрам дай готовое решение — что делать прямо сейчас, по шагам, с конкретикой и ссылками. Чего не хватает — реши сам по моему активному персонажу и мете, не переспрашивай.";
      if (!kick) return;
      await runStream(main, `/api/sessions/${cur.id}/chat`, {text: kick, images: []}, "▶ " + (cfg.kickoffLabel || "Начать"));
      const pb = main.querySelector(".ap-plan");
      if (pb && !(cur.steps || []).length) pb.click();
    };
    loadList();
    // «История» opens a session of this kind here: now if the tab is built, at its first look otherwise
    sessionOpeners[cfg.kind] = id => open(id);
    if (pendingOpen[cfg.kind]) { open(pendingOpen[cfg.kind]); delete pendingOpen[cfg.kind]; }
    return {open, reload: loadList, prefill: (sel, val) => { const f = root.querySelector(sel); if (f) f.value = val; }};
  }
  const sessionOpeners = {}, pendingOpen = {};
  // a session of a tab, opened in that tab (from «История»): the tab is shown, its panel opens the session
  function openSession(tab, kind, id) {
    go(tab);
    if (sessionOpeners[kind]) sessionOpeners[kind](id);
    else pendingOpen[kind] = id;
  }

  // ───── live channel (Client.txt + clipboard) ─────
  const liveSubs = [];
  let liveState = {log: {}, clip: {}};
  function connectLive() {
    const es = new EventSource(lane("/api/live", 0));
    es.onmessage = e => { liveState = JSON.parse(e.data); renderLiveCard(); notifyLog(liveState.log); notifyClip(liveState.clip); notifyWatch(liveState.watch); notifyDeath(liveState.death); notifyDoctor(liveState.doctor); liveSubs.forEach(f => { try { f(liveState); } catch (err) { console.error(err); } }); };
    es.onerror = () => { es.close(); setTimeout(connectLive, 4000); };
  }
  const mmss = s => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
  let lastZone = null;
  function renderLiveCard() {
    const l = liveState.log || {}, n = liveState.now || {};
    $("#lc-dot").classList.toggle("on", !!l.connected);
    // the card is the ACCOUNT (Steam + GGG); characters are in the header — here only where the player is now
    let sub = l.connected ? (n.area ? "" : "игра: ждём событий") : "игра не найдена — укажи Client.txt в настройках";
    let hint = "";
    if (n.kind === "map") {
      sub = `🗺 ${n.map ? esc(n.map.name) + " · ур. " + n.map.level : esc(n.area || "")}`;
      hint = n.map ? `⏱ ${mmss(n.map.seconds)}${n.session && n.session.runs ? ` · ${fmt.n(n.session.runs, "карта|карты|карт")}, ~${n.session.avg_min} мин` : ""}` : "";
    } else if (n.zone) {
      sub = `📍 ${esc(n.zone.name)} · ур. ${n.zone.level}`;
      hint = n.zone.rewards.length ? `⭐ ${esc(n.zone.rewards[0])}` : n.zone.skip ? "⏭ эту зону можно пропустить" : n.zone.kill ? `⚔ ${esc(n.zone.kill)}` : "";
    } else if (n.area) sub = `📍 ${esc(n.area)}`;
    $("#lc-sub").innerHTML = sub + (hint ? `<div class="lc-hint">${hint}</div>` : "");
    if (n.zone && n.zone.id !== lastZone && lastZone !== null && prefs.toasts !== false) {
      if (n.zone.rewards.length) toast("ok", `⭐ ${n.zone.name}`, n.zone.rewards.join(" · ") + (n.zone.kill ? " — " + n.zone.kill : ""));
      else if (n.zone.skip) toast("info", `⏭ ${n.zone.name}`, "зону можно пропустить — постоянной награды нет");
    }
    if (n.zone) lastZone = n.zone.id; else if (n.area_id) lastZone = n.area_id;
  }

  // ───── preferences & i18n ─────
  let prefs = {language: "ru", toasts: true};
  const t = s => (window.P2_I18N[prefs.language] || {})[s] || s;
  const ACCENTS = {
    violet: ["#8b5cf6", "#c084fc", "linear-gradient(135deg,#a855f7 0%,#7c3aed 55%,#5b21b6 100%)", "rgba(139,92,246,.45)"],
    purple: ["#9333ea", "#d8b4fe", "linear-gradient(135deg,#c026d3 0%,#9333ea 55%,#6b21a8 100%)", "rgba(147,51,234,.45)"],
    indigo: ["#6366f1", "#a5b4fc", "linear-gradient(135deg,#818cf8 0%,#6366f1 55%,#4338ca 100%)", "rgba(99,102,241,.45)"],
    magenta: ["#d946ef", "#f0abfc", "linear-gradient(135deg,#e879f9 0%,#c026d3 55%,#86198f 100%)", "rgba(217,70,239,.45)"],
  };
  // one zoom for the page: the player's own scale (Settings) times the fit to a narrow window
  let fitZoom = 1;
  function applyZoom() {
    const z = Math.round(((prefs && prefs.font_scale) || 100) / 100 * fitZoom * 100) / 100;
    document.body.style.zoom = z === 1 ? "" : String(z);
  }
  function applyPrefs(p) {
    prefs = p;
    const a = ACCENTS[p.accent] || ACCENTS.violet, st = document.documentElement.style;
    st.setProperty("--accent", a[0]); st.setProperty("--accent2", a[1]); st.setProperty("--grad", a[2]); st.setProperty("--glow", a[3]);
    applyZoom();
    document.body.classList.toggle("compact", !!p.compact);
    document.documentElement.lang = p.language;
    window.P2_setLanguage && window.P2_setLanguage(p.language);
    document.querySelectorAll("[data-i18n]").forEach(el => el.textContent = t(el.dataset.i18n));
    document.querySelectorAll(".nav button").forEach(b => { const l = b.querySelector(".lbl"); const m = modules.find(x => x.id === b.dataset.id); if (l && m) l.textContent = t(m.id) !== m.id ? t(m.id) : m.title; });
    if (current) { const m = modules.find(x => x.id === current); $("#v-title").textContent = t(m.id) !== m.id ? t(m.id) : m.title; }
  }
  let lastLog = null;
  // new listing from a price watch / a death analysis → toast with a button
  const seenVer = {watch: null, death: null};
  function notifyWatch(w) {
    if (!w) return;
    const first = seenVer.watch === null;
    if (w.version === seenVer.watch) return;
    seenVer.watch = w.version;
    if (first || !w.last) return;
    const t = document.createElement("div");
    t.className = "toast ok";
    t.innerHTML = `<b>👁 ${esc(w.last.watch)}: ${fmt.n(w.last.count, "новый лот|новых лота|новых лотов")}</b><span class="muted small">лучший: ${esc(w.last.best.price)} · ${esc(w.last.best.name || w.last.best.base || "")}</span>
      <div class="row" style="margin-top:8px"><button class="btn sm primary">Открыть трейд</button>${w.last.best.whisper ? `<button class="btn sm">Скопировать сообщение продавцу</button>` : ""}</div>`;
    $("#toasts").appendChild(t);
    const [a, b] = t.querySelectorAll("button");
    a.onclick = () => { openExternal(w.last.url); t.remove(); };
    if (b) b.onclick = () => { navigator.clipboard?.writeText(w.last.best.whisper); toast("ok", "Скопировано", "вставь в чат игры (Enter → Ctrl+V)"); };
    setTimeout(() => t.remove(), 30000);
  }
  // the doctor's own check found something broken: say it once, with the way to the doctor
  let doctorV = null;
  function notifyDoctor(d) {
    if (!d || d.v === doctorV) return;
    const first = doctorV === null; doctorV = d.v;
    if (first && !d.fail.length) return;
    if (!d.fail.length) return;
    const t = document.createElement("div");
    t.className = "toast err";
    t.innerHTML = `<b>Доктор нашёл проблемы: ${d.fail.length}</b><span class="muted small">${esc(d.fail.slice(0, 2).join(" · "))}</span>
      <div class="row" style="margin-top:8px"><button class="btn sm primary">Открыть «Доктор»</button></div>`;
    $("#toasts").appendChild(t);
    t.querySelector("button").onclick = () => { show("doctor"); t.remove(); };
    setTimeout(() => t.remove(), 20000);
  }
  function notifyDeath(dv) {
    if (!dv) return;
    const first = seenVer.death === null;
    if (dv.version === seenVer.death) return;
    seenVer.death = dv.version;
    if (first || !dv.last) return;
    const r = dv.last;
    const t = document.createElement("div");
    t.className = "toast err";
    t.innerHTML = `<b>☠ Разбор смерти: ${esc(r.area || "")}</b><span class="muted small">${esc((r.weak[0] || {}).text || "слабых мест не найдено")}</span>
      <div class="row" style="margin-top:8px"><button class="btn sm primary">Подробнее</button></div>`;
    $("#toasts").appendChild(t);
    t.querySelector("button").onclick = () => { show("character"); setTimeout(() => document.getElementById("ch-deaths")?.scrollIntoView({behavior: "smooth"}), 400); t.remove(); };
    setTimeout(() => t.remove(), 25000);
  }
  let lastClip = null;
  function notifyClip(c) {
    if (!c || c.version === lastClip) return;
    const first = lastClip === null; lastClip = c.version;
    if (first || c.action !== "pob") return;
    const t = document.createElement("div");
    t.className = "toast info";
    t.innerHTML = `<b>Скопирован PoB-билд</b><span class="muted small">poe.ninja / Maxroll / Mobalytics / pobb.in</span>
      <div class="row" style="margin-top:8px"><button class="btn sm primary">Открыть в PoB-разборе</button><button class="btn sm">Дерево</button></div>`;
    $("#toasts").appendChild(t);
    const [a, b] = t.querySelectorAll("button");
    a.onclick = () => { show("pob"); registry.pob?.load?.(c.text); t.remove(); };
    b.onclick = async () => { show("tree"); await new Promise(r => setTimeout(r, 400));
      const box = document.getElementById("tr-src"), sel = box?.querySelector("select");
      if (sel) { sel.value = "code:"; sel.onchange(); box.querySelector("input").value = c.text; document.getElementById("tr-load")?.click(); }
      t.remove(); };
    setTimeout(() => t.remove(), 15000);
  }
  function notifyLog(l) {
    if (!l || !l.last_event || !lastLog) { lastLog = l && l.version; return; }
    if (l.version === lastLog) return;
    lastLog = l.version;
    const e = l.last_event;
    if (!e.live || !prefs.toasts) return;
    if (e.type === "level" && prefs.notify_levelup) toast("ok", "Level up!", e.text);
    if (e.type === "death" && prefs.notify_death) toast("err", "Смерть", "загляни в Билд-ассистент: что усилить в защите");
    if (prefs.sound && (e.type === "level" || e.type === "death")) try { new Audio("data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=").play(); } catch (_) {}
  }

  // ───── modules / routing ─────
  const registry = {}, commands = [];
  let modules = [], current = null;
  function registerModule(m) { registry[m.id] = m; if (current === m.id && m.onShow) m.onShow(); }
  function registerCommand(c) { commands.push(c); }
  function setBusy(id, on) { document.querySelector(`.nav button[data-id="${id}"]`)?.classList.toggle("busy", on); }

  function show(id) {
    const m = modules.find(x => x.id === id) || modules[0];
    current = m.id;
    document.querySelectorAll(".view").forEach(v => v.classList.toggle("on", v.id === `v-${m.id}`));
    document.querySelectorAll(".nav button").forEach(b => b.classList.toggle("on", b.dataset.id === m.id));
    $("#v-title").textContent = t(m.id) !== m.id ? t(m.id) : m.title; $("#v-sub").textContent = m.subtitle || "";
    document.documentElement.style.setProperty("--sec", m.color || "var(--accent2)");
    if (location.hash !== `#${m.id}`) history.replaceState(null, "", `#${m.id}`);
    registry[m.id]?.onShow?.();
    if (dock.open) dockRefresh();  // the dock follows the tab
  }
  function go(id) { show(id); }

  // a tester's copy opens with the creator's login and password, made for this PC; the creator's PC and a copy without a key open as they are
  async function gate() {
    const a = await fetch("/api/access/state").then(r => r.json()).catch(() => ({locked: false}));
    if (a.login) { const w = $("#acc-who"); w.hidden = false; w.textContent = `доступ: ${a.login} · до ${a.until}`; }
    if (!a.locked) return true;
    document.body.insertAdjacentHTML("beforeend", `<div class="login" id="login"><div class="box">
      <h1>POE2 Helper</h1><div class="by">created by ${esc(a.creator_name || "SerTeZzZ")}</div>
      <div class="small muted" style="margin-bottom:6px">Код этого ПК — отправь его создателю, он выдаст логин и пароль именно для этого компьютера:</div>
      <div class="tiny faint" style="margin-bottom:8px">Это тестовая копия: раз в день она отправляет создателю отчёт — журнал, ошибки и что ты делал в туле, чтобы чинить
        найденное. Ключи ИИ, вход PoB и POESESSID в отчёт не попадают.</div>
      <div class="row" style="gap:8px;margin-bottom:16px"><span class="code">${esc(a.machine)}</span><button class="btn sm" id="login-copy">Скопировать</button></div>
      <label class="small">Логин<input class="inp" id="login-name" autocomplete="username"></label>
      <label class="small">Пароль<input class="inp" id="login-pass" type="password" autocomplete="current-password"></label>
      <div class="small" id="login-err" style="color:var(--red);min-height:18px"></div>
      <button class="btn primary" id="login-go" style="width:100%">Войти</button></div></div>`);
    $("#login-copy").onclick = () => navigator.clipboard.writeText(a.machine).then(() => toast("ok", "Код скопирован", a.machine));
    const go = async () => {
      try { await api.post("/api/access/login", {login: $("#login-name").value, password: $("#login-pass").value}); location.reload(); }
      catch (e) { $("#login-err").textContent = e.message; }
    };
    $("#login-go").onclick = go;
    $("#login-pass").onkeydown = e => { if (e.key === "Enter") go(); };
    return false;
  }

  async function boot() {
    if (!(await gate())) return;
    modules = await api.get("/api/modules");
    const nav = $("#nav"), views = $("#views");
    for (const m of modules) {
      nav.insertAdjacentHTML("beforeend", `<button data-id="${m.id}" style="--sec:${m.color}" title="${esc(m.title)}">
        <svg viewBox="0 0 24 24">${m.icon || ""}</svg><span class="lbl">${esc(m.title)}</span>${m.key ? `<kbd>Alt ${m.key}</kbd>` : ""}</button>`);
      views.insertAdjacentHTML("beforeend", `<section class="view" id="v-${m.id}"></section>`);
    }
    nav.querySelectorAll("button").forEach(b => b.onclick = () => show(b.dataset.id));
    for (const m of modules) {
      const html = await fetch(`/m/${m.id}/ui.html`).then(r => r.status === 200 ? r.text() : "");
      $(`#v-${m.id}`).innerHTML = html;
      if (m.has_css) document.head.insertAdjacentHTML("beforeend", `<link rel="stylesheet" href="/m/${m.id}/ui.css">`);
      const js = await fetch(`/m/${m.id}/ui.js`).then(r => r.status === 200 ? r.text() : "");
      if (js) { const s = document.createElement("script"); s.textContent = js + `\n//# sourceURL=/m/${m.id}/ui.js`; document.body.appendChild(s); }
    }
    try { applyPrefs((await api.get("/api/settings/prefs")).values); } catch (_) {}
    show(location.hash.slice(1) || prefs.start_page);
    connectLive();
    refreshStatus(); setInterval(refreshStatus, 60000);
    refreshActive();
  }

  // a new signed version downloaded and checked in the background: it goes in when the tool closes, or now
  function showUpdate(u) {
    let bar = document.getElementById("upd-bar");
    if (!u || !u.ready) { if (bar) bar.remove(); return; }
    if (!bar) {
      bar = document.createElement("div");
      bar.id = "upd-bar";
      bar.className = "upd-bar";
      document.body.appendChild(bar);
    }
    if (bar.dataset.v === u.ready) return;
    bar.dataset.v = u.ready;
    bar.innerHTML = `<span>⬆ Готово обновление <b>${esc(u.ready)}</b>${u.notes ? ` — ${esc(u.notes)}` : ""}. Поставится само при закрытии тулы.</span>
      <button class="btn sm primary" id="upd-now">Перезапустить сейчас</button><button class="btn sm ghost" id="upd-hide">Позже</button>`;
    bar.querySelector("#upd-now").onclick = async e => {
      const b = e.currentTarget;  // null once the handler resumes after an await
      b.disabled = true; b.textContent = "Ставлю…";
      try { await api.post("/api/app/update/apply", {}); toast("ok", "Обновляюсь", "тула откроется сама через несколько секунд"); }
      catch (err) { toast("err", "Обновление", err.message); b.disabled = false; b.textContent = "Перезапустить сейчас"; }
    };
    bar.querySelector("#upd-hide").onclick = () => { bar.hidden = true; };
  }

  async function refreshStatus() {
    try {
      const s = await api.get("/api/status");
      const lg = $("#chip-league"); lg.className = `chip ${s.league ? "ok" : "warn"}`; lg.querySelector("span").textContent = s.league || "лига ?";
      const ll = $("#chip-llm"); ll.className = `chip ${s.providers.length ? "ok" : "fail"}`;
      ll.querySelector("span").textContent = s.providers.length ? `LLM: ${s.providers.length} ${s.providers.length > 4 ? "провайдеров" : "пров."}` : "LLM не настроен";
      ll.title = s.providers.join(", ");
      showUpdate(s.update);
      if (s.meta_notice && prefs.notify_patch && s.meta_notice.time > (+localStorageGet("p2notice") || 0)) {
        toast("info", s.meta_notice.text, "Готов новый мета-отчёт — раздел «Мета и патчи»");
        localStorageSet("p2notice", s.meta_notice.time);
      }
    } catch (e) { /* server restarting */ }
  }

  // ───── palette (Ctrl+K) & hotkeys ─────
  const EN = "qwertyuiop[]asdfghjkl;'zxcvbnm,.`", RU = "йцукенгшщзхъфывапролджэячсмитьбюё";
  const swapLayout = t => [...t].map(c => { const i = EN.indexOf(c), j = RU.indexOf(c); return i >= 0 ? RU[i] : j >= 0 ? EN[j] : c; }).join("");
  function openPalette() {
    const pal = $("#palette"), inp = $("#pal-input"), list = $("#pal-list");
    pal.hidden = false; inp.value = ""; inp.focus();
    let sel = 0, items = [];
    const draw = () => {
      // «build» finds «Билд» (the section id), «athv» typed in the wrong layout finds «фарм»
      const q = inp.value.toLowerCase().replace(/ё/g, "е"), qs = [q, swapLayout(q)];
      items = [...modules.map(m => ({label: m.title, hint: m.subtitle, id: m.id, run: () => show(m.id)})), ...commands]
        .filter(i => !q || qs.some(x => `${i.label} ${i.hint || ""} ${i.id || ""}`.toLowerCase().replace(/ё/g, "е").includes(x)));
      if (q.length > 3) items.push({label: `Спросить ассистента: «${inp.value}»`, hint: "Enter", run: () => { show("assistant"); registry.assistant?.ask?.(inp.value); }});
      sel = Math.min(sel, Math.max(0, items.length - 1));
      list.innerHTML = items.map((i, k) => `<div class="pal-item ${k === sel ? "sel" : ""}" data-k="${k}">${esc(i.label)}<span class="k">${esc(i.hint || "")}</span></div>`).join("");
      list.querySelectorAll(".pal-item").forEach(el => el.onclick = () => { close(); items[+el.dataset.k].run(); });
    };
    const close = () => { pal.hidden = true; };
    inp.oninput = () => { sel = 0; draw(); };
    inp.onkeydown = e => {
      if (e.key === "ArrowDown") { sel = Math.min(items.length - 1, sel + 1); draw(); e.preventDefault(); }
      else if (e.key === "ArrowUp") { sel = Math.max(0, sel - 1); draw(); e.preventDefault(); }
      else if (e.key === "Enter") { close(); items[sel]?.run(); }
      else if (e.key === "Escape") close();
    };
    pal.onclick = e => { if (e.target === pal) close(); };
    draw();
  }
  document.addEventListener("keydown", e => {
    // the physical key: with the Russian layout e.key is «л» and Ctrl+K did nothing
    if ((e.ctrlKey || e.metaKey) && e.code === "KeyK") { e.preventDefault(); openPalette(); }
    if (e.altKey && /^[0-9]$/.test(e.key)) { const m = modules.find(x => x.key === e.key); if (m) { e.preventDefault(); show(m.id); } }
  });
  $("#open-palette").onclick = openPalette;

  // a real link click: the app window hands it to the system browser, a plain window.open may be blocked
  function openExternal(url) {
    const a = document.createElement("a");
    a.href = url; a.target = "_blank"; a.rel = "noopener";
    document.body.appendChild(a); a.click(); a.remove();
  }

  // ───── cross-tab actions (used by action cards, audit findings, price check, plans…) ─────
  const actions = {
    async trade(spec) {
      toast("info", "Ищу на трейде…", (spec.mods || []).slice(0, 3).join(" · "));
      try {
        const r = await api.post("/api/price/link", spec);
        const s = r.summary || {};
        toast("ok", `Найдено ${fmt.n(r.total, "лот|лота|лотов")}${s.count ? ` · от ${fmt.ex(s.min_ex)} ex, обычно ~${fmt.ex(s.median_ex)} ex` : ""}`,
              r.skipped?.length ? `не нашёл фильтр для: ${r.skipped.join(", ")}` : "открываю трейд с фильтрами");
        openExternal(r.url);
      } catch (e) { toast("err", "Трейд", e.message); }
    },
    async craft(spec) { show("craft"); await new Promise(r => setTimeout(r, 300)); registry.craft?.target?.(spec); },
    async node(spec) {
      show("tree"); await new Promise(r => setTimeout(r, 300));
      if (window.P2.treeFocus) await window.P2.treeFocus(spec.name);
    },
    async upgrade(spec) { show("pob"); await new Promise(r => setTimeout(r, 300)); registry.pob?.upgrade?.(spec); },
    async watch(spec) {
      const title = await dialog({title: "Следить за предметом", text: "Тула раз в 10 минут проверяет трейд и сообщит о новом лоте не дороже лимита.",
        input: {value: `${spec.slot || spec.cls || "Предмет"}: ${(spec.mods || []).slice(0, 2).join(", ")}`}, ok: "Дальше"});
      if (title === null) return;
      const max = await dialog({title: "Максимальная цена", text: "Например «2 div» или «300 ex». Пусто — в пределах бюджета персонажа.",
        input: {value: spec.budget || "", placeholder: "2 div"}, ok: "Следить"});
      if (max === null) return;
      try { const w = await api.post("/api/price/watch", {title, spec, max_price: max});
        toast("ok", "Слежка включена", `${w.total == null ? "? подходящих лотов" : fmt.n(w.total, "подходящий лот|подходящих лота|подходящих лотов")} сейчас — сообщу о новых`); }
      catch (e) { toast("err", "Слежка", e.message); }
    },
    async build(spec) { show("build"); await new Promise(r => setTimeout(r, 300)); registry.build?.prefill?.(spec); },
  };
  document.addEventListener("click", e => {
    const b = e.target.closest("[data-p2act]");
    if (!b) return;
    e.preventDefault();
    let spec = {};
    try { spec = JSON.parse(b.dataset.spec || "{}"); } catch (_) {}
    actions[b.dataset.p2act]?.(spec);
  });

  // ───── assistant dock: a chat on EVERY tab that sees the tab, what's on screen, the character and the wallet ─────
  const dock = {sid: {}, open: false};
  function dockHtml() {
    return `<div class="dock-head"><b>✦ Ассистент</b><span class="muted small" id="dk-tab"></span><span class="spacer"></span>
        <button class="btn sm ghost" id="dk-new" title="Новый разговор на этой вкладке">↺</button><button class="btn sm ghost" id="dk-close">✕</button></div>
      <div class="dock-wallet"><span class="small muted">💰 Бюджет:</span><input class="inp" id="dk-amount" type="number" min="0" placeholder="—">
        <select class="inp" id="dk-cur"><option value="divine">Divine</option><option value="exalted">Exalted</option><option value="chaos">Chaos</option></select>
        <button class="btn sm" id="dk-save-budget">OK</button><span class="tiny faint" id="dk-who"></span></div>
      <div class="dock-msgs" id="dk-msgs"></div>
      <div class="chips" id="dk-chips" style="padding:0 10px"></div>
      <div class="composer" style="margin:0 10px 10px"><textarea id="dk-in" rows="1" placeholder="Спроси про то, что на этой вкладке…"></textarea>
        <button class="btn primary" id="dk-send">➤</button></div>`;
  }
  const DOCK_CHIPS = {
    _: ["Собери/улучши мой билд в рамках бюджета", "💰 Бюджет вырос — что поменять первым?", "Что на этой вкладке мне сделать прямо сейчас?"],
    price: ["Стоит ли продавать этот предмет и за сколько?", "Скрафтить такой же — дешевле, чем купить?"],
    craft: ["Самый дешёвый путь к этой цели?", "Крафтить или купить готовое?"],
    audit: ["Что исправить первым в рамках бюджета?", "Составь список покупок со ссылками"],
    tree: ["Какие 5 нод взять следующими?", "Что респекнуть?"],
    farm: ["Что фармить моим билдом с таким бюджетом?"],
    leveling: ["Что важно не пропустить в этом акте?"],
  };
  async function dockOpen() {
    let el = $("#dock");
    if (!el) { document.body.insertAdjacentHTML("beforeend", `<div id="dock" class="dock">${dockHtml()}</div>`); el = $("#dock"); wireDock(); }
    el.hidden = false; dock.open = true; $("#fab").hidden = true;
    await dockRefresh();
    $("#dk-in").focus();
  }
  async function dockRefresh() {
    const m = modules.find(x => x.id === current) || {};
    $("#dk-tab").textContent = `· ${m.title || ""}`;
    $("#dk-chips").innerHTML = [...(DOCK_CHIPS[current] || []), ...DOCK_CHIPS._].slice(0, 4).map(c => `<button>${esc(c)}</button>`).join("");
    $("#dk-chips").querySelectorAll("button").forEach(b => b.onclick = async () => {
      if (!b.textContent.startsWith("💰")) { dockSend(b.textContent); return; }
      // ask how much was added instead of assuming a number
      const amount = await dialog({title: "Сколько добавилось?", text: "Например 20 — валюту выберешь дальше.", input: {type: "number", placeholder: "сумма"}, ok: "Дальше"});
      if (!amount) return;
      const cur = await dialog({title: "Какая валюта?", input: {type: "select", value: "divine", options: [["divine", "Divine Orb"], ["exalted", "Exalted Orb"], ["chaos", "Chaos Orb"]]}, ok: "Спросить"});
      if (!cur) return;
      const names = {divine: "Divine", exalted: "Exalted", chaos: "Chaos"};
      dockSend(`У меня появилось ещё ${amount} ${names[cur]}. Что поменять или улучшить в первую очередь? Дай ссылки на трейд и крафт.`);
    });
    try {
      const d = await api.get("/api/character/profiles");
      const a = d.profiles.find(p => p.id === d.active);
      dock.who = a ? a.id : "";
      $("#dk-who").textContent = a ? `для ${a.name}` : "персонаж не выбран";
      $("#dk-amount").value = a?.budget_amount ?? ""; $("#dk-cur").value = a?.budget_currency || "divine";
    } catch (_) {}
    // one dock conversation per tab AND character: a chat answers for the character it was opened for (F52), so
    // after switching characters the old one would keep answering for the previous character
    const key = dockKey();
    const sid = dock.sid[key] || (() => { try { return localStorage.getItem(key); } catch (_) { return null; } })();
    dock.sid[key] = sid;
    const box = $("#dk-msgs");
    box.innerHTML = `<div class="faint small" style="padding:10px">Спрашивай про то, что открыто на вкладке — ассистент видит экран, твоего персонажа и бюджет, и отвечает готовыми решениями с кнопками «Трейд» и «Крафт».</div>`;
    if (sid) {
      try { const s = await api.get(`/api/sessions/${sid}`);
        box.innerHTML = s.messages.slice(-12).map(m => m.role === "user" ? `<div class="msg user">${esc(m.content.split("\n\nВОПРОС: ").pop().slice(0, 600))}</div>`
          : `<div class="msg ai"><div class="body md">${md(m.content)}</div></div>`).join("") || box.innerHTML;
        box.scrollTop = box.scrollHeight;
      } catch (_) { dock.sid[key] = null; }
    }
  }
  const dockKey = () => `p2dock_${current}_${dock.who || ""}`;
  // the assistant follows the tab: open while the player switches, it said «· Билд» on the craft tab and answered for it
  window.addEventListener("hashchange", () => { if (dock.open && $("#dock") && !$("#dock").hidden) setTimeout(dockRefresh, 50); });
  async function dockSession() {
    if (dock.sid[dockKey()]) return dock.sid[dockKey()];
    const c = await choices().catch(() => ({}));
    const m = modules.find(x => x.id === current) || {};
    const s = await api.post("/api/assistant/new", {title: `Вкладка «${m.title || current}»`, ...(c.main_build ? {file: c.main_build} : {})});
    dock.sid[dockKey()] = s.id;
    try { localStorage.setItem(dockKey(), s.id); } catch (_) {}
    return s.id;
  }
  async function dockSend(text) {
    text = (text || "").trim(); if (!text) return;
    $("#dk-in").value = "";
    const box = $("#dk-msgs");
    box.querySelector(".faint")?.remove();
    box.insertAdjacentHTML("beforeend", `<div class="msg user">${esc(text)}</div><div class="msg ai typing"><div class="body md"></div></div>`);
    const out = box.lastElementChild; box.scrollTop = box.scrollHeight;
    const m = modules.find(x => x.id === current) || {};
    const screen = (document.getElementById(`v-${current}`)?.innerText || "").replace(/\n{2,}/g, "\n").slice(0, 3500);
    const full = `[Вкладка «${m.title || current}». Что сейчас на экране:]\n${screen}\n\nВОПРОС: ${text}`;
    let acc = "";
    const sid = await dockSession();
    const toolsEl = document.createElement("div"); toolsEl.className = "agent-tools"; out.querySelector(".body").before(toolsEl);
    await stream(`/api/sessions/${sid}/chat`, {text: full}, {
      onTool: t => { toolsEl.insertAdjacentHTML("beforeend", `<span class="agent-tool">${esc(t)}</span>`); box.scrollTop = box.scrollHeight; },
      onText: t => { if (!acc) toolsEl.classList.add("done"); acc += t; out.querySelector(".body").innerHTML = md(acc); box.scrollTop = box.scrollHeight; },
      onReplace: t => { acc = t; out.querySelector(".body").innerHTML = md(acc); },
      onError: e => { out.querySelector(".body").innerHTML += `<p style="color:var(--red)">${esc(e)}</p>`; },
    });
    out.classList.remove("typing");
  }
  function wireDock() {
    $("#dk-close").onclick = () => { $("#dock").hidden = true; dock.open = false; $("#fab").hidden = false; };
    $("#dk-new").onclick = () => { dock.sid[dockKey()] = null; try { localStorage.removeItem(dockKey()); } catch (_) {} dockRefresh(); };
    $("#dk-send").onclick = () => dockSend($("#dk-in").value);
    $("#dk-in").onkeydown = e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); dockSend($("#dk-in").value); } };
    $("#dk-save-budget").onclick = async () => {
      try { await api.post("/api/character/budget", {amount: $("#dk-amount").value ? +$("#dk-amount").value : null, currency: $("#dk-cur").value});
        toast("ok", "Бюджет сохранён", "советы и поиск на трейде теперь в этих рамках"); }
      catch (e) { toast("err", "Бюджет", e.message); }
    };
  }
  document.body.insertAdjacentHTML("beforeend", `<button id="fab" class="fab" title="Ассистент по этой вкладке">✦</button>`);
  $("#fab").onclick = dockOpen;

  // header character/league switchers live in components.js (P2.headerRefresh)
  function refreshActive() { return window.P2 && window.P2.headerRefresh ? window.P2.headerRefresh() : null; }
  function rerender() { registry[current]?.onShow?.(); if (dock.open) dockRefresh(); }  // the dock follows a character switch

  // ───── help: «?» opens the instructions for the current tab ─────
  function helpHtml(key) {
    const h = (window.P2_HELP || {})[key];
    if (!h) return `<div class="muted">Для этой вкладки инструкции пока нет.</div>`;
    return `<div class="help-block"><h3 style="font-size:16px">${esc(h.title)}</h3>
      <div class="muted" style="margin:6px 0 12px">${esc(h.what || "")}</div>
      ${h.steps ? `<ol class="help-steps">${h.steps.map(s => `<li>${esc(s)}</li>`).join("")}</ol>` : ""}
      ${h.where ? `<div class="help-where">${h.where.map(([a, b]) => `<div><b>${esc(a)}:</b> ${esc(b)}</div>`).join("")}</div>` : ""}
      ${h.links ? `<div class="row" style="margin-top:10px">${h.links.map(([a, u]) => `<a class="btn sm" href="${esc(u)}" target="_blank">${esc(a)} ↗</a>`).join("")}</div>` : ""}
      ${h.tips ? `<div class="help-tips">${h.tips.map(t => `<div>💡 ${esc(t)}</div>`).join("")}</div>` : ""}</div>`;
  }
  function openHelp(key) {
    const wrap = document.createElement("div");
    wrap.className = "palette";
    wrap.innerHTML = `<div class="pal-box" style="width:min(640px,94vw);padding:20px;max-height:80vh;overflow:auto">${helpHtml(key)}
      <div class="row end" style="margin-top:14px"><button class="btn ghost" data-a="all">Вся инструкция</button><button class="btn primary" data-a="ok">Понятно</button></div></div>`;
    document.body.appendChild(wrap);
    const close = () => wrap.remove();
    wrap.onclick = e => { if (e.target === wrap) close(); };
    wrap.querySelector("[data-a=ok]").onclick = close;
    wrap.querySelector("[data-a=all]").onclick = () => { close(); show("help"); };
    wrap.tabIndex = -1; wrap.focus(); wrap.onkeydown = e => { if (e.key === "Escape") close(); };
  }
  $("#open-help").onclick = () => openHelp(current);

  // ───── «Проверить актуальность» ─────
  let freshTimer = null;
  async function drawFresh() {
    let s;
    try { s = await api.get("/api/update/full"); } catch (_) { return; }
    const stale = s.freshness.filter(r => r.stale).length;
    const chip = $("#chip-fresh");
    chip.className = `chip ${s.running ? "warn" : stale ? "warn" : "ok"}`;
    chip.querySelector("span").textContent = s.running ? "Обновляю…" : stale ? `Устарело: ${stale}` : "Всё актуально";
    if ($("#fresh").hidden) return s;
    const when = ts => ts ? fmt.ago(ts) : "—";
    $("#fresh-rows").innerHTML = s.freshness.map(r => `<tr><td>${esc(r.name)}${r.count ? ` <span class="faint tiny">${r.count}</span>` : ""}${r.note ? ` <span class="tiny faint">${esc(r.note)}</span>` : ""}</td>
      <td class="small muted">${when(r.updated)}</td><td>${r.stale ? `<span class="tag amber">устарело</span>` : `<span class="tag green">актуально</span>`}</td></tr>`).join("");
    $("#fresh-steps").innerHTML = (s.steps || []).length ? `<div style="margin-bottom:12px">${s.steps.map(st => `<div class="row small" style="padding:3px 0">
      ${st.status === "running" ? `<span class="spin" style="width:12px;height:12px;border:2px solid var(--line2);border-top-color:var(--accent2);border-radius:50%;animation:spin .7s linear infinite"></span>` : st.status === "ok" ? `<span class="up">✓</span>` : `<span class="down">✗</span>`}
      <span>${esc(st.name)}</span><span class="spacer"></span><span class="faint tiny">${st.seconds != null ? st.seconds + " с" : ""} ${esc(st.result || "")}</span></div>`).join("")}</div>` : "";
    $("#fresh-run").disabled = s.running;
    $("#fresh-run").textContent = s.running ? "Обновляю…" : "Обновить всё сейчас";
    clearTimeout(freshTimer);
    if (s.running) freshTimer = setTimeout(drawFresh, 1500);
    return s;
  }
  $("#chip-fresh").onclick = () => { $("#fresh").hidden = false; drawFresh(); };
  $("#fresh-close").onclick = () => { $("#fresh").hidden = true; };
  $("#fresh").onclick = e => { if (e.target.id === "fresh") $("#fresh").hidden = true; };
  $("#fresh-run").onclick = async () => { await api.post("/api/update/full"); toast("info", "Обновляю всё", "можно продолжать работу — прогресс в этом окне"); drawFresh(); };
  setInterval(drawFresh, 120000);
  setTimeout(drawFresh, 3000);
  window.addEventListener("hashchange", () => { const id = location.hash.slice(1); if (id && id !== current) show(id); });
  $("#railtoggle").onclick = () => { $("#side").classList.toggle("collapsed"); try { localStorage.setItem("p2rail", $("#side").classList.contains("collapsed") ? "1" : "0"); } catch (_) {} };
  try { if (localStorage.getItem("p2rail") === "1") $("#side").classList.add("collapsed"); } catch (_) {}
  // the tool fits the window it's in: a narrow window folds the menu into icons (unless the player opened it by hand)
  // and below the width the tabs are laid out for, the whole page scales down a little — nothing is cut at the edge
  const FIT_W = 1280, FIT_H = 760, MIN_ZOOM = 0.8;
  function fitWindow() {
    const w = window.innerWidth;  // the window's width: the page's zoom doesn't change it
    let manual = null;
    try { manual = localStorage.getItem("p2rail"); } catch (_) {}
    if (manual === null) $("#side").classList.toggle("collapsed", w < 1200);
    // by height too: the menu with every tab needs about FIT_H; a low window scales down a little as well
    fitZoom = Math.max(MIN_ZOOM, Math.min(1, w / FIT_W, window.innerHeight / FIT_H));
    applyZoom();
  }
  window.addEventListener("resize", () => { clearTimeout(fitWindow.t); fitWindow.t = setTimeout(fitWindow, 120); });
  fitWindow();
  $("#livecard").onclick = () => show("character");
  async function renderAccount() {
    try {
      const a = await api.get("/api/character/account");
      const s = a.steam, g = a.ggg || {};
      $("#lc-av").innerHTML = s && s.avatar ? `<img src="/api/character/account/avatar" alt="">` : `<b>${esc(((s && s.name) || g.account || "?")[0].toUpperCase())}</b>`;
      $("#lc-name").textContent = s ? s.name : (g.account || "Аккаунт не подключён");
      $("#lc-acc").innerHTML = g.connected
        ? `<span class="${g.need_login ? "warn" : "ok"}">${g.need_login ? "⚠" : "●"}</span> GGG: ${esc(g.account || "подключён")}${g.need_login ? " · нужен вход" : ""}`
        : `<span class="warn">○</span> GGG не подключён`;
    } catch (_) {}
  }
  renderAccount();
  setInterval(renderAccount, 60000);

  window.P2 = {api, lane, evTime, toast, stream, md, esc, fmt, itemCard, spinBtn, assistantPanel, dialog,
    current: () => current, choices, selectHtml, wireSelects, selectValue, sourcePicker, sourceValue, helpHtml, openHelp, refreshActive, rerender, actions, registerModule, registerCommand, go, openSession, t, applyPrefs, prefs: () => prefs,
    onLive: f => { liveSubs.push(f); f(liveState); }, live: () => liveState, setBusy};
  boot().catch(e => toast("err", "Не удалось загрузить интерфейс", e.message));
})();
