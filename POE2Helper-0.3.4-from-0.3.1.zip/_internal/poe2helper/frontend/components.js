/* POE2 Helper — shared rich components on top of window.P2:
   popover, picker (searchable dropdown with icons), gem/class pickers, header character + league switchers,
   «add character» wizard. Loaded after app.js. */
(function () {
  "use strict";
  const P2 = window.P2;
  const {api, esc, toast} = P2;
  const $ = (s, r = document) => r.querySelector(s);

  // ───── popover anchored to an element; closes on outside click / Escape ─────
  let openPop = null;
  function popover(anchor, html, o = {}) {
    closePopover();
    const el = document.createElement("div");
    el.className = "p2-pop";
    el.innerHTML = html;
    document.body.appendChild(el);
    const r = anchor.getBoundingClientRect();
    const w = o.width || Math.max(r.width, 280);
    el.style.width = w + "px";
    const left = Math.min(Math.max(8, o.alignRight ? r.right - w : r.left), window.innerWidth - w - 8);
    el.style.left = left + "px";
    const below = window.innerHeight - r.bottom;
    if (below < 320 && r.top > below) { el.style.bottom = (window.innerHeight - r.top + 6) + "px"; el.style.maxHeight = (r.top - 16) + "px"; }
    else { el.style.top = (r.bottom + 6) + "px"; el.style.maxHeight = (below - 16) + "px"; }
    const onDoc = e => { if (!el.contains(e.target) && !anchor.contains(e.target)) closePopover(); };
    const onKey = e => { if (e.key === "Escape") closePopover(); };
    setTimeout(() => { document.addEventListener("mousedown", onDoc); document.addEventListener("keydown", onKey); });
    openPop = {el, close: () => { document.removeEventListener("mousedown", onDoc); document.removeEventListener("keydown", onKey); el.remove(); openPop = null; o.onClose && o.onClose(); }};
    return openPop;
  }
  function closePopover() { if (openPop) openPop.close(); }

  // ───── picker: a button that opens a searchable, grouped list with icons ─────
  // items: [{value, label, sub, icon, group, color, tags:[], search}]
  const COLOR = {red: "#f87171", green: "#4ade80", blue: "#60a5fa", white: "#e5e7eb"};
  function iconHtml(it, size = 26) {
    if (it.icon) return `<img class="pk-ic" src="${esc(it.icon)}" width="${size}" height="${size}" loading="lazy" alt="" onerror="this.style.visibility='hidden'">`;
    if (it.emoji) return `<span class="pk-ic pk-emo" style="width:${size}px;height:${size}px">${it.emoji}</span>`;
    return `<span class="pk-ic pk-dot" style="width:${size}px;height:${size}px;--c:${COLOR[it.color] || "var(--accent2)"}"></span>`;
  }
  function rowHtml(it, sel) {
    return `<div class="pk-row ${sel ? "sel" : ""}" data-v="${esc(it.value)}">${iconHtml(it)}
      <div class="pk-txt"><b>${esc(it.label)}</b>${it.sub ? `<span>${esc(it.sub)}</span>` : ""}
      ${(it.tags || []).length ? `<div class="pk-tags">${it.tags.slice(0, 5).map(t => `<i>${esc(t)}</i>`).join("")}</div>` : ""}</div>
      ${it.badge ? `<span class="tag ${esc(it.badgeClass || "")}">${esc(it.badge)}</span>` : ""}</div>`;
  }
  function picker(el, o) {
    let items = o.items || [], value = o.value ?? "";
    el.classList.add("pk-btn");
    el.type = "button";
    const draw = () => {
      const it = items.find(x => String(x.value) === String(value));
      el.dataset.value = value ?? "";
      el.innerHTML = it ? `${iconHtml(it, 20)}<span class="pk-cur">${esc(it.label)}${it.sub && o.showSub !== false ? `<small>${esc(it.sub)}</small>` : ""}</span><span class="pk-caret">▾</span>`
        : `<span class="pk-cur muted">${esc(o.placeholder || "— выбери —")}</span><span class="pk-caret">▾</span>`;
    };
    el.onclick = () => {
      const pop = popover(el, `${o.search !== false ? `<input class="inp pk-q" placeholder="${esc(o.searchPlaceholder || "Поиск…")}">` : ""}
        <div class="pk-list"></div>${(o.footer || []).length ? `<div class="pk-foot">${o.footer.map((f, i) => `<button class="btn sm ghost" data-f="${i}">${esc(f.label)}</button>`).join("")}</div>` : ""}`,
        {width: o.width});
      const list = pop.el.querySelector(".pk-list"), q = pop.el.querySelector(".pk-q");
      const render = () => {
        const s = (q?.value || "").trim().toLowerCase();
        const hit = items.filter(it => !s || (it.search || [it.label, it.sub, ...(it.tags || [])].join(" ")).toLowerCase().includes(s));
        const shown = hit.slice(0, o.limit || 300);
        let html = "", grp = null;
        if (o.allowEmpty) html += rowHtml({value: "", label: o.emptyLabel || "— не выбрано —", emoji: "∅"}, value === "");
        for (const it of shown) {
          if (it.group && it.group !== grp) { grp = it.group; html += `<div class="pk-grp">${esc(grp)}</div>`; }
          html += rowHtml(it, String(it.value) === String(value));
        }
        if (!shown.length) html += `<div class="pk-empty">Ничего не найдено${o.custom && s ? ` — <a href="#" class="pk-custom">использовать «${esc(q.value)}»</a>` : ""}</div>`;
        if (hit.length > shown.length) html += `<div class="pk-empty">…ещё ${hit.length - shown.length}, уточни поиск</div>`;
        list.innerHTML = html;
        list.querySelectorAll(".pk-row").forEach(r => r.onclick = () => choose(r.dataset.v));
        list.querySelector(".pk-custom")?.addEventListener("click", e => { e.preventDefault(); items = [...items, {value: q.value.trim(), label: q.value.trim()}]; choose(q.value.trim()); });
        list.querySelector(".pk-row.sel")?.scrollIntoView({block: "nearest"});
      };
      const choose = v => { value = v; draw(); pop.close(); o.onChange && o.onChange(v, items.find(x => String(x.value) === String(v))); };
      pop.el.querySelectorAll("[data-f]").forEach(b => b.onclick = () => { pop.close(); o.footer[+b.dataset.f].run(); });
      if (q) { q.oninput = render; q.focus();
        q.onkeydown = e => { if (e.key === "Enter") { const first = list.querySelector(".pk-row:not([data-v=''])") || list.querySelector(".pk-row"); if (first) choose(first.dataset.v); } }; }
      render();
    };
    draw();
    return {get value() { return value; }, set(v) { value = v; draw(); }, setItems(x) { items = x; draw(); }, el};
  }
  const pickerValue = el => (el && el.dataset.value) || "";

  // ───── avatars: the in-game portrait of the class / ascendancy (PoE2DB art) ─────
  function avatar(p, size = 34) {
    const letter = esc(((p && p.name) || "?")[0]);
    const st = `width:${size}px;height:${size}px;font-size:${Math.round(size * 0.42)}px`;
    return p && p.portrait ? `<span class="cc-av img" style="${st}"><img src="${esc(p.portrait)}" alt="" onerror="this.parentNode.textContent='${letter}'"></span>`
      : `<span class="cc-av" style="${st}">${letter}</span>`;
  }

  // ───── gem / class pickers ─────
  async function gemItems(kind) {
    const c = await P2.choices();
    return (c.gems_rich || []).filter(g => !kind || kind === "all" || g.kind === kind || (kind === "skill" && g.kind === "spirit"))
      .sort((a, b) => (a.req || 99) - (b.req || 99) || a.ru.localeCompare(b.ru, "ru"))
      .map(g => ({value: g.en, label: g.ru, sub: g.ru !== g.en ? g.en : "", icon: g.icon, color: g.color, tags: g.tags,
        group: {skill: "Камни умений", support: "Камни поддержки", spirit: "Камни духа"}[g.kind] || "",
        search: [g.ru, g.en, ...(g.tags || [])].join(" ")}));
  }
  async function gemPicker(el, o = {}) {
    return picker(el, {...o, items: await gemItems(o.kind || "skill"), placeholder: o.placeholder || "Выбери скилл…",
      searchPlaceholder: "Название (рус/англ) или тег: ветер, проекция, огонь…", custom: true, width: 420});
  }
  async function classItems(o = {}) {
    const c = await P2.choices();
    const out = [];
    for (const cl of c.classes) {
      if (o.base !== false) out.push({value: cl.name, label: cl.ru || cl.name, sub: `${cl.name} · без восхождения`, group: cl.ru || cl.name,
        icon: cl.portrait, emoji: "⚔"});
      cl.asc.forEach((a, i) => out.push({value: a, label: cl.asc_ru[i] || a, sub: `${a} · ${cl.ru || cl.name}`, group: cl.ru || cl.name,
        icon: (cl.asc_portrait || [])[i], emoji: "✦"}));
    }
    return out;
  }
  async function currencyPicker(el, o = {}) {
    const c = await P2.choices();
    const ic = c.currency_icons || {};
    return picker(el, {...o, search: false, width: 220, showSub: false, items: [
      {value: "divine", label: "Divine Orb", sub: "div", icon: ic.divine, emoji: "🟡"},
      {value: "exalted", label: "Exalted Orb", sub: "ex", icon: ic.exalted, emoji: "🔷"},
      {value: "chaos", label: "Chaos Orb", sub: "chaos", icon: ic.chaos, emoji: "🔴"}], value: o.value || "divine"});
  }
  async function classPicker(el, o = {}) {
    return picker(el, {...o, items: await classItems(o), placeholder: o.placeholder || "Класс / восхождение…", width: 360});
  }

  // ───── header: character switcher + league switcher ─────
  let PROF = null;
  const curName = {divine: "div", exalted: "ex", chaos: "chaos"};
  function charLabel(p) { return [p.ascendancy_ru || p.class_ru || p.ascendancy || p.class, p.level ? `${p.level} ур.` : ""].filter(Boolean).join(" · "); }
  async function headerRefresh() {
    try { PROF = await api.get("/api/character/profiles"); } catch (_) { return; }
    const act = PROF.profiles.find(p => p.id === PROF.active);
    const chip = $("#chip-char");
    chip.innerHTML = act ? `${avatar(act, 30)}<span class="cc-txt"><b>${esc(act.name)}</b><small>${esc(charLabel(act))}${act.playing ? " · ▶ в игре" : ""}</small></span><span class="pk-caret">▾</span>`
      : `<span class="cc-av">+</span><span class="cc-txt"><b>Персонаж</b><small>не выбран</small></span>`;
    chip.classList.toggle("playing", !!(act && act.playing));
  }
  function charMenu() {
    if (!PROF) return;
    const leagues = ["", ...new Set(PROF.profiles.map(p => p.league || "").filter(Boolean))];
    let filter = localStorageGet("p2charLeague") || "";
    const pop = popover($("#chip-char"), `<div class="row" style="padding:4px 4px 8px"><b>Персонажи</b><span class="spacer"></span>
        ${leagues.length > 1 ? `<select class="inp" id="cm-league" style="width:auto;padding:4px 8px">${leagues.map(l => `<option value="${esc(l)}" ${l === filter ? "selected" : ""}>${esc(l || "все лиги")}</option>`).join("")}</select>` : ""}</div>
      ${PROF.ggg && !PROF.ggg.connected ? `<div class="kb gem" style="margin:0 0 6px"><span class="ki">🔗</span><div class="kt"><b class="kh">Все персонажи по лигам</b>
        Подключи аккаунт pathofexile.com — появятся все твои персонажи с лигами, шмотом и древом.
        <div style="margin-top:6px"><button class="btn sm primary" id="cm-ggg">Подключить аккаунт</button></div></div></div>` : ""}
      <div class="pk-list" id="cm-list"></div>
      <div class="pk-foot" style="flex-wrap:wrap">
        <button class="btn sm primary" id="cm-add">+ Добавить</button><button class="btn sm" id="cm-sync">⟳ Обновить</button>
        <label class="small row" style="gap:6px;margin-left:auto"><input type="checkbox" id="cm-follow" ${PROF.auto_follow ? "checked" : ""}> следовать за игрой</label>
        <button class="btn sm ghost" id="cm-manage" style="width:100%">⚙ Управлять персонажами</button></div>`, {width: 380, alignRight: true});
    const draw = () => {
      const rows = PROF.profiles.filter(p => !filter || p.league === filter);
      pop.el.querySelector("#cm-list").innerHTML = rows.map(p => `<div class="pk-row ${p.id === PROF.active ? "sel" : ""}" data-v="${p.id}">
          ${avatar(p, 36)}<div class="pk-txt"><b>${esc(p.name)}${p.playing ? ` <span class="tag green">▶ в игре</span>` : ""}</b>
          <span>${esc(charLabel(p))}${p.league ? " · " + esc(p.league) : ""}</span>
          <div class="pk-tags">${(p.sources || []).map(s => `<i>${esc({log: "лог игры", ggg: "аккаунт", pob: "PoB"}[s] || s)}</i>`).join("")}${p.build_file ? "<i>есть билд PoB</i>" : ""}${p.budget_amount ? `<i>💰 ${p.budget_amount} ${curName[p.budget_currency] || ""}</i>` : ""}</div></div></div>`).join("")
        || `<div class="pk-empty">Нет персонажей${filter ? " в этой лиге" : ""}. Нажми «+ Добавить».</div>`;
      pop.el.querySelectorAll("#cm-list .pk-row").forEach(r => r.onclick = async () => { pop.close(); await activate(r.dataset.v); });
    };
    draw();
    pop.el.querySelector("#cm-league")?.addEventListener("change", e => { filter = e.target.value; localStorageSet("p2charLeague", filter); draw(); });
    pop.el.querySelector("#cm-add").onclick = () => { pop.close(); addCharacter(); };
    pop.el.querySelector("#cm-ggg")?.addEventListener("click", () => { pop.close(); addCharacter("ggg"); });
    pop.el.querySelector("#cm-manage").onclick = () => { pop.close(); P2.go("character"); };
    pop.el.querySelector("#cm-follow").onchange = async e => { await api.post("/api/character/follow", {on: e.target.checked}); PROF.auto_follow = e.target.checked;
      toast("ok", e.target.checked ? "Тула переключается сама на персонажа, которым ты играешь" : "Автопереключение выключено"); };
    pop.el.querySelector("#cm-sync").onclick = async e => { const b = e.currentTarget; P2.spinBtn(b, true);
      try { const r = await api.post("/api/character/profiles/sync"); toast("ok", "Персонажи обновлены", r.ggg ? `аккаунт: ${r.ggg.characters} перс.` : "из лога игры"); }
      catch (err) { toast("err", "Обновление", err.message); }
      P2.spinBtn(b, false); await headerRefresh(); draw(); };
  }
  async function activate(id) {
    const r = await api.post(`/api/character/profiles/${id}/activate`);
    toast("ok", `Играю: ${r.active.name}`, "вся тула подстроилась: советы, цены лиги, билд, древо");
    await afterCharChange();
  }
  async function afterCharChange() {
    await P2.choices(true);
    await headerRefresh();
    P2.rerender && P2.rerender();
    refreshLeagueChip();
  }
  $("#chip-char").onclick = charMenu;

  async function refreshLeagueChip() {
    try { const s = await api.get("/api/status"); const lg = $("#chip-league"); lg.className = `chip ${s.league ? "ok" : "warn"}`; lg.querySelector("span").textContent = s.league || "лига ?"; } catch (_) {}
  }
  $("#chip-league").style.cursor = "pointer";
  $("#chip-league").onclick = async () => {
    const [c, env] = await Promise.all([P2.choices(), api.get("/api/settings/env").catch(() => ({}))]);
    const cur = env.POE_LEAGUE || "";
    const items = [{value: "", label: "Авто", sub: "лига активного персонажа или текущая лига", emoji: "✦"},
      ...c.leagues.map(l => ({value: l, label: l, sub: /HC|Hardcore/.test(l) ? "хардкор" : l === "Standard" ? "постоянная" : "лига", emoji: /HC|Hardcore/.test(l) ? "☠" : "⚔"}))];
    const pop = popover($("#chip-league"), `<div class="small muted" style="padding:4px 6px 8px">Лига для цен, трейда и мета-данных</div><div class="pk-list">${items.map(it => rowHtml(it, it.value === cur)).join("")}</div>`, {width: 300, alignRight: true});
    pop.el.querySelectorAll(".pk-row").forEach(r => r.onclick = async () => {
      pop.close();
      const league = r.dataset.v;
      // a league with my character in it = switch to that character (the league follows the character)
      const d = league ? await api.get("/api/character/profiles").catch(() => null) : null;
      const mine = d && d.profiles.filter(p => p.league === league).sort((a, b) => (b.last_active || 0) - (a.last_active || 0) || (b.level || 0) - (a.level || 0))[0];
      if (mine) {
        await api.post(`/api/character/profiles/${mine.id}/activate`);
        toast("ok", `Лига: ${league}`, `переключился на ${mine.name} — цены и трейд этой лиги`);
      } else {
        await api.post("/api/settings/env", {values: {POE_LEAGUE: league}});
        toast("ok", "Лига: " + (league || "авто"), league ? "персонажа в этой лиге нет — смотрю цены и трейд лиги" : "лига активного персонажа");
      }
      await afterCharChange();
    });
  };

  // ───── «add character» wizard ─────
  const localStorageGet = k => { try { return localStorage.getItem(k); } catch (_) { return null; } };
  const localStorageSet = (k, v) => { try { localStorage.setItem(k, v); } catch (_) {} };
  function modal(title, html, width = 640) {
    const wrap = document.createElement("div");
    wrap.className = "palette";
    wrap.innerHTML = `<div class="pal-box" style="width:min(${width}px,94vw);padding:18px;max-height:88vh;overflow:auto">
      <div class="row"><h3 style="margin:0;font-size:16px">${esc(title)}</h3><span class="spacer"></span><button class="btn ghost sm" data-x>✕</button></div>
      <div class="m-body" style="margin-top:12px">${html}</div></div>`;
    document.body.appendChild(wrap);
    const close = () => wrap.remove();
    wrap.querySelector("[data-x]").onclick = close;
    wrap.onclick = e => { if (e.target === wrap) close(); };
    return {el: wrap.querySelector(".m-body"), close};
  }


  // ───── deep build analysis block (all numbers measured in PoB) — used by «Анализ билда» and «Текущий билд» ─────
  function deepHtml(d, whose) {
    if (!d) return "";
    const n = v => (v == null || !isFinite(v)) ? "—" : Math.abs(v) >= 1000 ? Math.round(v).toLocaleString("ru") : (+v).toFixed(v < 10 ? 1 : 0);
    const o = d.offense, df = d.defence, r = d.resources;
    const sens = (d.sensitivity || []).slice().sort((a, b) => (b.dps + b.ehp) - (a.dps + a.ehp));
    const top = sens.filter(x => x.dps + x.ehp > 0.3).slice(0, 10), useless = sens.filter(x => x.group !== "util" && Math.abs(x.dps) + Math.abs(x.ehp) < 0.3);
    const maxv = Math.max(1, ...top.map(x => Math.max(x.dps, x.ehp)));
    const bar = (v, cls) => `<i class="dp-bar ${cls}" style="width:${Math.max(2, Math.min(100, v / maxv * 100))}%"></i>`;
    const hits = Object.entries(df.max_hits || {}), hmax = Math.max(1, ...hits.map(h => h[1]));
    const SEV = {critical: "warn", warn: "info", info: "gem"};
    const cap = df.res_cap || 75, res = df.res || {}, oc = df.overcap || {};
    const RES_RU = {Fire: "Огонь", Cold: "Холод", Lightning: "Молния", Chaos: "Хаос"};
    const resRow = el => res[el] == null ? "" : `<div class="dp-kv"><span>${RES_RU[el]}</span><b class="${res[el] >= cap ? "up" : el === "Chaos" ? "" : "down"}">${n(res[el])}%${
      el !== "Chaos" && res[el] >= cap && oc[el] != null ? ` <span class="tiny faint">перекап ${n(oc[el])}%</span>` : el !== "Chaos" && res[el] < cap ? ` <span class="tiny">не хватает ${n(cap - res[el])}%</span>` : ""}</b></div>`;
    return `<div class="card dp" style="margin-top:12px"><div class="sec-h" style="--k:var(--k-info)"><span class="si">🔬</span><div><h3>Глубокий разбор${whose ? " " + esc(whose) : ""}</h3>
        <div class="sd">всё измерено в Path of Building на этом билде: ~20 проб усиления, вклад каждого мода, слои защиты, ресурсы</div></div></div>
      <div class="dp-cols" style="margin-bottom:10px">
        <div class="dp-box"><div class="bv-sgh" style="--k:var(--k-gem)">🧱 Резисты (кап ${cap}%)</div>${["Fire", "Cold", "Lightning", "Chaos"].map(resRow).join("")}</div>
        <div class="dp-box"><div class="bv-sgh" style="--k:var(--k-reward)">❤ Запас</div>
          <div class="dp-kv"><span>Жизнь</span><b>${n(df.life)}</b></div><div class="dp-kv"><span>Энергощит</span><b>${n(df.es)}</b></div>
          <div class="dp-kv"><span>Мана</span><b>${n(df.mana)}</b></div>${r.survival_time ? `<div class="dp-kv"><span>Продержишься под уроном босса</span><b>${n(r.survival_time)} с</b></div>` : ""}</div>
        <div class="dp-box"><div class="bv-sgh" style="--k:var(--k-item)">🛡 Слои</div>
          <div class="dp-kv"><span>Броня</span><b>${n(df.armour)} (−${n(df.phys_red)}% физ.)</b></div>
          <div class="dp-kv"><span>Уклонение</span><b>${n(df.evasion)} (${n(df.evade)}%)</b></div>
          <div class="dp-kv"><span>Отражение / блок</span><b>${n(df.deflect)}% / ${n(df.block)}%</b></div>
          ${df.spell_block ? `<div class="dp-kv"><span>Блок чар</span><b>${n(df.spell_block)}%</b></div>` : ""}</div>
      </div>
      <div class="dp-cols">
        <div class="dp-box"><div class="bv-sgh" style="--k:var(--k-item)">⚔ Урон</div>
          <div class="dp-kv"><span>DPS</span><b>${n(o.dps)}</b></div><div class="dp-kv"><span>Средний удар</span><b>${n(o.hit)}</b></div>
          <div class="dp-kv"><span>Скорость</span><b>${n(o.speed)}/с</b></div><div class="dp-kv"><span>Крит</span><b>${n(o.crit_chance)}% ×${(+o.crit_multi || 0).toFixed(2)}</b></div>
          <div class="dp-kv"><span>Попадание</span><b>${n(o.hit_chance)}%</b></div>${o.dot ? `<div class="dp-kv"><span>Урон со временем</span><b>${n(o.dot)}</b></div>` : ""}</div>
        <div class="dp-box"><div class="bv-sgh" style="--k:var(--k-gem)">🛡 Защита — что убьёт первым</div>
          ${hits.map(([t, v]) => `<div class="dp-hit ${t === df.weakest ? "weak" : ""}"><span>${esc(t)}</span><div class="bv-bar"><i style="width:${v / hmax * 100}%"></i></div><b>${n(v)}</b></div>`).join("")}
          <div class="dp-kv"><span>EHP</span><b>${n(df.ehp)}</b></div>
          <div class="dp-kv"><span>Броня / уклонение / отражение</span><b>−${n(df.phys_red)}% · ${n(df.evade)}% · ${n(df.deflect)}%</b></div>
          ${df.block ? `<div class="dp-kv"><span>Блок</span><b>${n(df.block)}%</b></div>` : ""}</div>
        <div class="dp-box"><div class="bv-sgh" style="--k:var(--k-act)">⚡ Ресурсы и восстановление</div>
          <div class="dp-kv"><span>Мана: трата / реген</span><b>${n(r.mana_use)} / ${n(r.mana_regen)} в с</b></div>
          ${r.mana_lasts ? `<div class="dp-kv"><span>Мана кончится через</span><b class="down">${n(r.mana_lasts)} с</b></div>` : ""}
          ${r.spirit_free != null ? `<div class="dp-kv"><span>Свободный дух</span><b class="${r.spirit_free < 0 ? "down" : ""}">${n(r.spirit_free)}</b></div>` : ""}
          <div class="dp-kv"><span>Реген жизни / ES recharge</span><b>${n(r.life_regen)} / ${n(r.es_recharge)}</b></div>
          <div class="dp-kv"><span>Скорость бега</span><b>${r.move ? "+" + n((r.move - 1) * 100) + "%" : "—"}</b></div></div>
      </div>
      ${d.weapon_sets ? `<div class="bv-sgh" style="--k:var(--k-item);margin-top:10px">⚔ Наборы оружия</div>
        ${d.weapon_roles ? d.weapon_roles.sets.map(w => `<div class="row small" style="gap:8px;margin:3px 0"><span>Набор ${w.set}: <b>${esc(w.weapon || w.base)}</b></span>
          <select class="inp dp-role" style="width:auto;padding:2px 6px" data-key="${esc(d.weapon_roles.key)}" data-set="${w.set}">${[["damage", "основной урон"], ["speed", "скорость и перемещение"], ["utility", "вспомогательный"]].map(([v, l]) => `<option value="${v}" ${v === w.role ? "selected" : ""}>${l}</option>`).join("")}</select>
          <span class="tiny faint">${esc(w.why)} · EHP ${n(w.ehp)} · пассивок ${w.points}</span></div>`).join("") : ""}
        <table class="tbl"><thead><tr><th>Скилл</th><th class="num">Набор 1: DPS</th><th class="num">крит</th><th class="num">скорость</th><th class="num">Набор 2: DPS</th><th class="num">крит</th><th class="num">скорость</th></tr></thead><tbody>${d.weapon_sets.skills.map(r => { const c = x => x ? `<td class="num">${n(x.dps)}</td><td class="num">${x.crit}%</td><td class="num">${x.speed}/с</td>` : `<td class="num faint">—</td><td></td><td></td>`; return `<tr><td>${esc(r.skill)}</td>${c(r.set1)}${c(r.set2)}</tr>`; }).join("")}</tbody></table>` : ""}
      ${(d.weapon_passives || []).map(w => `<div class="small" style="margin-top:6px"><b>Пассивки набора ${w.set}</b> <span class="muted">(${esc(w.role_ru)}, замер по: ${esc(w.metric)}, ${w.points} оч.)</span>
          <div class="tiny muted">${w.worn.slice(0, 8).map(x => `${esc(x.ru)} ${x.gain >= 0 ? "+" : ""}${x.gain}%`).join(" · ") || "значимых нод нет"}</div>
          ${w.better.length ? `<div class="tiny up">взять: ${w.better.map(x => `${esc(x.ru)} ${x.gain >= 0 ? "+" : ""}${x.gain}% за ${x.cost} оч.`).join(" · ")}</div>` : ""}</div>`).join("")}
      <div class="grid g2" style="margin-top:10px">
        <div><div class="bv-sgh" style="--k:var(--k-reward)">📈 Что сильнее всего усилит этот билд</div>
          ${top.map(x => `<div class="dp-sens"><span>${esc(x.label)}</span><div class="dp-bars">${x.dps > 0 ? bar(x.dps, "dmg") : ""}${x.ehp > 0 ? bar(x.ehp, "def") : ""}</div>
            <b>${x.dps > 0 ? `<span class="up">DPS +${x.dps}%</span>` : ""}${x.dps > 0 && x.ehp > 0 ? " · " : ""}${x.ehp > 0 ? `<span style="color:#7dd3fc">EHP +${x.ehp}%</span>` : ""}</b></div>`).join("") || `<div class="faint small">Ни одна проба заметно не усиливает — билд упёрся в другое (см. ниже).</div>`}
          ${useless.length ? `<div class="small muted" style="margin-top:6px">Почти бесполезно для этого билда: ${useless.map(x => esc(x.label)).join(" · ")}</div>` : ""}</div>
        <div><div class="bv-sgh" style="--k:var(--k-item)">🧩 Самые слабые моды на предметах</div>
          ${(d.weak_mods || []).map(w => `<div class="kb ${w.corrupted ? "skip" : "act"}" style="margin:4px 0"><span class="ki">${w.corrupted ? "🔒" : "↻"}</span><div class="kt">
            <b>${esc(w.slot)} «${esc(w.name)}»</b>: «${esc(w.weakest.mod_ru || w.weakest.mod)}» даёт ${w.weakest.dps + w.weakest.ehp < 3 ? "всего " : ""}DPS ${w.weakest.dps >= 0 ? "+" : ""}${w.weakest.dps}% / EHP ${w.weakest.ehp >= 0 ? "+" : ""}${w.weakest.ehp}%
            ${w.weakest.needed_for && w.weakest.needed_for.length ? ` <span class="pill warn">нужен для: ${w.weakest.needed_for.map(esc).join(", ")}</span>` : ""}
            ${w.corrupted ? `<div class="tiny faint">предмет осквернён — менять моды нельзя</div>` : w.instead ? `<div class="tiny" style="color:#a5f3fc">заменить на полезное: лучшая проба — ${esc(w.instead)}</div>` : ""}</div></div>`).join("") || `<div class="faint small">Нет редких предметов для разбора.</div>`}
          ${(d.open_affixes || []).length ? `<div class="bv-sgh" style="--k:var(--k-money);margin-top:8px">➕ Свободные аффиксы</div>${d.open_affixes.map(a => `<div class="kb money" style="margin:4px 0"><span class="ki">＋</span><div class="kt"><b>${esc(a.slot)} «${esc(a.name)}»</b>: свободно ${Object.entries(a.free).map(([s, k]) => `${k} ${s === "prefix" ? "префикс" : "суффикс"}`).join(", ")}
            ${a.hints.map(h => `<div class="tiny">→ ${esc(h.family)} (${esc(h.gain)}${h.chance ? `, шанс среди ${h.side === "prefix" ? "префиксов" : "суффиксов"} ${h.chance}%` : ""})</div>`).join("")}</div></div>`).join("")}` : ""}</div>
      </div>
      ${d.gems && d.gems.supports.length ? `<div class="bv-sgh" style="--k:var(--k-gem);margin-top:10px">💎 Поддержки основного скилла «${esc(d.gems.skill)}» — что реально даёт каждая (PoB)</div>
        <div class="dp-gems">${d.gems.supports.map(s => `<div class="kb ${s.better ? "warn" : s.clear ? "info" : s.dps < 2 ? "skip" : "node"}" style="margin:3px 0"><span class="ki">${s.clear ? "🌀" : s.better ? "↻" : s.dps < 2 ? "·" : "✓"}</span><div class="kt">
          <b>${esc(s.name)}</b>: ${s.clear ? `для зачистки${s.dps < -2 ? ` · на боссах снять: <span class="up">+${(-s.dps).toFixed(0)}% урона</span>` : ""}` : `<span class="${s.dps >= 2 ? "up" : ""}">${s.dps >= 0 ? "+" : ""}${s.dps}% урона</span>`}
          ${s.better ? `<div class="small" style="color:#86efac">→ поставь ${esc(s.better.name)}: ${s.better.dps >= 0 ? "+" : ""}${s.better.dps}% к урону</div>` : ""}</div></div>`).join("")}</div>` : ""}
      ${(d.insights || []).length ? `<div class="bv-sgh" style="--k:var(--k-act);margin-top:10px">💡 Выводы</div>${d.insights.map(x => `<div class="kb ${SEV[x.sev]}" style="margin:4px 0"><span class="ki">${x.sev === "critical" ? "⛔" : x.sev === "warn" ? "⚠" : "ℹ"}</span><div class="kt"><b class="kh">${esc(x.area)}: ${esc(x.title)}</b>${esc(x.text)}</div></div>`).join("")}` : ""}
    </div>`;
  }

  // PoE2 characters live on pathofexile2.com (its own login): one visible login window, then everything syncs itself
  let loginWait = null;
  function gggLogin() {
    if (loginWait) return loginWait;
    loginWait = (async () => {
      await api.post("/api/character/ggg/login");
      toast("info", "Открыл окно pathofexile2.com", "войди в аккаунт PoE — после входа окно спрячется само, персонажи подтянутся");
      for (;;) {
        await new Promise(r => setTimeout(r, 2000));
        const st = await api.get("/api/character/ggg");
        if (st.login.status === "ok") {
          toast("ok", st.login.message, "загружаю персонажей и билд…");
          await api.post("/api/character/profiles/sync").catch(() => {});
          await P2.choices(true);
          headerRefresh();
          return st;
        }
        if (!st.login.running) throw new Error(st.login.message || "Вход отменён");
      }
    })().finally(() => { loginWait = null; });
    return loginWait;
  }
  // a character without a build: log in if the PoE2 site needs it, then pull gear + gems + tree into PoB
  async function loadBuild(pid) {
    let st = await api.get("/api/character/ggg");
    if (!st.connected || (st.site && st.site.need_login)) {
      if (!st.can_window) throw new Error("Вход на pathofexile2.com работает только в окне приложения (ярлык «POE2 Helper»). Или вставь PoB-код.");
      await gggLogin();
    }
    toast("info", "Загружаю билд с pathofexile2.com", "шмот, камни и древо — до минуты");
    const r = await api.post(`/api/character/profiles/${pid}/import`);
    await P2.choices(true);
    return r.build_file;
  }
  // tabs call this when the active character has no build: one shared load per character, no buttons needed
  const building = new Map();
  function autoBuild(pid) {
    if (!building.has(pid)) building.set(pid, loadBuild(pid).finally(() => setTimeout(() => building.delete(pid), 1000)));
    return building.get(pid);
  }
  function autoBuildHtml(name) {
    return `<div class="kb gem"><span class="ki"><span class="spin-s"></span></span><div class="kt"><b class="kh">Загружаю билд ${esc(name || "")} с pathofexile2.com</b>
      шмот, камни и древо — обычно 20–60 секунд, всё подставится само</div></div>`;
  }
  // the one button: account sync + live gear + tree/skills; opens PoB only when the tree has no source yet
  async function refreshBuild(btn) {
    btn && P2.spinBtn(btn, true, "Обновляю…");
    try {
      let st = await api.get("/api/character/ggg");
      if (!st.connected || (st.site && st.site.need_login)) await gggLogin();
      const r = await api.post("/api/character/refresh_build");
      await P2.choices(true);
      headerRefresh();
      if (r.need_pob) {  // never pop PoB up by itself: the «древа нет» pill opens it when the player wants
        toast("info", `${r.name}: шмот обновлён, древа пока нет`,
          `древо и камни берутся из Path of Building — нажми «🌳 древа нет» в шапке билда, когда будет удобно`);
      } else toast("ok", `${r.name}: билд обновлён`, `шмот с сайта (${r.items || 0} предм.), древо и камни — ${r.tree_from}`);
      P2.rerender && P2.rerender();
      return r;
    } catch (e) { toast("err", "Обновить билд", e.message); throw e; }
    finally { btn && P2.spinBtn(btn, false); }
  }
  function needLoginHtml(st) {
    return st && st.site && st.site.need_login ? `<div class="kb warn" style="margin-top:10px"><span class="ki">🔑</span><div class="kt"><b class="kh">Нужен вход на pathofexile2.com</b>
      Персонажи PoE2 (все лиги), их шмот и древо берутся с сайта PoE2 — у него свой вход, отдельный от pathofexile.com. Один раз войди — дальше всё обновляется само.
      <div class="row" style="margin-top:8px"><button class="btn primary" data-ggg="login">🔑 Войти на pathofexile2.com</button></div></div></div>` : "";
  }
  async function gggConnectHtml(st) {
    return st.connected ? `<div class="row" style="flex-wrap:wrap;gap:6px">${st.session_expired ? `<span class="tag" style="color:#fbbf24">сессия истекла</span>` : `<span class="tag green">подключён</span>`}
        <b>${esc(st.account || "аккаунт GGG")}</b><span class="spacer"></span>
        <button class="btn sm" data-ggg="sync">⟳ Загрузить персонажей</button>${st.can_window ? `<button class="btn sm" data-ggg="login">🔑 Войти заново</button>` : ""}
        ${st.can_window && (st.session_expired || !st.trade_session) ? `<button class="btn sm primary" data-ggg="trade">🔑 Войти для трейда</button>` : ""}
        <button class="btn sm ghost danger" data-ggg="logout">Отключить</button></div>
        ${st.session_expired || !st.trade_session ? `<div class="small" style="color:#fbbf24;margin-top:6px">Для трейда у GGG свой вход — на pathofexile.com, отдельно от pathofexile2.com. Без него нет живого поиска в слежках и высоких лимитов трейда: нажми «Войти для трейда».</div>` : ""}${needLoginHtml(st)}`
      : `<div class="small" style="line-height:1.6">Войди на <b>pathofexile2.com</b> в окне тулы: увидим всех персонажей аккаунта по лигам, их шмот, камни и древо.
          Пароль вводится только на сайте GGG; тула хранит только сессию (в зашифрованном виде) и в любой момент её можно отключить.</div>
        <div class="row" style="margin-top:10px">${st.can_window ? `<button class="btn primary" data-ggg="login">🔑 Войти на pathofexile2.com</button>` : ""}
          <button class="btn ${st.can_window ? "ghost" : ""}" data-ggg="manual">У меня есть POESESSID</button></div>
        <div data-ggg-manual hidden style="margin-top:10px"><div class="small muted" style="line-height:1.6">Как взять POESESSID: открой pathofexile.com в браузере и войди → F12 →
          вкладка <b>Application</b> (Chrome) / <b>Storage</b> (Firefox) → Cookies → https://www.pathofexile.com → строка <b>POESESSID</b> → скопируй Value (32 символа).
          Никому его не пересылай: он даёт доступ к аккаунту на сайте.</div>
          <div class="row" style="margin-top:6px"><input class="inp" type="password" data-ggg-sess placeholder="POESESSID" autocomplete="off" style="flex:1"><button class="btn primary" data-ggg="save">Подключить</button></div></div>`;
  }
  function wireGgg(box, onDone) {
    box.querySelectorAll("[data-ggg]").forEach(b => b.onclick = async () => {
      const a = b.dataset.ggg;
      try {
        if (a === "manual") { box.querySelector("[data-ggg-manual]").hidden = false; return; }
        if (a === "login") {
          P2.spinBtn(b, true, "Жду вход…");
          await gggLogin();
          onDone();
          return;
        }
        if (a === "save") {
          P2.spinBtn(b, true);
          const r = await api.post("/api/character/ggg/session", {sessid: box.querySelector("[data-ggg-sess]").value});
          box.querySelector("[data-ggg-sess]").value = "";
          toast("ok", `Аккаунт ${r.account} подключён`, `персонажей: ${r.characters}, новых: ${r.added}`);
          onDone();
        }
        if (a === "sync") { P2.spinBtn(b, true); const r = await api.post("/api/character/profiles/sync"); toast("ok", "Готово", r.ggg ? `персонажей на аккаунте: ${r.ggg.characters}` : ""); onDone(); }
        if (a === "trade") {
          P2.spinBtn(b, true, "Жду вход…");
          await api.post("/api/character/ggg/trade_login");
          toast("info", "Открыл окно pathofexile.com", "войди — окно закроется само, трейд подхватит вход");
          for (;;) {
            await new Promise(r => setTimeout(r, 2000));
            const t = await api.get("/api/character/ggg/trade_login");
            if (!t.running) { toast(t.status === "ok" ? "ok" : "info", t.status === "ok" ? "Вход для трейда есть" : "Вход для трейда", t.message); break; }
          }
          onDone();
          return;
        }
        if (a === "logout") { P2.spinBtn(b, true); await api.post("/api/character/ggg/logout"); toast("ok", "Аккаунт отключён", "сессия удалена из тулы — войти можно снова в любой момент"); onDone(); }
      } catch (err) { P2.spinBtn(b, false); toast("err", "Аккаунт GGG", err.message); }
    });
  }

  async function addCharacter(tab) {
    const d = await api.get("/api/character/profiles");
    const m = modal("Добавить персонажа", `<div class="seg" id="ac-tabs">
        <button data-t="ggg">Аккаунт GGG</button><button data-t="game">Из игры</button><button data-t="pob">Код PoB / ссылка</button><button data-t="manual">Вручную</button></div>
      <div id="ac-body" style="margin-top:14px"></div>`, 680);
    const body = m.el.querySelector("#ac-body");
    const done = async () => { m.close(); await afterCharChange(); };
    const tabs = {
      async ggg() {
        body.innerHTML = await gggConnectHtml(d.ggg);
        wireGgg(body, done);
      },
      game() {
        const c = d.candidates.filter(x => x.source === "игра");
        body.innerHTML = `<div class="kb warn"><span class="ki">⚠</span><div class="kt">В лог игры (Client.txt) попадают и <b>участники группы</b> — здесь могут быть персонажи друзей.
          Добавляй только своих. Надёжнее — вкладка «Аккаунт GGG»: там только твои персонажи и их лиги.</div></div>
          ${c.map((x, i) => `<div class="pk-row" data-i="${i}" style="border:1px solid var(--line);border-radius:10px;margin-bottom:6px">${avatar(x, 36)}
            <div class="pk-txt"><b>${esc(x.name)}</b><span>${esc(x.ascendancy_ru || x.class_ru || x.class)} · ${x.level} ур. · последний раз ${esc(x.seen || "")}</span></div><button class="btn sm primary">Добавить</button></div>`).join("")
          || `<div class="pk-empty">Все персонажи из лога уже добавлены.</div>`}`;
        body.querySelectorAll("[data-i]").forEach(r => r.onclick = async () => {
          const x = c[+r.dataset.i];
          const p = await api.post("/api/character/profiles", {name: x.name, ascendancy: x.ascendancy || x.class, level: x.level});
          await api.post(`/api/character/profiles/${p.id}/activate`);
          toast("ok", `${x.name} добавлен и выбран`); done();
        });
      },
      pob() {
        body.innerHTML = `<div class="small muted" style="line-height:1.6;margin-bottom:8px">Вставь код Path of Building или ссылку <b>pobb.in</b> / <b>poe.ninja</b> / pastebin.
            Билд сохранится в папку PoB, станет билдом этого персонажа, и все вкладки (Текущий билд, Древо, Анализ, Апгрейды) будут работать от него.</div>
          <textarea class="inp" id="ac-code" rows="5" placeholder="eNrtfQt..."></textarea>
          <div class="row" style="margin-top:8px"><input class="inp" id="ac-name" placeholder="Имя персонажа (как в игре, необязательно)" style="flex:1">
            <button class="btn primary" id="ac-go">Добавить</button></div><div id="ac-res" class="small" style="margin-top:8px"></div>`;
        body.querySelector("#ac-go").onclick = async e => {
          const b = e.currentTarget; P2.spinBtn(b, true, "Читаю…");
          try { const r = await api.post("/api/character/profiles/from_pob", {code: body.querySelector("#ac-code").value, name: body.querySelector("#ac-name").value});
            toast("ok", `${r.profile.name} добавлен`, `${r.info.ascendancy || r.info.class} ${r.info.level || ""} · ${P2.fmt.n(r.info.skills.length, "группа камней|группы камней|групп камней")}`); done(); }
          catch (err) { body.querySelector("#ac-res").innerHTML = `<span style="color:var(--red)">${esc(err.message)}</span>`; P2.spinBtn(b, false); }
        };
      },
      async manual() {
        const c = await P2.choices();
        body.innerHTML = `<div class="grid g2">
          <div class="field"><label>Имя персонажа</label><input class="inp" id="am-name" placeholder="как в игре"></div>
          <div class="field"><label>Уровень</label><input class="inp" id="am-level" type="number" min="1" max="100" placeholder="90"></div>
          <div class="field"><label>Класс / восхождение</label><button id="am-class"></button></div>
          <div class="field"><label>Основной скилл</label><button id="am-skill"></button></div>
          <div class="field"><label>Лига</label><select class="inp" id="am-league"><option value="">— текущая —</option>${c.leagues.map(l => `<option>${esc(l)}</option>`).join("")}</select></div>
          </div><div class="row end" style="margin-top:12px"><button class="btn primary" id="am-go">Добавить и выбрать</button></div>`;
        const cls = await classPicker(body.querySelector("#am-class"), {});
        const sk = await gemPicker(body.querySelector("#am-skill"), {});
        body.querySelector("#am-go").onclick = async () => {
          const name = body.querySelector("#am-name").value.trim();
          if (!name) { toast("info", "Укажи имя персонажа"); return; }
          const p = await api.post("/api/character/profiles", {name, ascendancy: cls.value, skill: sk.value, league: body.querySelector("#am-league").value,
            level: +body.querySelector("#am-level").value || null});
          await api.post(`/api/character/profiles/${p.id}/activate`);
          toast("ok", `${name} добавлен и выбран`); done();
        };
      },
    };
    const sel = t => { m.el.querySelectorAll("#ac-tabs button").forEach(b => b.classList.toggle("on", b.dataset.t === t)); tabs[t](); };
    m.el.querySelectorAll("#ac-tabs button").forEach(b => b.onclick = () => sel(b.dataset.t));
    sel(tab || (d.ggg.connected ? "ggg" : d.candidates.some(x => x.source === "игра") ? "game" : "ggg"));
  }

  // live: the server switched the active character (auto-follow) or synced the list
  let charVer = null, activeId = null, buildVer = null, craftVer = null;
  P2.onLive(st => {
    const cr = st && st.craft;
    if (cr) {  // a tracked craft turned profitable (or stopped being)
      if (craftVer !== null && cr.v !== craftVer && cr.alert) toast(/стал/.test(cr.alert.text) ? "ok" : "info", `💰 ${cr.alert.label}`, cr.alert.text);
      craftVer = cr.v;
    }
    const c = st && st.chars;
    if (!c) return;
    if (charVer !== null && c.version !== charVer) {
      const switched = activeId && c.active !== activeId;
      headerRefresh().then(() => {
        if (switched) {
          const act = PROF && PROF.profiles.find(p => p.id === c.active);
          if (act) toast("info", `Переключился на ${act.name}`, "ты зашёл в игру этим персонажем — тула подстроилась");
          afterCharChange();
        }
      });
    }
    if (buildVer !== null && c.build !== buildVer && !(activeId && c.active !== activeId)) {
      toast("ok", c.note ? "Билд обновлён из Path of Building" : "Билд обновлён из игры",
        c.note || "новый шмот / древо / камни уже в туле и у ассистента");
      P2.choices(true);
      if (["build_view", "dash", "tree", "audit", "pob"].includes(P2.current && P2.current())) P2.rerender && P2.rerender();
    }
    buildVer = c.build;
    charVer = c.version; activeId = c.active;
  });

  Object.assign(P2, {popover, closePopover, picker, pickerValue, gemPicker, classPicker, currencyPicker, avatar, gemItems, classItems, iconHtml,
    headerRefresh, refreshActive: headerRefresh, addCharacter, afterCharChange, modal, gggConnectHtml, wireGgg, gggLogin, loadBuild, needLoginHtml, autoBuild, autoBuildHtml, refreshBuild, deepHtml});
  headerRefresh();
  document.addEventListener("change", async e => {
    if (!e.target.matches || !e.target.matches(".dp-role")) return;
    await P2.api.post("/api/pob/weapon_role", {key: e.target.dataset.key, set: +e.target.dataset.set, role: e.target.value});
    P2.toast("ok", "Роль набора сохранена", "пересчитываю билд на новых ролях");
    window.dispatchEvent(new Event("p2:weapon-roles"));
  });
  // gem index for answer cards (real PoE2 gems: icon + Russian name; anything else is a model mistake)
  P2.choices().then(c => { P2.gemIndex = new Map(); (c.gems_rich || []).forEach(g => { P2.gemIndex.set(g.en.toLowerCase(), g); P2.gemIndex.set(g.ru.toLowerCase(), g); }); }).catch(() => {});
})();
