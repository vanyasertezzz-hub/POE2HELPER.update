(function () {
  "use strict";
  const {api, esc, registerModule, spinBtn} = window.P2;
  const root = document.getElementById("doctor-root");
  const ICON = {ok: "✔", warn: "⚠", fail: "✖"}, CLS = {ok: "node", warn: "warn", fail: "warn"};
  root.innerHTML = `<div class="card glow"><div class="row"><h3 style="margin:0">Состояние тулы</h3><span class="spacer"></span>
      <span class="small muted" id="dr-sum"></span><a class="btn sm" href="/api/doctor/report" download title="журнал ошибок, хвост лога, версии, проверки Доктора — без ключей и данных персонажей; отправь автору">📦 Отчёт автору</a><button class="btn sm primary" id="dr-run">⟳ Проверить</button></div>
      <div class="small muted" style="margin-top:4px">Каждый источник и фоновая задача: работает ли, когда обновлялась, сколько данных принесла. Пустой результат — тоже проблема.</div>
      <div class="small" id="dr-game" style="margin-top:6px"></div>
      <div id="dr-brain" style="margin-top:10px"></div>
      <div id="dr-list" style="margin-top:12px"></div></div>`;
  // the brain: what the tool knows about the game now and what the last patch or league changed — learned by itself
  const KIND = {classes: "классы", ascendancies: "восхождения", acts: "акты", skills: "скиллы", uniques: "уники", bases: "базы", currency: "валюта крафта"};
  function brainHtml(b) {
    if (!b) return "";
    const c = b.counts || {};
    const h = (b.history || [])[0];
    const changed = h ? Object.entries(h.change || {}).filter(([k]) => KIND[k]).map(([k, v]) =>
      `${KIND[k]}: ${v.added.length ? `+${v.added.length} (${esc(v.added.slice(0, 6).join(", "))}${v.added.length > 6 ? "…" : ""})` : ""}${v.removed.length ? ` −${v.removed.length}` : ""}`).join("; ")
      + ["patch", "league", "content_update"].filter(k => (h.change || {})[k]).map(k => `; ${({patch: "патч", league: "лига", content_update: "контент-патч"})[k]}: ${esc(h.change[k].from || "—")} → ${esc(h.change[k].to)}`).join("") : "";
    const steps = ((b.pipeline || {}).steps || []).map(x => `<span class="tag" title="${esc(x.error || "")}">${x.ok ? "✔" : "✖"} ${esc(x.title)}</span>`).join(" ");
    return `<div class="kb node"><span class="ki">🧠</span><div class="kt"><b class="kh">Мозг тулы — учится новому патчу и лиге сам</b>
      ${b.patch ? `Патч ${esc(b.patch)} · лига «${esc(b.league || "—")}»${b.content_update ? ` · контент-патч «${esc(b.content_update)}»` : ""}` : "ещё не смотрел данные — посмотрит сам или по кнопке"}
      ${b.patch ? `<div class="small" style="margin-top:3px">Знает: ${esc((b.classes || []).join(", "))} · ${esc((b.acts || []).join(", "))} · скиллов ${c.skills || 0}, уников ${c.uniques || 0}, баз ${c.bases || 0}</div>` : ""}
      ${h ? `<div class="small" style="margin-top:3px">Последнее изменение (${window.P2.fmt.ago(h.t)}): ${changed || "—"}</div>` : ""}
      ${steps ? `<div class="small" style="margin-top:4px">Конвейер нового патча: ${steps}</div>` : ""}
      ${b.step ? `<div class="small" style="margin-top:3px"><span class="spin-s"></span> ${esc(b.step)}</div>` : ""}
      <div class="row" style="margin-top:6px"><button class="btn sm" id="dr-brain-learn">🧠 Посмотреть сейчас</button>
      <span class="tiny faint">${b.last ? `смотрел ${window.P2.fmt.ago(b.last)}` : ""} — сам: после каждого патча, обновления PoB, новой лиги и раз в сутки</span></div></div></div>`;
  }
  async function loadBrain() {
    try { $("#dr-brain").innerHTML = brainHtml(await api.get("/api/doctor/brain")); } catch (_) { return; }
    $("#dr-brain-learn")?.addEventListener("click", async e => {
      const b = e.currentTarget; spinBtn(b, true, "Смотрю…");
      try { await api.post("/api/doctor/brain/learn"); } catch (err) { window.P2.toast("err", "Мозг", err.message); }
      spinBtn(b, false); loadBrain();
    });
  }
  // the nightly audit of the whole game (every mod, base, item, skill — tools/audit_*.py) in one line
  function gameHtml(g) {
    if (!g) return "";
    if (g.running) return `🔎 Аудит всей игры: идёт${g.step ? ` — ${esc(g.step)}` : ""}`;
    if (!g.total) return "🔎 Аудит всей игры: ещё не запускался — идёт сам раз в сутки (в убежище, в городе или при закрытой игре)";
    const bad = g.bad.length;
    return `🔎 Аудит всей игры: <b class="${bad ? "down" : "up"}">${bad ? `${bad} с проблемами` : "0 проблем"}</b> из ${g.total} проверок · ${window.P2.fmt.ago(g.last)}${bad ? ` · ${g.bad.map(esc).join(", ")}` : ""}`;
  }
  async function load() {
    $("#dr-list").innerHTML = `<div class="small muted"><span class="spin-s"></span> проверяю PoB, ИИ, трейд, базу знаний…</div>`;
    let d;
    try { d = await api.get("/api/doctor"); } catch (e) { $("#dr-list").innerHTML = `<div class="kb warn"><span class="ki">✖</span><div class="kt">${esc(String(e))}</div></div>`; return; }
    $("#dr-sum").textContent = `✔ ${d.summary.ok} · ⚠ ${d.summary.warn} · ✖ ${d.summary.fail}`;
    $("#dr-game").innerHTML = gameHtml(d.game_audit);
    loadBrain();
    $("#dr-list").innerHTML = d.checks.map(c => `<div class="kb ${CLS[c.status]}" style="margin:6px 0${c.status === "fail" ? ";border-color:#f87171" : ""}">
      <span class="ki">${ICON[c.status]}</span><div class="kt"><b class="kh">${esc(c.title)}</b>${esc(c.detail)}
      ${c.fix ? `<div class="small" style="margin-top:3px">→ ${esc(c.fix)}</div>` : ""}</div></div>`).join("")
      + ((d.errors || []).length ? `<div class="row" style="margin-top:14px"><h3 style="margin:0">Журнал ошибок</h3><span class="spacer"></span>
          <button class="btn sm" id="dr-copy">📋 Скопировать для Claude</button><button class="btn sm ghost" id="dr-clear">Очистить</button></div>
        <table class="tbl" style="margin-top:6px"><tbody>${d.errors.map(e => `<tr><td class="tiny faint" style="white-space:nowrap">${new Date(e.last * 1000).toLocaleString("ru")}</td>
          <td><span class="tag">${esc(e.source)}</span></td><td class="small"><b>${esc(e.where)}</b><br>${esc(e.message)}</td><td class="num">×${e.count}</td></tr>`).join("")}</tbody></table>` : "")
      + latencyHtml(d.latency) + backupsHtml(d.backups);
    $("#dr-backup-now")?.addEventListener("click", async e => { const b = e.currentTarget; spinBtn(b, true, "…");
      try { const r = await api.post("/api/doctor/backups/run"); window.P2.toast("ok", "Копия сделана", `${r.date}: ${r.files} файлов`); } catch (err) { window.P2.toast("err", "Копия", err.message); }
      spinBtn(b, false); load(); });
    root.querySelectorAll("[data-restore]").forEach(b => b.onclick = async () => {
      if (!await window.P2.dialog({title: `Восстановить данные из копии ${b.dataset.restore}?`, text: "Текущее состояние сначала отложится в before-restore-…, потом вернутся персонажи, настройки, ключи, сундук, слежки и сессии. После — перезапусти тулу.", ok: "Восстановить", danger: true})) return;
      try { const r = await api.post("/api/doctor/backups/restore", {name: b.dataset.restore}); window.P2.toast("ok", "Восстановлено", `${r.files} файлов · ${r.note}`); } catch (err) { window.P2.toast("err", "Восстановление", err.message); }
      load();
    });
    const cp = $("#dr-copy");
    if (cp) cp.onclick = () => { navigator.clipboard.writeText(d.errors.map(e => `[${e.source}] ${e.where} ×${e.count}\n${e.message}\n${(e.detail || "").slice(-800)}`).join("\n\n")); window.P2.toast("ok", "Скопировано", "вставь в чат с Claude"); };
    const cl = $("#dr-clear");
    if (cl) cl.onclick = async () => { await api.post("/api/errors/clear"); load(); };
  }
  // the numbers behind «the tab waits»: p50 / p95 / the longest call of every route over the day
  function latencyHtml(l) {
    if (!l || !(l.routes || []).length) return "";
    const sec = ms => ms >= 1000 ? (ms / 1000).toFixed(1) + " с" : ms + " мс";
    return `<div class="row" style="margin-top:14px"><h3 style="margin:0">Отклик запросов за сутки</h3><span class="spacer"></span><span class="small muted">${l.calls} запросов · p50 / p95 / максимум</span></div>
      <table class="tbl" style="margin-top:6px"><tbody>${l.routes.map(r => `<tr><td class="mono small">${esc(r.path)}</td><td class="num">×${r.n}</td><td class="num">${sec(r.p50)}</td><td class="num ${r.p95 > 3000 ? "down" : ""}">${sec(r.p95)}</td><td class="num">${sec(r.max)}</td><td class="num">${r.errors ? `<span style="color:var(--red)">ошибок ${r.errors}</span>` : ""}</td></tr>`).join("")}</tbody></table>`;
  }
  // the daily copies of the player's own data (characters, settings, keys, stash, watches, sessions): any of them comes back by a click
  function backupsHtml(list) {
    const mb = b => b >= 1048576 ? (b / 1048576).toFixed(1) + " МБ" : Math.round(b / 1024) + " КБ";
    return `<div class="row" style="margin-top:14px"><h3 style="margin:0">Резервные копии данных</h3><span class="spacer"></span><button class="btn sm" id="dr-backup-now">Сделать копию</button></div>
      <div class="tiny faint" style="margin:4px 0 6px">раз в сутки, хранится 7; восстановление сначала откладывает текущее состояние</div>
      ${(list || []).length ? `<table class="tbl"><tbody>${list.map(b => `<tr><td class="mono small">${esc(b.name)}</td><td class="num">${b.files} файлов</td><td class="num">${mb(b.bytes)}</td><td class="num"><button class="btn sm ghost" data-restore="${esc(b.name)}">Восстановить</button></td></tr>`).join("")}</tbody></table>` : `<div class="small muted">копий пока нет</div>`}`;
  }
  const $ = s => root.querySelector(s);
  $("#dr-run").onclick = async e => { const b = e.currentTarget; spinBtn(b, true, "Проверяю…"); try { await load(); } finally { spinBtn(b, false); } };
  registerModule({id: "doctor", onShow: load});
})();
