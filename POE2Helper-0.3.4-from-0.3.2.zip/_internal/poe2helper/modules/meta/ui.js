(function () {
  "use strict";
  const {api, esc, fmt, registerModule, assistantPanel, toast} = window.P2;
  const root = document.getElementById("meta-root");
  root.innerHTML = `
    <div class="card glow" style="margin-bottom:16px"><div class="row"><h3 style="margin:0">Источники меты</h3><span class="spacer"></span>
      <span class="small muted" id="mt-when"></span><button class="btn sm" id="mt-refresh">Собрать свежее</button></div>
      <div class="small faint" style="margin:8px 0 12px">Тула сама проверяет каждые 6 ч: официальные патч-ноуты (Early Access Patch Notes), новости GGG, r/PathOfExile2 и r/pathofexile2builds. Сырые тексты локально сжимает Ollama (бесплатно), отчёт пишет облачная модель с большим контекстом. При новой лиге или патче отчёт создаётся автоматически.</div>
      <div class="grid g4" id="mt-src"></div><div class="tiny faint" id="mt-log" style="margin-top:10px"></div></div>
    <div id="mt-assist"></div>`;
  const $ = s => root.querySelector(s);
  const LBL = {patch: "Патч-ноуты", news: "Новости GGG", community: "Reddit", digest: "Дайджесты Ollama"};

  async function load() {
    const s = await api.get("/api/meta/status");
    const pt = s.patch ? `патч ${s.patch.note}${s.patch.posted ? ` от ${new Date(s.patch.posted * 1000).toLocaleDateString("ru-RU")}` : ""} · ` : "";
    $("#mt-when").textContent = pt + (s.state.refreshed ? `обновлено ${fmt.ago(s.state.refreshed)}` : "ещё не собирали");
    const by = {};
    s.sources.forEach(x => { by[x.kind] = by[x.kind] || {n: 0, docs: 0, last: 0}; by[x.kind].n++; by[x.kind].docs += x.count; by[x.kind].last = Math.max(by[x.kind].last, x.updated); });
    $("#mt-src").innerHTML = Object.keys(LBL).map(k => `<div class="stat"><b>${by[k] ? by[k].docs : 0}</b><span>${LBL[k]}${by[k] ? ` · ${by[k].n} ист.` : ""}</span></div>`).join("");
    $("#mt-log").innerHTML = (s.running ? "⟳ " : "") + esc(s.log.slice(-3).join(" · "));
    if (s.running) setTimeout(load, 4000);
    if (s.state.notice && s.state.notice.session) panel.reload();
  }
  $("#mt-refresh").onclick = async () => { await api.post("/api/meta/refresh"); toast("info", "Сбор запущен", "патчи, новости, Reddit, затем дайджесты Ollama"); setTimeout(load, 2000); };

  const panel = assistantPanel($("#mt-assist"), {
    kind: "meta", newUrl: "/api/meta/report", newTitle: "Мета-отчёт", createLabel: "Сделать отчёт по лиге", kickoff: false,  // the report is written by the request itself
    formHtml: `<div class="small muted">Соберёт патч-ноуты, дайджесты, посты, свежие билды и рейтинг стартеров и напишет отчёт (около минуты). Новый патч или лига: тула сделает его сама.</div>`,
    collect: () => ({}),
    chips: ["Сделай полный отчёт: изменения, топ стартеры, топ эндгейм", "Какой стартер для новичка с минимальным бюджетом?", "Лучший билд под боссинг в этой лиге?",
            "Что понерфили и кого это задело?", "Что говорят люди на Reddit о сильнейших билдах?", "Что будет дорожать в начале лиги?"],
    emptyHtml: "Отчёт по текущей лиге: что изменилось в патче, лучшие лиг-стартеры и эндгейм-билды с аргументами, мнения комьюнити со ссылками.",
  });
  registerModule({id: "meta", onShow: load});
})();
