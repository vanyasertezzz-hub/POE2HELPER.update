(function () {
  "use strict";
  const {api, esc, fmt, registerModule, toast, go, spinBtn, onLive} = window.P2;
  const root = document.getElementById("bv-root");
  root.innerHTML = `
    <div class="row" style="margin-bottom:12px;gap:10px"><div class="seg bv-mode"><button data-m="mine" class="on">🛡 Мой билд</button><button data-m="ai">✦ Как видит ИИ</button></div>
      <span class="small muted" id="bv-mode-hint">реальный билд из игры / PoB</span><span class="spacer"></span>
      <button class="btn primary sm" id="bv-refresh" title="шмот с сайта PoE2, древо и камни из Path of Building — всё сразу">⟳ Обновить билд</button></div>
    <div class="card bv-aibar" id="bv-aibar" hidden><div class="row" style="gap:8px;flex-wrap:wrap">
        <b>💰 Бюджет:</b><input class="inp" id="bv-amt" type="number" min="0" step="1" placeholder="сколько" style="width:110px">
        <button id="bv-cur" style="width:170px"></button>
        <input class="inp" id="bv-wish" placeholder="пожелание (необязательно): больше урона по боссам, HC, без Energy Shield…" style="flex:1;min-width:240px">
        <button class="btn primary" id="bv-gen">✦ Собрать билд</button></div>
      <div id="bv-aisum" style="margin-top:10px"></div></div>
    <div class="card glow bv-head" id="bv-head"></div>
    <div id="bv-changes"></div>
    <div class="bv-grid">
      <div class="card"><div class="sec-h" style="--k:var(--k-item)"><span class="si">🛡</span><div><h3>Экипировка</h3><div class="sd">наведи на предмет — моды; клик — трейд, апгрейд, крафт</div></div></div>
        <div class="bv-doll" id="bv-doll"></div><div class="bv-flasks" id="bv-flasks"></div></div>
      <div class="card"><div class="sec-h" style="--k:var(--k-gem)"><span class="si">💎</span><div><h3>Камни умений</h3><div class="sd">скилл + его камни поддержки</div></div></div>
        <div id="bv-gems"></div></div>
      <div class="card"><div class="sec-h" style="--k:var(--k-info)"><span class="si">📊</span><div><h3>Характеристики</h3><div class="sd">точный расчёт Path of Building</div></div></div>
        <div id="bv-stats"></div></div>
    </div>
    <div class="bv-grid2">
      <div class="card"><div class="sec-h" style="--k:var(--k-node)"><span class="si">🌳</span><div><h3>Древо пассивок</h3><div class="sd">взятые ноды — золотом</div></div>
        <span class="spacer"></span><button class="btn sm" data-go="tree">Открыть древо и план респека →</button></div><div id="bv-tree"></div></div>
      <div class="card"><div class="sec-h" style="--k:var(--k-reward)"><span class="si">⭐</span><div><h3>Ключевые пассивки</h3><div class="sd">восхождение, ключевые и значимые</div></div></div>
        <div id="bv-pass" style="max-height:560px;overflow:auto"></div></div>
    </div>
    <div id="bv-review"></div>
    <div id="bv-deep"></div>
    <div class="bv-tip" id="bv-tip"></div>`;
  const $ = s => root.querySelector(s);
  let data = null, tv = null, other = null, mode = "mine", mine = null, aiData = null, curPick = null;
  const big = n => n >= 1e6 ? (n / 1e6).toFixed(2) + "M" : n >= 1e4 ? (n / 1e3).toFixed(1) + "k" : Math.round(n).toLocaleString("ru");
  const fmtv = (v, f) => f === "pct" ? v.toFixed(v < 10 ? 1 : 0) + "%" : f === "x" ? "×" + v.toFixed(2) : f === "f2" ? v.toFixed(2)
    : f === "ms" ? (v * 100 - 100 >= 0 ? "+" : "") + (v * 100 - 100).toFixed(0) + "%" : f === "res" ? v.toFixed(0) + "%" : big(v);
  const RAR = {Unique: "#d97706", Rare: "#facc15", Magic: "#818cf8", Normal: "#d4d4d8", Relic: "#4ade80"};

  // paper doll positions (grid areas)
  const DOLL = {"Weapon 1": "w1", "Weapon 2": "w2", "Helmet": "he", "Body Armour": "bo", "Gloves": "gl", "Boots": "bt",
    "Amulet": "am", "Ring 1": "r1", "Ring 2": "r2", "Ring 3": "r3", "Belt": "be"};
  const MOD_ORDER = [["enchant", "Зачарование"], ["implicit", "Собственные"], ["rune", "Руны"], ["fractured", "Расколотые"],
    ["explicit", ""], ["desecrated", "Осквернённые"], ["crafted", "Ремесленные"]];

  function itemTip(it) {
    const c = RAR[it.rarity] || "#d4d4d8";
    return `<div class="gtip" style="--rc:${c}"><div class="gtip-h"><b>${esc(it.name_ru || it.name)}</b>${it.name_ru && it.name_ru !== it.name ? `<span class="tiny" style="display:block;opacity:.7">${esc(it.name)}</span>` : ""}
        ${it.base && it.base !== it.name ? `<span>${esc(it.base_ru || it.base)}</span>` : ""}</div>
      <div class="gtip-b"><div class="tiny" style="color:#a1a1aa">${esc(it.slot_ru)}${it.ilvl ? ` · ур. предмета ${esc(it.ilvl)}` : ""}${it.quality ? ` · качество ${esc(it.quality)}` : ""}${it.req ? ` · ${esc(it.req.replace("Requires:", "требует"))}` : ""}</div>
      ${MOD_ORDER.filter(([k]) => (it.mods[k] || []).length).map(([k, t]) => `<div class="gtip-sec m-${k}">${t ? `<i>${t}</i>` : ""}${((it.mods_ru || {})[k] || it.mods[k]).map(m => `<div>${esc(m)}</div>`).join("")}</div>`).join("")}
      ${it.corrupted ? `<div class="gtip-sec" style="color:#f87171">Осквернён (Corrupted)</div>` : ""}
      ${it.check ? `<div class="gtip-sec" style="text-align:left;color:${it.check.ok ? "#86efac" : "#fca5a5"}">🧪 PoB: ${it.check.dps != null ? `DPS ${it.check.dps >= 0 ? "+" : ""}${it.check.dps}% · EHP ${it.check.ehp >= 0 ? "+" : ""}${it.check.ehp}%` : ""} ${esc(it.check.note || "")}</div>` : ""}
      ${it.ai ? `<div class="gtip-sec" style="color:#e9d5ff;text-align:left">${it.keep ? "✓ оставить текущий" : `💰 ≈ ${it.price_div} div`}${it.why ? `<br>${esc(it.why)}` : ""}${it.verified === false ? `<br><span style="color:#fbbf24">⚠ имя не найдено в базе игры — проверь на трейде</span>` : ""}</div>` : ""}</div></div>`;
  }
  function slotHtml(slot, cls) {
    const it = (data.items || []).find(x => x.slot === slot);
    if (!it) return `<div class="bv-slot empty ${cls}" title="${esc(slot)}"><span>${esc({"Weapon 1": "оружие", "Weapon 2": "вторая рука", Helmet: "шлем", "Body Armour": "нательник", Gloves: "перчатки", Boots: "ботинки", Amulet: "амулет", "Ring 1": "кольцо", "Ring 2": "кольцо", "Ring 3": "кольцо", Belt: "пояс"}[slot] || slot)}</span></div>`;
    return `<div class="bv-slot ${cls}" data-slot="${esc(slot)}" style="--rc:${RAR[it.rarity] || "#a1a1aa"}">
      ${it.icon ? `<img src="${esc(it.icon)}" alt="" loading="lazy" data-name="${esc(it.base_ru || it.base || it.name || "")}">` : `<span>${esc(it.base)}</span>`}
      <div class="bv-sname">${esc(it.name)}</div>${it.ai && !it.keep ? `<span class="bv-price">${it.price_div} div</span>` : it.keep ? `<span class="bv-price keep">✓</span>` : ""}
      ${it.check ? `<span class="bv-check ${it.check.ok ? "ok" : "bad"}" title="проверка PoB">${it.check.ok ? "✓" : "✗"}</span>` : ""}
      ${it.craft && it.craft.cheaper ? `<span class="bv-craft" title="дешевле скрафтить: ≈ ${it.craft.cost_div} div">⚒</span>` : ""}</div>`;
  }
  function render() {
    const d = data;
    const act = d.active;
    $("#bv-head").innerHTML = `<div class="row" style="gap:14px;flex-wrap:wrap">
        ${window.P2.avatar(other ? {name: d.ascendancy || "?", portrait: d.portrait} : {...(act || {}), portrait: (act && act.portrait) || d.portrait}, 56)}
        <div><div style="font-size:20px;font-weight:800">${esc(other ? "Чужой билд" : (act && act.name) || "Билд")}</div>
          <div class="row" style="gap:6px;margin-top:4px">${d.ascendancy_ru || d.class_ru || (d.class && d.class !== "None") ? `<span class="pill reward">${esc(d.ascendancy_ru || d.class_ru || d.class)}</span>` : ""}
          <span class="pill node">${esc(d.level || "?")} уровень</span>${act && act.league && !other ? `<span class="pill info">${esc(act.league)}</span>` : ""}
          ${(d.nodes || []).length > 4 || other || d.ai ? `<span class="pill gem">${fmt.n((d.nodes || []).length, "пассивка|пассивки|пассивок")}</span>`
            : `<button class="pill warn" id="bv-notree" title="сайт PoE2 отдаёт только шмот — древо и камни берутся из Path of Building">🌳 древа нет — импортируй в PoB</button>`}${d.calc_error ? `<span class="pill warn" title="${esc(d.calc_error)}">расчёт PoB недоступен</span>` : ""}</div></div>
        <span class="spacer"></span>
        <div class="row" style="gap:6px;flex-wrap:wrap">
          ${other ? `<button class="btn sm" id="bv-back">← К моему билду</button>` : `<button class="btn sm" id="bv-sync" title="Шмот с сайта PoE2, древо и камни из Path of Building">⟳ Обновить из игры</button>`}
          <button class="btn sm" data-go="audit">🔬 Анализ билда</button><button class="btn sm" data-go="pob">📈 Апгрейды</button>
          <input class="inp" id="bv-code" placeholder="Чужой билд: ссылка pobb.in / poe.ninja или код" style="width:300px"><button class="btn sm primary" id="bv-open">Открыть</button></div></div>`;
    const doll = $("#bv-doll");
    doll.innerHTML = Object.entries(DOLL).map(([slot, cls]) => slotHtml(slot, cls)).join("");
    const extra = (d.items || []).filter(x => /Flask|Charm/.test(x.slot));
    const swap = (d.items || []).filter(x => / Swap$/.test(x.slot));
    $("#bv-flasks").innerHTML = (swap.length ? `<div class="tiny muted" style="flex-basis:100%;margin-top:6px">⚔ Второй набор оружия</div>` + swap.map(it => `<div class="bv-slot fl" data-slot="${esc(it.slot)}" style="--rc:${RAR[it.rarity] || "#a1a1aa"}">
      ${it.icon ? `<img src="${esc(it.icon)}" alt="" loading="lazy" data-name="${esc(it.base || it.name || "")}">` : ""}<div class="bv-sname">${esc(it.name)}</div></div>`).join("") + `<div style="flex-basis:100%"></div>` : "") + extra.map(it => `<div class="bv-slot fl" data-slot="${esc(it.slot)}" style="--rc:${RAR[it.rarity] || "#a1a1aa"}">
      ${it.icon ? `<img src="${esc(it.icon)}" alt="" loading="lazy" data-name="${esc(it.slot_ru || it.name || "")}">` : ""}<div class="bv-sname">${esc(it.slot_ru)}</div></div>`).join("");
    // gems
    // AI view: the player's own gems judged by the AI (green — keep, red — replace; hover a red one for the swap)
    const review = d.ai && aiData && (aiData.gem_review || []).length && mine && !mine.empty ? new Map(aiData.gem_review.map(r => [r.gem, r])) : null;
    if (review) {
      const CL = {replace: "gr-bad", keep: "gr-ok", weak: "gr-weak", clear: "gr-clear"};
      const chip = (s, big) => { const r = review.get(s.name); const cls = r ? CL[r.verdict] || "" : "";
        const tip = r ? (r.verdict === "replace" ? `Заменить на: ${r.replace_ru || r.replace_with || "?"}${r.why ? " — " + r.why : ""}`
          : r.verdict === "weak" ? `Слабый: ${r.why}` : r.verdict === "clear" ? `Зачистка: ${r.why}` : r.verdict === "unseen" ? `Утилита или условие: ${r.why}` : `Оставить: ${r.why || "на своём месте"}`) + (r.measured ? " (замер PoB)" : " (мнение ИИ)") : "";
        return big ? `<div class="bv-gem big ${cls}" style="--gc:${gemColor(s)}" title="${esc(tip)}">${s.icon ? `<img src="${esc(s.icon)}" alt="">` : ""}</div>`
          : `<div class="bv-supi ${cls}" title="${esc(s.name + (tip ? "\n" + tip : ""))}"><div class="bv-gem" style="--gc:${gemColor(s)}">${s.icon ? `<img src="${esc(s.icon)}" alt="">` : ""}</div><span>${esc(s.ru)}</span>
              ${r && r.verdict === "replace" && r.replace_ru ? `<span class="gr-rep">→ ${r.replace_icon ? `<img src="${esc(r.replace_icon)}" alt="">` : ""}${esc(r.replace_ru)}</span>` : ""}</div>`; };
      const bad = aiData.gem_review.filter(r => r.verdict === "replace").length;
      $("#bv-gems").innerHTML = `<div class="kb ${bad ? "warn" : "node"}" style="margin-bottom:8px"><span class="ki">🧪</span><div class="kt"><b class="kh">Твои камни глазами ИИ</b>
          ${bad ? `<span style="color:#fca5a5">красным</span> — есть замена лучше (наведи — на что и сколько даст)` : "явных замен нет"} · <span style="color:#86efac">зелёным</span> — даёт урон ·
          <span style="color:#fcd34d">жёлтым</span> — почти не даёт · <span style="color:#7dd3fc">синим</span> — для зачистки. Поддержки основного скилла измерены в PoB, остальное — мнение ИИ</div></div>`
        + mine.gems.map(g => `<div class="bv-gg ${g.main ? "main" : ""} ${g.enabled ? "" : "off"}">
          <div class="row" style="gap:10px">${g.skills.map(s => chip(s, true)).join("")}
            <div style="min-width:0"><b>${g.skills.map(s => esc(s.ru)).join(" + ")}</b>${g.main ? ` <span class="pill reward">основной</span>` : ""}
            ${g.skills.map(s => review.get(s.name)).filter(r => r && r.verdict === "replace").map(r => `<div class="small" style="color:#fca5a5">→ заменить на ${esc(r.replace_ru || r.replace_with || "")}: ${esc(r.why)}</div>`).join("")}</div></div>
          ${g.supports.length ? `<div class="bv-sup">${g.supports.map(s => chip(s, false)).join("")}</div>` : ""}</div>`).join("")
        + ((d.gems || []).length ? `<div class="bv-sgh" style="--k:var(--k-gem);margin-top:10px">✦ Связки, которые предлагает ИИ</div>` : "");
    }
    $("#bv-gems").innerHTML = (review ? $("#bv-gems").innerHTML : "") + (d.gems || []).map(g => `<div class="bv-gg ${g.main ? "main" : ""} ${g.enabled ? "" : "off"}">
        <div class="row" style="gap:10px">${g.skills.map(s => `<div class="bv-gem big" style="--gc:${gemColor(s)}">${s.icon ? `<img src="${esc(s.icon)}" alt="">` : ""}</div>`).join("")}
          <div style="min-width:0"><b>${g.skills.map(s => esc(s.ru)).join(" + ")}</b>${g.main ? ` <span class="pill reward">основной</span>` : ""}
          <div class="tiny faint">${g.skills.map(s => esc(s.name)).join(" + ")}${g.slot_ru ? " · " + esc(g.slot_ru) : ""}</div>
          ${g.why ? `<div class="small" style="color:#a5f3fc;margin-top:2px">${esc(g.why)}</div>` : ""}</div></div>
        ${g.supports.length ? `<div class="bv-sup">${g.supports.map(s => `<div class="bv-supi" title="${esc(s.name)}"><div class="bv-gem" style="--gc:${gemColor(s)}">${s.icon ? `<img src="${esc(s.icon)}" alt="">` : ""}</div><span>${esc(s.ru)}</span></div>`).join("")}</div>` : ""}
      </div>`).join("") || `<div class="muted small">Камней нет</div>`;
    // stats (AI mode: budget, goals and the order of actions)
    if (d.ai) {
      const tg = d.targets || {};
      $("#bv-stats").innerHTML = `<div class="bv-sg" style="--k:var(--k-money)"><div class="bv-sgh">💰 Бюджет</div>
          <div class="bv-res"><span>${d.total_div} div</span><div class="bv-bar"><i style="width:${Math.min(100, d.total_div / Math.max(0.01, d.budget_div) * 100)}%;background:${d.over ? "#ef4444" : "#22c55e"}"></i></div><b>${d.budget_div}</b></div>
          <div class="tiny ${d.over ? "down" : "muted"}">${d.over ? "⚠ ИИ немного вышел за бюджет — смотри цены на трейде" : "укладывается в бюджет"}</div></div>
        <div class="bv-sg" style="--k:var(--k-info)"><div class="bv-sgh">🎯 Цели билда</div>${Object.entries(tg).filter(([, v]) => v).map(([k, v]) =>
          `<div class="bv-sr"><span>${esc({life: "Здоровье", energy_shield: "Энергощит", resists: "Резисты", dps: "Урон"}[k] || k)}</span><b>${esc(v)}</b></div>`).join("") || "<div class='muted small'>—</div>"}</div>
        <div class="bv-sg" style="--k:var(--k-act)"><div class="bv-sgh">✅ Порядок действий</div>${(d.steps || []).map((t, i) => `<div class="kb act" style="margin:4px 0"><span class="ki">${i + 1}</span><div class="kt">${esc(t)}</div></div>`).join("")}</div>`;
    } else
    $("#bv-stats").innerHTML = (d.stats || []).map(g => `<div class="bv-sg" style="--k:var(--k-${g.kind})"><div class="bv-sgh">${esc(g.title)}</div>${g.note ? `<div class="tiny muted" style="margin:2px 0 4px">${esc(g.note)}</div>` : ""}
      ${g.rows.map(r => r.fmt === "res" ? `<div class="bv-res"><span>${esc(r.label)}</span><div class="bv-bar"><i style="width:${Math.max(0, Math.min(100, r.value / 90 * 100))}%;background:${r.value >= 75 ? "#22c55e" : r.value >= 50 ? "#f59e0b" : "#ef4444"}"></i></div><b class="${r.value >= 75 ? "up" : "down"}">${fmtv(r.value, r.fmt)}</b></div>`
        : `<div class="bv-sr"><span>${esc(r.label)}</span><b>${fmtv(r.value, r.fmt)}</b></div>`).join("")}</div>`).join("")
      || `<div class="kb warn"><span class="ki">⚠</span><div class="kt">Нет расчёта PoB${d.calc_error ? ": " + esc(d.calc_error) : ""}</div></div>`;
    // passives
    const P = d.ai ? {keystones: (d.picked || []).filter(p => p.kind === "keystones"), notables: (d.picked || []).filter(p => p.kind === "notables")} : d.passives || {};
    const prow = (p, k) => `<div class="bv-p ${k}" data-node="${esc(p.id)}"><img src="${esc(p.icon || "")}" alt="" onerror="this.style.visibility='hidden'"><div><b>${esc(p.ru)}</b>${d.ai ? (p.have ? ` <span class="pill info">уже есть</span>` : ` <span class="pill node">взять</span>`) : ""}
      <div class="tiny">${(p.stats || []).map(esc).join("<br>")}</div></div></div>`;
    $("#bv-pass").innerHTML = [["ascendancy", "✦ Восхождение"], ["keystones", "◆ Ключевые"], ["notables", "● Значимые"], ["jewels", "◇ Гнёзда самоцветов"]]
      .filter(([k]) => (P[k] || []).length).map(([k, t]) => `<div class="bv-sgh" style="margin-top:6px">${t} · ${P[k].length}</div>${P[k].map(p => prow(p, k)).join("")}`).join("")
      || `<div class="muted small">Нет данных о пассивках</div>`;
    wire();
    drawTree();
  }
  function gemColor(g) { return {red: "#ef4444", green: "#22c55e", blue: "#3b82f6"}[g.color] || "#a78bfa"; }

  async function drawTree() {
    if (!tv) { tv = new window.P2.TreeView($("#bv-tree"), {height: "560px"}); await tv.load(); }
    const asc = (data.passives?.ascendancy || [])[0];
    const ascName = asc ? (tv.L.byId[asc.id] || {}).asc : null;
    tv.setAllocated((data.nodes || []).map(String), {cls: data.class, ascendancy: ascName || (data.ai ? data.ascendancy : null)});
    tv.setPlan(data.ai ? {add: (data.plan || {}).add || [], remove: []} : null);
    tv.focusAllocated();
  }

  // the deep analysis knows which slot gives the build the least (measured: the build without it); the doll says so
  async function markWeak(tries = 0) {
    let r; try { r = await api.get("/api/buildview/slots"); } catch (_) { return; }
    if (r.running && tries < 12) { setTimeout(() => document.body.contains(root) && markWeak(tries + 1), 8000); return; }
    const pc = v => `${v > 0 ? "+" : ""}${String(v).replace(".", ",")}%`;
    Object.entries(r.slots || {}).forEach(([slot, v]) => {
      const el = root.querySelector(`.bv-slot[data-slot="${CSS.escape(slot)}"]`);
      if (!el || v.grade !== "weak" || el.querySelector(".bv-weak")) return;
      el.insertAdjacentHTML("beforeend", `<span class="bv-weak" title="Слабый слот по замеру PoB: без этого предмета урон ${pc(v.dps)}, живучесть ${pc(v.ehp)} — его менять первым">слабый</span>`);
    });
  }

  function wire() {
    markWeak();
    const tip = $("#bv-tip");
    root.querySelectorAll(".bv-slot[data-slot]").forEach(el => {
      const it = data.items.find(x => x.slot === el.dataset.slot);
      el.onmouseenter = () => { tip.innerHTML = itemTip(it); tip.style.display = "block"; };
      el.onmousemove = e => { const w = tip.offsetWidth, h = tip.offsetHeight;
        tip.style.left = Math.min(e.clientX + 18, window.innerWidth - w - 10) + "px"; tip.style.top = Math.min(e.clientY + 18, window.innerHeight - h - 10) + "px"; };
      el.onmouseleave = () => { tip.style.display = "none"; };
      el.onclick = () => itemMenu(el, it);
      el.ondblclick = () => itemMenu(el, it);
    });
    root.querySelectorAll("[data-go]").forEach(b => b.onclick = () => go(b.dataset.go));
    root.querySelectorAll(".bv-p[data-node]").forEach(el => el.onclick = () => tv && tv.focus(el.dataset.node));
    $("#bv-open").onclick = openOther;
    $("#bv-code").onkeydown = e => { if (e.key === "Enter") openOther(); };
    $("#bv-back")?.addEventListener("click", () => { other = null; load(); });
    // one refresh path for the whole tab: account + live gear + tree/skills from Path of Building
    $("#bv-sync")?.addEventListener("click", e => window.P2.refreshBuild(e.currentTarget).then(() => load()).catch(() => {}));
    $("#bv-notree")?.addEventListener("click", async () => {
      try { await api.post("/api/character/pob/open");
        toast("info", "Открыл Path of Building", `Import/Export Build → ${data.active ? data.active.name : "персонаж"} → Import (древо + шмот) → Save. Тула подхватит сама`); }
      catch (err) { toast("err", "Path of Building", err.message); }
    });
  }
  function itemMenu(el, it) {
    const spec = {slot: it.slot_ru, cls: it.slot, base: it.rarity === "Unique" ? undefined : it.base, unique: it.rarity === "Unique" ? it.name : undefined,
      mods: (it.trade_mods && it.trade_mods.length ? it.trade_mods : [...(it.mods.explicit || []), ...(it.mods.implicit || [])]).slice(0, 6),
      budget: it.price_div ? `до ${Math.max(0.1, it.price_div * 1.3).toFixed(1)} div` : undefined};
    if (it.ai && !it.keep) {
      const pop = window.P2.popover(el, `<div class="pk-grp">${esc(it.name)}${it.price_div ? ` · ≈ ${it.price_div} div` : ""}</div>
        <div class="bv-buy"><button class="btn primary" data-a="trade">🛒 Купить<small>трейд со всеми фильтрами и цифрами</small></button>
        ${it.rarity !== "Unique" ? `<button class="btn ${it.craft && it.craft.cheaper ? "primary" : ""}" data-a="craft">⚒ Скрафтить<small>${it.craft ? `≈ ${it.craft.cost_div} div${it.craft.base_priced === false ? " без баз" : ""} · ${esc(it.craft.method)}` : "шаги, шансы и стоимость"}</small></button>` : ""}</div>
        ${it.craft && it.craft.cheaper ? `<div class="kb money" style="margin:6px 4px 0"><span class="ki">⚒</span><div class="kt"><b class="kh">Дешевле скрафтить</b>≈ ${it.craft.cost_div} div вместо ${it.price_div} div на трейде</div></div>`
          : it.craft && it.craft.cheaper_if_base_ex ? `<div class="kb info" style="margin:6px 4px 0"><span class="ki">⚒</span><div class="kt"><b class="kh">Может быть дешевле скрафтить</b>≈ ${it.craft.cost_div} div без белых баз (их ~${Math.round(it.craft.bases)} шт., цены базы на трейде нет) — дешевле ${it.price_div} div, если база ≤ ${it.craft.cheaper_if_base_ex} ex</div></div>` : ""}
        ${it.why ? `<div class="small muted" style="padding:6px 4px 2px">${esc(it.why)}</div>` : ""}`, {width: 340});
      pop.el.querySelectorAll("[data-a]").forEach(b => b.onclick = () => { pop.close(); window.P2.actions[b.dataset.a](spec); });
      return;
    }
    const pop = window.P2.popover(el, `<div class="pk-grp">${esc(it.name)}</div>
      <div class="pk-row" data-a="trade">🔎<div class="pk-txt"><b>Найти похожий на трейде</b><span>те же моды, в пределах бюджета</span></div></div>
      <div class="pk-row" data-a="upgrade">📈<div class="pk-txt"><b>Подобрать апгрейд по PoB</b><span>лоты с трейда, посчитанные в твоём билде</span></div></div>
      ${it.rarity !== "Unique" ? `<div class="pk-row" data-a="craft">⚒<div class="pk-txt"><b>Скрафтить такой</b><span>шансы, шаги и стоимость</span></div></div>` : ""}
      <div class="pk-row" data-a="copy">📋<div class="pk-txt"><b>Скопировать текст предмета</b><span>для PoB или чата</span></div></div>`, {width: 300});
    pop.el.querySelectorAll("[data-a]").forEach(r => r.onclick = async () => {
      pop.close();
      if (r.dataset.a === "copy") { try { await navigator.clipboard.writeText(it.text); toast("ok", "Скопировано"); } catch (_) { toast("err", "Буфер обмена недоступен"); } return; }
      window.P2.actions[r.dataset.a](spec);
    });
  }
  async function openOther() {
    const code = $("#bv-code").value.trim();
    if (!code) { toast("info", "Вставь ссылку pobb.in / poe.ninja или код PoB"); return; }
    const b = $("#bv-open"); spinBtn(b, true, "…");
    try { data = await api.post("/api/buildview/code", {code}); other = code; render(); $("#bv-changes").innerHTML = ""; }
    catch (e) { toast("err", "Билд", e.message); }
    spinBtn(b, false);
  }
  root.querySelector("#bv-refresh").onclick = e => window.P2.refreshBuild(e.currentTarget).then(() => { other = null; load.failed = null; load(); }).catch(() => {});
  async function load() {
    if (other) return;
    $("#bv-doll").innerHTML = `<div class="skel"></div><div class="skel"></div>`;
    try {
      data = mine = await api.get("/api/buildview");
      if (mode === "ai") return showAi();
      if (data.empty && data.active && !load.failed) {
        // the character is on the account: fetch its build right away instead of asking for buttons
        const act = data.active;
        $("#bv-head").innerHTML = (data.foreign ? `<div class="kb warn" style="margin-bottom:6px"><span class="ki">⚠</span><div class="kt"><b class="kh">Сохранённый билд — не ${esc(act.name)}</b>${esc(data.foreign)}. Чужой билд не показываю — пересобираю с аккаунта.</div></div>` : "")
          + window.P2.autoBuildHtml(act.name);
        ["#bv-doll", "#bv-flasks", "#bv-gems", "#bv-stats", "#bv-pass"].forEach(s => $(s).innerHTML = "");
        window.P2.autoBuild(act.id).then(() => load()).catch(e => { load.failed = e.message; load(); });
        return;
      }
      if (data.empty) {
        const act = data.active;
        $("#bv-head").innerHTML = `<div class="kb gem"><span class="ki">🔗</span><div class="kt"><b class="kh">У ${esc(act ? act.name : "персонажа")} ещё нет билда</b>
          ${load.failed ? `<span style="color:var(--amber)">${esc(load.failed)}</span><br>` : ""}Тула повторит загрузку сама. Пока можно вставить код PoB / ссылку pobb.in.
          <div class="row" style="margin-top:8px"><button class="btn sm primary" id="bv-ggg">⟳ Загрузить снова</button><button class="btn sm" id="bv-pob">Вставить код PoB</button>
          <input class="inp" id="bv-code" placeholder="или открыть чужой билд по ссылке" style="width:280px"><button class="btn sm" id="bv-open">Открыть</button></div></div></div>`;
        ["#bv-doll", "#bv-flasks", "#bv-gems", "#bv-stats", "#bv-pass"].forEach(s => $(s).innerHTML = "");
        $("#bv-ggg").onclick = () => { load.failed = null; load(); };
        setTimeout(() => { if (load.failed) { load.failed = null; if (!other && mode !== "ai") load(); } }, 120000);
        $("#bv-pob").onclick = () => window.P2.addCharacter("pob");
        $("#bv-open").onclick = openOther;
        return;
      }
      render();
      renderDeep();
      renderChanges();
    } catch (e) { $("#bv-doll").innerHTML = `<div class="kb warn"><span class="ki">⚠</span><div class="kt">${esc(e.message)}</div></div>`; }
  }
  // what the last refresh changed: items per slot, passives, gems, the level, and PoB's numbers before and after
  async function renderChanges() {
    const box = $("#bv-changes");
    if (mode !== "mine" || other) { box.innerHTML = ""; return; }
    let c; try { c = await api.get("/api/buildview/changes"); } catch (_) { box.innerHTML = ""; return; }
    if (!c || !c.has) { box.innerHTML = ""; return; }
    const pct = v => (v >= 0 ? "+" : "") + v + "%";
    const nodes = k => { const big = c.nodes[k].filter(n => n.k !== "normal").map(n => esc(n.ru)), small = c.nodes[k].length - big.length;
      return [big.join(", "), small ? fmt.n(small, "малая нода|малые ноды|малых нод") : ""].filter(Boolean).join(" и "); };
    box.innerHTML = `<details class="card" style="margin-bottom:12px"><summary class="small" style="cursor:pointer"><b>⟳ Что изменилось с прошлого обновления</b> <span class="muted">(${fmt.ago(c.when)})</span>${c.stats ? ` · DPS <b class="${c.stats.dps >= 0 ? "up" : "down"}">${pct(c.stats.dps)}</b> · EHP <b class="${c.stats.ehp >= 0 ? "up" : "down"}">${pct(c.stats.ehp)}</b>` : ""}</summary>
      <div class="small" style="margin-top:8px">
        ${c.items.map(i => `<div>🛡 ${esc(i.slot)}: ${i.before ? `«${esc(i.before)}»` : "пусто"} → ${i.after ? `«${esc(i.after)}»` : "пусто"}</div>`).join("")}
        ${c.nodes.added.length ? `<div>🌳 взято: ${nodes("added")}</div>` : ""}${c.nodes.removed.length ? `<div>🌳 снято: ${nodes("removed")}</div>` : ""}
        ${c.gems.added.length ? `<div>💎 новые камни: ${c.gems.added.map(esc).join(", ")}</div>` : ""}${c.gems.removed.length ? `<div>💎 убраны: ${c.gems.removed.map(esc).join(", ")}</div>` : ""}
        ${c.level.before !== c.level.after ? `<div>⬆ уровень ${esc(String(c.level.before))} → ${esc(String(c.level.after))}</div>` : ""}
      </div></details>`;
  }
  // ───── «Как видит ИИ» ─────
  function aiAsData(a) {
    const act = (mine && mine.active) || null;
    return {ai: true, active: act, portrait: mine && mine.portrait, ascendancy_ru: (mine && mine.ascendancy_ru) || a.ascendancy || "", class_ru: mine && mine.class_ru,
      level: (mine && mine.level) || (act && act.level), items: a.items || [], gems: a.gems || [], nodes: a.nodes || [], plan: a.plan, picked: a.picked,
      targets: a.targets, steps: a.steps, total_div: a.total_div, budget_div: a.budget_div, over: a.over,
      class: mine && mine.class, ascendancy: a.ascendancy, passives: {}};
  }
  function verifyHtml(v, attempt) {
    if (!v) return "";
    if (!v.available) return `<div class="kb skip"><span class="ki">🧪</span><div class="kt"><b class="kh">Проверка в Path of Building</b>${esc(v.reason || "")}</div></div>`;
    const sign = x => (x >= 0 ? "+" : "") + x.toFixed(0) + "%";
    return `<div class="kb ${v.ok ? "node" : "warn"}"><span class="ki">🧪</span><div class="kt"><b class="kh">Проверено в Path of Building на твоём билде${attempt === 2 ? " · исправлено со 2-й попытки" : ""}</b>
      DPS <b class="${v.dps >= 0 ? "up" : "down"}">${sign(v.dps)}</b> · EHP <b class="${v.ehp >= 0 ? "up" : "down"}">${sign(v.ehp)}</b>
      · резисты ${["FireResist", "ColdResist", "LightningResist", "ChaosResist"].map(k => `<b class="${(v.after[k] || 0) >= 75 || k === "ChaosResist" ? "up" : "down"}">${Math.round(v.after[k] || 0)}%</b>`).join(" / ")}
      ${v.problems.length ? `<div class="small" style="margin-top:4px">${v.problems.map(p => "⚠ " + esc(p)).join("<br>")}</div>` : `<div class="small up">Каждый предмет усиливает билд — можно брать.</div>`}</div></div>`;
  }
  async function showAi() {
    $("#bv-aibar").hidden = false;
    $("#bv-changes").innerHTML = "";
    if (!aiData) aiData = await api.get("/api/buildview/ai").catch(() => ({}));
    if (!aiData || !aiData.items) {
      $("#bv-aisum").innerHTML = `<div class="kb money"><span class="ki">💰</span><div class="kt">Впиши бюджет и нажми «Собрать билд» — ИИ соберёт полный билд для
        ${esc(mine && mine.active ? mine.active.name : "твоего персонажа")}: шмот с картинками и ценами, камни, древо. Клик по предмету — купить или скрафтить.</div></div>`;
      ["#bv-doll", "#bv-flasks", "#bv-gems", "#bv-stats", "#bv-pass"].forEach(x => $(x).innerHTML = "");
      $("#bv-head").innerHTML = "";
      return;
    }
    $("#bv-aisum").innerHTML = `<div class="row" style="gap:8px"><b style="font-size:16px">✦ ${esc(aiData.title)}</b><span class="pill money">${esc(aiData.budget)}</span>
        <span class="pill ${aiData.over ? "warn" : "node"}">итого ≈ ${aiData.total_div} div</span><span class="tiny faint">${new Date(aiData.made * 1000).toLocaleString("ru")}</span></div>
      <div class="kb info"><span class="ki">ℹ</span><div class="kt">${esc(aiData.summary)}</div></div>
      ${verifyHtml(aiData.verify, aiData.attempt)}
      ${aiData.budget_plan && aiData.budget_plan.pending ? `<div class="kb money" id="bv-mkt"><span class="ki"><span class="spin-s"></span></span><div class="kt"><b class="kh">Ищу реальные лоты на трейде под ${aiData.budget_div} div</b>
        каждый лот надевается в PoB на твой билд; начинаю с самых слабых слотов. Лимит запросов GGG — несколько минут, билд обновится сам.<span id="bv-mkt-p"></span></div></div>` : ""}
      ${aiData.budget_plan && aiData.budget_plan.error ? `<div class="kb skip"><span class="ki">🛒</span><div class="kt">${esc(aiData.budget_plan.error)}</div></div>` : ""}
      ${aiData.budget_plan && aiData.budget_plan.real_lots != null ? `<div class="kb money"><span class="ki">🛒</span><div class="kt"><b class="kh">Бюджет: потрачено ${aiData.budget_plan.spent_div} из ${aiData.budget_div} div</b>
        ${aiData.budget_plan.real_lots ? `${aiData.budget_plan.real_lots} слот(ов) — реальные лоты с трейда, измеренные в PoB (помечены 🛒). ` : ""}
        ${aiData.budget_plan.left_div > aiData.budget_div * 0.15 ? `Остаток ${aiData.budget_plan.left_div} div: на рынке в бюджете нет лотов, которые ещё заметно усилят билд (замер PoB по каждому слоту).` : "Бюджет использован почти полностью."}
        ${(aiData.budget_plan.keep || []).length ? `<div class="tiny muted" style="margin-top:4px">Почему не другие слоты (замер PoB): ${aiData.budget_plan.keep.map(k => esc(k.slot) + " — " + esc(k.why)).join("; ")}</div>` : ""}</div></div>` : ""}`;
    data = aiAsData(aiData);
    render();
    renderReview();
    renderDeep();
    treePlan();
  }
  // the AI's own opinion of the player's build — what it likes, what it doesn't
  // deep PoB analysis of the real build (mine mode)
  let deepTimer = null;
  window.addEventListener("p2:weapon-roles", () => { load(); });
  async function renderDeep() {
    clearTimeout(deepTimer);
    if (other || !mine || mine.empty) return;
    if (!root.offsetParent) return;  // the tab is hidden: stop polling (load() on the next visit starts it again)
    let d;
    try { d = await api.get("/api/buildview/deep"); } catch (_) { return; }
    if (other) return;
    if (d.pending) {
      $("#bv-deep").innerHTML = `<div class="card" style="margin-top:16px"><div class="kb gem"><span class="ki"><span class="spin-s"></span></span><div class="kt"><b class="kh">Глубокий разбор в Path of Building</b>
        ~20 проб усиления, вклад каждого мода и каждой поддержки — около минуты, покажу сам</div></div></div>`;
      deepTimer = setTimeout(renderDeep, 5000);
      return;
    }
    if (!d.empty) $("#bv-deep").innerHTML = window.P2.deepHtml(d, mode === "ai" ? "твоего настоящего билда (не ИИ-сборки)" : "");
  }
  function renderReview() {
    const r = mode === "ai" && aiData && aiData.review;
    $("#bv-review").innerHTML = r ? `<div class="card" style="margin-top:16px"><div class="sec-h" style="--k:var(--k-act)"><span class="si">🗣</span><div><h3>Мнение ИИ о твоём билде</h3>
        <div class="sd">что нравится, что нет и что делать; строки с числами не из замеров PoB или с модами, которых у такого предмета не бывает, тула убирает</div></div></div>
      <div class="grid g2">
        <div>${(r.likes || []).map(x => `<div class="kb node" style="margin:4px 0"><span class="ki">👍</span><div class="kt">${esc(x)}</div></div>`).join("") || ""}</div>
        <div>${(r.dislikes || []).map(x => `<div class="kb warn" style="margin:4px 0"><span class="ki">👎</span><div class="kt">${esc(x)}</div></div>`).join("") || ""}</div></div>
      ${r.verdict ? `<div class="kb info" style="margin-top:8px"><span class="ki">✦</span><div class="kt"><b class="kh">Итог</b>${esc(r.verdict)}</div></div>` : ""}
      ${r.removed ? `<div class="tiny faint" style="margin-top:6px">✂ убрано строк без опоры на замер: ${r.removed}</div>` : ""}</div>` : "";
  }
  // tree changes for the AI view: computed in Path of Building on the real build (red — take off, green — take)
  let planFor = null;
  async function treePlan() {
    if (!aiData || !mine || mine.empty || (mine.nodes || []).length < 5) return;
    const key = aiData.made;
    if (aiData.tree_plan) { showPlan(aiData.tree_plan); return; }
    if (planFor === key) return;
    planFor = key;
    const box = document.createElement("div");
    box.id = "bv-tplan";
    $("#bv-tree").after(box);
    box.innerHTML = `<div class="kb gem" style="margin-top:8px"><span class="ki"><span class="spin-s"></span></span><div class="kt"><b class="kh">Считаю в Path of Building, какие очки перекинуть</b><span id="bv-tprog">перебираю варианты…</span></div></div>`;
    const prog = setInterval(async () => { try { const p = await api.get("/api/tree/plan/progress");
      const el = root.querySelector("#bv-tprog"); if (el && p.running) el.textContent = `${p.step}: ${p.done} из ${p.total} расчётов PoB`; } catch (_) {} }, 1500);
    try {
      const p = await api.post("/api/tree/plan", {goal: $("#bv-wish").value || ""});
      if (aiData && aiData.made === key) { aiData.tree_plan = p; if (mode === "ai") showPlan(p); }
    } catch (e) { box.innerHTML = `<div class="kb warn" style="margin-top:8px"><span class="ki">⚠</span><div class="kt">План древа не посчитался: ${esc(e.message)}</div></div>`; }
    clearInterval(prog);
  }
  function showPlan(p) {
    if (tv) { tv.setAllocated((mine.nodes || []).map(String), {cls: mine.class}); tv.setPlan(p); const ns = [...p.remove, ...p.add].map(x => tv.L.byId[x.id]).filter(Boolean); if (ns.length) tv.fit(ns); }
    let box = root.querySelector("#bv-tplan");
    if (!box) { box = document.createElement("div"); box.id = "bv-tplan"; $("#bv-tree").after(box); }
    const ck = p.check || {}, rem = p.remove.filter(x => x.main), add = p.add.filter(x => x.main);
    const name = x => esc(x.ru || x.name || x.id);
    box.innerHTML = rem.length || add.length ? `<div class="kb ${ck.ok ? "node" : "warn"}" style="margin-top:8px"><span class="ki">🌳</span><div class="kt">
        <b class="kh">Древо: что перекинуть (посчитано в Path of Building)</b>${p.summary ? esc(p.summary) + "<br>" : ""}
        DPS <b class="${ck.dps >= 0 ? "up" : "down"}">${ck.dps >= 0 ? "+" : ""}${ck.dps}%</b> · EHP <b class="${ck.ehp >= 0 ? "up" : "down"}">${ck.ehp >= 0 ? "+" : ""}${ck.ehp}%</b>
        <div class="row" style="gap:6px;flex-wrap:wrap;margin-top:6px">${rem.map(x => `<span class="pill warn">− ${name(x)}</span>`).join("")}${add.map(x => `<span class="pill node">+ ${name(x)}</span>`).join("")}</div></div></div>`
      : `<div class="kb info" style="margin-top:8px"><span class="ki">🌳</span><div class="kt">PoB не нашёл в древе перестановки, которая усилит билд без потери защиты — древо собрано хорошо.</div></div>`;
  }
  root.querySelectorAll(".bv-mode button").forEach(b => b.onclick = async () => {
    mode = b.dataset.m;
    root.querySelectorAll(".bv-mode button").forEach(x => x.classList.toggle("on", x === b));
    $("#bv-mode-hint").textContent = mode === "ai" ? "идеальный билд под твой бюджет — так его видит ИИ" : "реальный билд из игры / PoB";
    $("#bv-aibar").hidden = mode !== "ai";
    if (mode === "ai") { if (!mine) await load(); else showAi(); }
    else { other = null; data = mine; root.querySelector("#bv-tplan")?.remove(); $("#bv-review").innerHTML = ""; $("#bv-deep").innerHTML = ""; if (mine && !mine.empty) { render(); renderDeep(); renderChanges(); } else load(); }
  });
  $("#bv-gen").onclick = async e => {
    const amount = +$("#bv-amt").value;
    if (!amount) { toast("info", "Впиши бюджет", "например 20 и выбери Divine"); $("#bv-amt").focus(); return; }
    const b = e.currentTarget; spinBtn(b, true, "ИИ собирает билд… (до минуты)");
    try { aiData = await api.post("/api/buildview/ai", {amount, currency: curPick ? curPick.value : "divine", wish: $("#bv-wish").value}); showAi(); }
    catch (err) { toast("err", "Билд от ИИ", err.message); }
    spinBtn(b, false);
  };
  (async () => {
    try {
      const pr = await api.get("/api/character/profiles");
      const a = pr.profiles.find(p => p.id === pr.active);
      curPick = await window.P2.currencyPicker($("#bv-cur"), {value: (a && a.budget_currency) || "divine"});
      if (a && a.budget_amount) $("#bv-amt").value = a.budget_amount;
    } catch (_) { /* optional prefill */ }
  })();
  // real trade listings for the AI build arrive in the background
  let mktV = null;
  onLive(st => {
    const m = st.aimkt;
    if (!m) return;
    const p = document.getElementById("bv-mkt-p");
    if (p && m.running) p.textContent = ` Сейчас: ${m.slot || "…"} (${m.done}/${m.total})${m.eta > 30 ? `, лимиты трейда: ещё ≈ ${Math.ceil(m.eta / 60)} мин` : ""}.`;
    if (mktV !== null && m.v !== mktV && mode === "ai") {
      aiData = null; showAi();
      toast("ok", "🛒 Реальные лоты добавлены в ИИ-билд", "каждый измерен в PoB на твоём билде");
    }
    mktV = m.v;
  });
  // the AI build changes only by this tab's own button, or while its market search is still running: only then re-fetch
  registerModule({id: "build_view", onShow: () => { if (aiData && aiData.budget_plan && aiData.budget_plan.pending) aiData = null; load(); }});
})();
