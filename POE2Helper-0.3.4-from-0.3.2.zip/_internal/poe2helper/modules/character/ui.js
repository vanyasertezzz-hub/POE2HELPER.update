(function () {
  "use strict";
  const {api, esc, spinBtn, registerModule, onLive, toast, go} = window.P2;
  const root = document.getElementById("character-root");
  root.innerHTML = `
    <div class="grid g3" style="margin-bottom:16px">
      <div class="card glow" style="grid-column:span 2"><div class="sec-h" style="--k:var(--k-info)"><span class="si">👤</span>
          <div><h3>Мои персонажи</h3><div class="sd">активный — под него подстраивается вся тула: билд, древо, советы, цены лиги</div></div>
          <span class="spacer"></span><label class="small row" style="gap:6px"><input type="checkbox" id="pf-follow"> следовать за игрой</label>
          <button class="btn sm" id="pf-sync">⟳ Обновить</button><button class="btn sm primary" id="pf-new">+ Добавить</button></div>
        <div id="pf-list" class="grid g3"></div><div id="pf-err" class="small" style="margin-top:8px;color:var(--amber)"></div></div>
      <div class="card"><div class="sec-h" style="--k:var(--k-gem)"><span class="si">🔗</span><div><h3>Аккаунт pathofexile.com</h3>
          <div class="sd">все персонажи по лигам + шмот, камни и древо</div></div></div><div id="pf-ggg"></div></div>
    </div>
    <div id="pf-edit" hidden></div>
    <div class="grid g3">
      <div class="card"><div class="sec-h" style="--k:var(--k-node)"><span class="si">🎮</span><div><h3>Сейчас в игре</h3><div class="sd">по логу игры Client.txt</div></div></div><div id="ch-live"></div></div>
      <div class="card"><div class="sec-h" style="--k:var(--k-reward)"><span class="si">⭐</span><div><h3>Постоянные бонусы</h3><div class="sd">награды кампании, замеченные в этой сессии</div></div></div><div id="ch-gains"></div></div>
      <div class="card"><div class="sec-h" style="--k:var(--k-act)"><span class="si">📜</span><div><h3>События</h3><div class="sd">уровни, смерти, зоны, личные сообщения</div></div></div>
        <div id="ch-events" class="small" style="max-height:280px;overflow:auto"></div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="sec-h" style="--k:var(--k-warn)"><span class="si">☠</span><div><h3>Разбор смертей</h3>
        <div class="sd">после каждой смерти: зона, цифры PoB и какой слой защиты подвёл — с кнопками, где купить исправление</div></div>
        <span class="spacer"></span><button class="btn sm" id="ch-death-test">Проверить сейчас</button></div><div id="ch-death-list"></div></div>
    <div class="card" style="margin-top:16px"><div class="sec-h" style="--k:var(--k-info)"><span class="si">🗓</span><div><h3>Хроника по дням</h3>
        <div class="sd">из лога игры: уровни, смерти и где, сколько зон и сколько времени в игре</div></div>
        <span class="spacer"></span><select id="ch-tl-days" class="sm"><option value="30">30 дней</option><option value="90">90 дней</option></select></div>
        <div id="ch-timeline" style="max-height:420px;overflow:auto"></div></div>`;
  const $ = s => root.querySelector(s);
  let PF = null;
  const SRC = {log: ["лог игры", "info"], ggg: ["аккаунт GGG", "gem"], pob: ["PoB", "node"]};

  let lastLive = null;  // the live block drew before the profiles came: the log's class stood next to the card's
  const renderLive = st => {
    lastLive = st;
    const l = st.log || {};
    const lp = (PF && PF.profiles.find(p => p.name === l.character)) || {name: l.character};
    $("#ch-live").innerHTML = l.connected ? `<div class="row" style="gap:12px">${window.P2.avatar(lp, 46)}
        <div><b style="font-size:16px">${esc(l.character || "—")}</b><div class="small muted">${esc(lp.ascendancy_ru || l.class_raw || l.class || "")} · ${lp.level || l.level || "?"} уровень</div></div></div>
      <div class="kb info"><span class="ki">📍</span><div class="kt"><b class="kh">Зона</b>${esc(l.area || "—")} <span class="muted">(ур. ${l.area_level || "?"})</span></div></div>
      <div class="kb ${l.deaths ? "warn" : "node"}"><span class="ki">☠</span><div class="kt"><b class="kh">Смертей за сессию</b>${l.deaths}</div></div>`
      : `<div class="kb warn"><span class="ki">⚠</span><div class="kt">Client.txt не найден. Укажи путь в «Настройки → Игра и аккаунт».</div></div>`;
    api.get("/api/character/live").then(d => {
      const icon = {death: ["☠", "warn"], level: ["⬆", "node"], area: ["📍", "info"], whisper: ["✉", "money"], gain: ["⭐", "reward"]};
      $("#ch-events").innerHTML = d.events.slice().reverse().slice(0, 60).map(e => { const [ic, k] = icon[e.type] || ["•", "info"];
        return `<div class="row" style="padding:4px 0;border-bottom:1px solid var(--line)"><span class="pill ${k}">${ic}</span><span style="flex:1">${esc(e.text)}</span><span class="faint tiny">${esc(window.P2.evTime(e.time))}</span></div>`; }).join("") || `<div class="muted">Пока тихо</div>`;
      $("#ch-gains").innerHTML = d.gains.slice().reverse().map(g => `<div class="kb reward"><span class="ki">⭐</span><div class="kt">${esc(g.text)}<div class="tiny faint">${esc(g.time.slice(5, 16))}</div></div></div>`).join("")
        || `<div class="small muted">В этой сессии бонусов не было. Здесь появятся +дух, +резисты, +здоровье за боссов кампании.</div>`;
    }).catch(() => {});
  };
  onLive(renderLive);

  const label = p => [p.ascendancy_ru || p.class_ru || p.ascendancy || p.class || "класс ?", p.level ? `${p.level} ур.` : ""].filter(Boolean).join(" · ");
  async function loadProfiles() {
    PF = await api.get("/api/character/profiles");
    if (lastLive) renderLive(lastLive);
    $("#pf-follow").checked = PF.auto_follow;
    if (PF.ggg && PF.ggg.site && PF.ggg.site.need_login && PF.ggg.can_window) {
      // characters of all leagues come from pathofexile2.com: its login is the one thing missing
      $("#pf-err").innerHTML = window.P2.needLoginHtml(PF.ggg);
      window.P2.wireGgg($("#pf-err"), async () => { await loadProfiles(); window.P2.afterCharChange(); });
    } else $("#pf-err").textContent = PF.sync_error ? `Аккаунт GGG: ${PF.sync_error}` : "";
    $("#pf-list").innerHTML = PF.profiles.map(p => {
      const on = p.id === PF.active;
      return `<div class="card" style="padding:14px;${on ? "border-color:var(--accent2);box-shadow:0 0 0 2px var(--accentSoft)" : ""}">
        <div class="row" style="gap:10px">${window.P2.avatar(p, 46)}<div style="flex:1;min-width:0"><b style="font-size:15px;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(p.name)}">${esc(p.name)}</b>
          <div class="small muted">${esc(label(p))}</div></div>${on ? `<span class="pill node">активный</span>` : ""}</div>
        <div class="row" style="gap:4px;margin-top:8px;flex-wrap:wrap">${p.playing ? `<span class="pill node">▶ в игре</span>` : ""}
          ${p.league ? `<span class="pill info">${esc(p.league)}</span>` : ""}
          ${(p.sources || []).map(s => `<span class="pill ${(SRC[s] || ["", "info"])[1]}">${esc((SRC[s] || [s])[0])}</span>`).join("")}
          ${(p.main_skill || p.skill) ? `<span class="pill gem" title="${p.main_skill ? "основной скилл в билде PoB" : "указан вручную"}">💎 ${esc(p.main_skill || p.skill)}</span>` : ""}
          ${p.budget_amount ? `<span class="pill money">💰 ${p.budget_amount} ${esc({divine: "div", exalted: "ex", chaos: "chaos"}[p.budget_currency || "divine"])}</span>` : ""}
          ${p.build_problem
            ? `<span class="pill warn" title="${esc(p.build_problem)} — все цифры для этого персонажа были бы неверными">⚠ билд неверный: ${esc(p.build_problem)}</span>`
            : `<span class="pill ${p.build_file ? "item" : "skip"}">${p.build_file ? "🛡 билд PoB есть" : "без билда PoB"}</span>`}</div>
        ${p.build_problem ? `<div class="tiny" style="margin-top:6px;color:var(--k-warn)">Нажми «⬇ Из GGG» в окне тулы — шмот возьмётся с сайта pathofexile2.com.</div>` : ""}
        <div class="row" style="margin-top:10px;flex-wrap:wrap">${on ? `<button class="btn sm primary" data-go="build_view">Открыть билд</button>` : `<button class="btn sm primary" data-act="${p.id}">Играю им</button>`}
          ${PF.ggg.connected && (p.sources || []).includes("ggg") ? `<button class="btn sm" data-imp="${p.id}" title="Шмот, камни и древо с pathofexile.com → Path of Building">⬇ Из GGG</button>` : ""}
          <button class="btn sm ghost" data-edit="${p.id}">Изменить</button><button class="btn sm ghost danger" data-del="${p.id}" title="Убрать из списка">✕</button></div></div>`;
    }).join("") || `<div class="kb info"><span class="ki">ℹ</span><div class="kt">Персонажей пока нет. Нажми «+ Добавить»: войди в аккаунт GGG, выбери из лога игры или вставь код PoB.</div></div>`;
    $("#pf-ggg").innerHTML = await window.P2.gggConnectHtml(PF.ggg);
    window.P2.wireGgg($("#pf-ggg"), async () => { await loadProfiles(); window.P2.afterCharChange(); });
    root.querySelectorAll("[data-act]").forEach(b => b.onclick = async () => { await api.post(`/api/character/profiles/${b.dataset.act}/activate`);
      toast("ok", "Активный персонаж сменён", "вся тула подстроилась"); await window.P2.afterCharChange(); });
    root.querySelectorAll("[data-go]").forEach(b => b.onclick = () => go(b.dataset.go));
    root.querySelectorAll("[data-imp]").forEach(b => b.onclick = async () => { spinBtn(b, true, "Импорт…");
      try { const r = await api.post(`/api/character/profiles/${b.dataset.imp}/import`); toast("ok", "Шмот, камни и древо подтянуты", r.build_file); await loadProfiles(); window.P2.afterCharChange(); }
      catch (err) { toast("err", "Импорт из GGG", err.message); spinBtn(b, false); } });
    root.querySelectorAll("[data-edit]").forEach(b => b.onclick = () => edit(PF.profiles.find(p => p.id === b.dataset.edit)));
    root.querySelectorAll("[data-del]").forEach(b => b.onclick = async () => {
      if (!await window.P2.dialog({title: "Убрать персонажа из списка?", text: "Сам персонаж и билды не удаляются, автоматически он больше не добавится.", ok: "Убрать", danger: true})) return;
      await api.del(`/api/character/profiles/${b.dataset.del}`); await loadProfiles(); window.P2.afterCharChange();
    });
  }
  async function edit(p) {
    const c = await window.P2.choices(true);
    const box = $("#pf-edit"); box.hidden = false;
    box.innerHTML = `<div class="card" style="margin-bottom:16px;border-color:var(--accent2)"><div class="sec-h"><span class="si">✎</span><h3>${esc(p.name)}: настройки</h3>
        <span class="sd">уровень, класс и лига обновляются сами из игры и аккаунта</span></div>
      <div class="grid g3">
        <div class="field"><label>Класс / восхождение</label><button id="pe-class"></button></div>
        <div class="field"><label>Основной скилл</label><button id="pe-skill"></button></div>
        <div class="field"><label>Билд Path of Building</label>${window.P2.selectHtml("build_file", c.builds.map(b => [b.file, `${b.name} — ${b.ascendancy || b.class || ""} ${b.level || ""}`]), {value: p.build_file || "", empty: "— без билда —"})}</div>
        <div class="field"><label>Лига</label>${window.P2.selectHtml("league", c.leagues, {value: p.league || "", empty: "— как в аккаунте / текущая —"})}</div>
        <div class="field"><label>💰 Бюджет на билд</label><div class="row"><input class="inp" name="budget_amount" type="number" min="0" step="1" value="${p.budget_amount ?? ""}" placeholder="сумма" style="flex:1">
          <button id="pe-cur" style="width:170px"></button></div></div>
        <div class="field"><label>Заметка</label><input class="inp" name="note" value="${esc(p.note || "")}" placeholder="напр. «качаю под боссов»"></div>
      </div><div class="row end"><button class="btn ghost" id="pe-cancel">Отмена</button><button class="btn primary" id="pe-save">Сохранить</button></div></div>`;
    const cls = await window.P2.classPicker(box.querySelector("#pe-class"), {value: p.ascendancy || p.class || ""});
    const sk = await window.P2.gemPicker(box.querySelector("#pe-skill"), {value: p.skill || ""});
    const cur = await window.P2.currencyPicker(box.querySelector("#pe-cur"), {value: p.budget_currency || "divine"});
    box.querySelector("#pe-cancel").onclick = () => { box.hidden = true; };
    box.querySelector("#pe-save").onclick = async () => {
      const q = n => box.querySelector(`[name=${n}]`);
      await api.post("/api/character/profiles", {id: p.id, name: p.name, ascendancy: cls.value, skill: sk.value, level: p.level || null,
        build_file: window.P2.selectValue(box, "build_file"), league: window.P2.selectValue(box, "league"), note: q("note").value,
        budget_amount: q("budget_amount").value ? +q("budget_amount").value : null, budget_currency: cur.value});
      box.hidden = true; toast("ok", "Сохранено", p.name);
      await loadProfiles(); window.P2.afterCharChange();
    };
    box.scrollIntoView({behavior: "smooth", block: "nearest"});
  }
  $("#pf-new").onclick = () => window.P2.addCharacter();
  $("#pf-follow").onchange = async e => { await api.post("/api/character/follow", {on: e.target.checked});
    toast("ok", e.target.checked ? "Тула сама переключается на персонажа, которым ты играешь" : "Автопереключение выключено"); };
  $("#pf-sync").onclick = async e => { const b = e.currentTarget; spinBtn(b, true);
    try { await api.post("/api/character/profiles/sync"); } catch (err) { toast("err", "Обновление", err.message); }
    spinBtn(b, false); await loadProfiles(); window.P2.afterCharChange(); };

  function deathHtml(r) {
    return `<div class="card" style="padding:12px;margin-bottom:8px;border-left:3px solid var(--k-warn)"><div class="row"><b>☠ ${esc(r.area_ru || r.area || "?")}</b><span class="pill info">зона ${r.area_level ?? "?"}</span>
        <span class="pill node">ур. ${r.level ?? "?"}</span><span class="spacer"></span><span class="tiny faint">${esc(r.time || "")}</span></div>
      ${r.weak.map(w => `<div class="kb warn"><span class="ki">⚠</span><div class="kt">${esc(w.text)}</div>${w.action ? `
        <button class="btn sm" data-p2act="trade" data-spec="${esc(JSON.stringify(w.action))}">🔎 Трейд</button>
        <button class="btn sm ghost" data-p2act="upgrade" data-spec="${esc(JSON.stringify(w.action))}">📈 PoB</button>` : ""}</div>`).join("")}
      ${r.note ? `<div class="md small" style="margin-top:6px">${window.P2.md(r.note)}</div>` : ""}</div>`;
  }
  async function loadDeaths() {
    const list = await api.get("/api/character/deaths");
    $("#ch-death-list").innerHTML = list.slice(0, 5).map(deathHtml).join("") || `<div class="small muted">Смертей пока не было (или тула не была запущена). Разбор появится сам.</div>`;
  }
  $("#ch-death-test").onclick = async e => {
    const btn = e.currentTarget; spinBtn(btn, true, "Анализирую…");
    try { await api.post("/api/character/deaths/test"); await loadDeaths(); } catch (err) { toast("err", "Разбор", err.message); }
    spinBtn(btn, false);
  };
  const hm = m => m >= 60 ? `${Math.floor(m / 60)} ч ${m % 60} мин` : `${m} мин`;
  function charLine(c) {
    const who = c.name === "—" ? `<span class="muted" title="лог называет персонажа только при новом уровне или смерти">персонаж не определён</span>` : `<b>${esc(c.name)}</b>${c.class ? ` <span class="tiny faint">${esc(c.class)}</span>` : ""}`;
    const bits = [];
    if (c.level_to != null) bits.push(c.level_to > c.level_from ? `ур. ${c.level_from} → ${c.level_to}` : `ур. ${c.level_to}`);
    if (c.areas) bits.push(`зон: ${c.areas}`);
    if (c.deaths) bits.push(`<span style="color:var(--k-warn)">☠ ${c.deaths}${c.death_areas.length ? ` — ${esc(c.death_areas.join(", "))}` : ""}</span>`);
    return `<div class="small" style="margin:2px 0 2px 12px">${who} · ${bits.join(" · ")}</div>`;
  }
  async function loadTimeline() {
    let t;
    const days = $("#ch-tl-days").value;
    try { t = await api.get(`/api/character/timeline?days=${days}`); } catch (err) { $("#ch-timeline").innerHTML = `<div class="small muted">${esc(err.message)}</div>`; return; }
    $("#ch-timeline").innerHTML = t.note ? `<div class="small muted">${esc(t.note)}</div>`
      : t.days.map(d => `<div style="margin-bottom:8px"><div class="row"><b>${esc(d.day.split("-").reverse().join("."))}</b><span class="spacer"></span>
          <span class="tiny faint">в игре ${hm(d.minutes)}</span></div>${d.chars.map(charLine).join("")}</div>`).join("")
        || `<div class="small muted">За ${days} дней в логе игры нет ни одной зоны — игра не запускалась.</div>`;
  }
  $("#ch-tl-days").onchange = loadTimeline;
  registerModule({id: "character", onShow: () => { loadProfiles(); loadDeaths(); loadTimeline(); }});
})();
