(function () {
  "use strict";
  const {api, esc, fmt, itemCard, registerModule, onLive, go} = window.P2;
  const root = document.getElementById("dash-root");
  root.innerHTML = `
    <div class="d-hero">
      <div class="card glow" id="d-me"><div class="skel"></div></div>
      <div class="card" id="d-build"><div class="skel"></div></div>
      <div class="grid" style="gap:12px">
        <div class="card"><div class="stat"><b id="d-div">—</b><span>Exalted за 1 Divine</span></div><div class="small muted" id="d-chaos"></div></div>
        <div class="card"><div class="row"><div class="stat"><b id="d-maps">—</b><span>карт за 12 ч</span></div><span class="spacer"></span>
          <div class="stat" style="text-align:right"><b id="d-kb">—</b><span>в базе знаний</span></div></div><div class="small muted" id="d-maps-sub"></div><div class="tiny faint" id="d-kb-sub"></div></div>
      </div>
    </div>
    <div class="grid g3" style="margin-top:16px">
      <div class="card" style="grid-column:span 2"><h3>Валюта <span class="muted small" id="d-league"></span><span class="spacer"></span>
        <button class="btn sm ghost" id="d-to-price">Вся биржа →</button></h3>
        <table class="tbl"><thead><tr><th>Предмет</th><th style="text-align:right">Exalted</th><th style="text-align:right">Divine</th><th style="text-align:right">7 дней</th></tr></thead><tbody id="d-cur"><tr><td colspan="4"><div class="skel"></div><div class="skel"></div></td></tr></tbody></table></div>
      <div class="grid">
        <div class="card"><h3>Последний скопированный предмет</h3><div id="d-clip" class="empty">Наведи на предмет в игре и нажми <kbd>Ctrl D</kbd> (оверлей) или <kbd>Ctrl C</kbd></div></div>
        <div class="card"><h3>События игры</h3><div id="d-events" class="small"></div></div>
      </div>
    </div>
    <div class="card" style="margin-top:16px" id="d-today"></div>
    <div class="card" style="margin-top:16px" id="d-learn"></div>
    <div class="grid g4" style="margin-top:16px" id="d-quick"></div>`;

  const quick = [
    ["assistant", "Спросить ассистента", "любой вопрос по игре — с базой знаний"],
    ["build", "Собрать билд", "пошаговый план от уровня до эндгейма"],
    ["craft", "Скрафтить предмет", "шансы, цена попытки, шаги"],
    ["farm", "Что фармить", "рейтинг механик по ценам прямо сейчас"],
  ];
  document.getElementById("d-quick").innerHTML = quick.map(q => `<div class="card" style="cursor:pointer" data-go="${q[0]}"><b>${q[1]}</b><div class="small muted">${q[2]}</div></div>`).join("");
  root.querySelectorAll("[data-go]").forEach(el => el.onclick = () => go(el.dataset.go));
  document.getElementById("d-to-price").onclick = () => go("price");

  // what the tool has learned: applied advice and its real effect, forecast accuracy, fixed AI mistakes
  // three cards from what the tool already measured: the build's main step, the craft that pays, the farm by your hours
  async function loadToday() {
    const box = root.querySelector("#d-today");
    let r; try { r = await api.get("/api/dash/today"); } catch (_) { box.hidden = true; return; }
    const ICON = {build: "🛡", craft: "💰", farm: "🗺"}, KIND = {build: "node", craft: "reward", farm: "act"};
    box.innerHTML = `<div class="sec-h" style="--k:var(--k-reward)"><span class="si">☀</span><div><h3>Что сделать сегодня</h3>
        <div class="sd">из уже посчитанного: главный шаг для билда, крафт, который окупается, и фарм по твоим часам игры</div></div></div>
      <div class="grid g3">${r.cards.map(c => `<div class="kb ${c.sev === "critical" ? "warn" : KIND[c.kind] || "info"}" style="cursor:pointer" data-go="${esc(c.go || "")}">
        <span class="ki">${ICON[c.kind] || "•"}</span><div class="kt"><b class="kh">${esc(c.title)}</b>${esc(c.text)}</div></div>`).join("")}</div>`;
    box.querySelectorAll("[data-go]").forEach(el => el.onclick = () => el.dataset.go && go(el.dataset.go));
  }
  loadToday();

  async function loadLearn() {
    const box = document.getElementById("d-learn");
    let s;
    try { s = await api.get("/api/learn/summary"); } catch (_) { box.innerHTML = ""; return; }
    const KR = {gem: "Замены камней", mod: "Замены модов", tree: "Планы древа"};
    const kinds = Object.entries(s.outcomes.kinds || {});
    // what the tool found lately, each in its own column: tree measurements had stood under «your craft experience»
    const fact = keep => (s.facts || []).filter(keep).slice(0, 4).map(f => `<div class="tiny faint" style="padding:2px 0">• ${esc(f.key)} — ${esc(f.value).slice(0, 110)}</div>`).join("");
    box.innerHTML = `<div class="sec-h" style="--k:var(--k-act)"><span class="si">🧠</span><div><h3>Чему научилась тула</h3>
        <div class="sd">советы, которые ты применил, и их реальный эффект в PoB · ошибки ИИ, которые она больше не повторит · твой опыт крафта</div></div></div>
      <div class="grid g3">
        <div><div class="bv-sgh" style="--k:var(--k-reward)">📊 Советы и результат</div>
          ${kinds.map(([k, v]) => `<div class="dp-kv"><span>${KR[k] || k}</span><b>применено ${v.applied} · пропущено ${v.ignored}${v.accuracy != null ? ` · эффект ${v.accuracy}% от прогноза` : ""}</b></div>`).join("")
            || `<div class="faint small">Пока нет данных: тула запоминает каждый измеренный совет и после следующего обновления билда проверит, что он реально дал.</div>`}
          ${(s.outcomes.recent || []).filter((e, i, a) => a.findIndex(x => x.text === e.text) === i).slice(0, 6).map(e => `<div class="small" style="padding:3px 0">✓ ${esc(e.text)} <span class="${e.real_dps >= 0 ? "up" : "down"}">DPS ${e.real_dps >= 0 ? "+" : ""}${e.real_dps}%</span> · EHP ${e.real_ehp >= 0 ? "+" : ""}${e.real_ehp}%</div>`).join("")}
          ${Object.entries(s.outcomes.open || {}).map(([c, recs]) => `<div class="tiny faint" style="margin-top:4px">ждёт проверки (${esc(c)}): ${recs.slice(0, 3).map(esc).join(" · ")}</div>`).join("")}
          ${fact(f => f.kind !== "craft_result")}</div>
        <div><div class="bv-sgh" style="--k:var(--k-item)">🛠 Исправленные ошибки ИИ</div>
          ${(s.fixes || []).map(f => `<div class="small" style="padding:2px 0">✗ «${esc(f.wrong)}» → ${f.right ? `«${esc(f.right)}»` : f.kind === "item" ? "в PoB хуже надетого — не предлагать" : "такого нет в PoE2"} <span class="tiny faint">×${f.n}</span></div>`).join("") || `<div class="faint small">Ошибок не было.</div>`}</div>
        <div><div class="bv-sgh" style="--k:var(--k-money)">💰 Твой опыт крафта</div>
          ${(s.crafts || []).map(c => `<div class="dp-kv"><span>${esc(c.cls)} · ${c.n} крафт(ов)</span><b class="${c.profit_total_ex >= 0 ? "up" : "down"}">${c.profit_total_ex >= 0 ? "+" : ""}${fmt.ex(c.profit_total_ex)} ex</b></div>`).join("")
            || `<div class="faint small">Записывай результаты крафта на продажу — тула подстроит прогнозы под твой опыт.</div>`}
          ${fact(f => f.kind === "craft_result")}</div>
      </div>`;
  }
  loadLearn();

  const big = n => n >= 1e6 ? (n / 1e6).toFixed(2) + "M" : n >= 1e4 ? (n / 1e3).toFixed(1) + "k" : Math.round(n).toLocaleString("ru");
  async function loadMe() {
    const pr = await api.get("/api/character/profiles").catch(() => null);
    const a = pr && pr.profiles.find(p => p.id === pr.active);
    const live = window.P2.live() && window.P2.live().log || {};
    $("#d-me").innerHTML = a ? `<div class="row" style="gap:14px">${window.P2.avatar(a, 60)}
        <div style="min-width:0"><div style="font-size:20px;font-weight:800">${esc(a.name)}</div>
          <div class="row" style="gap:6px;margin-top:4px;flex-wrap:wrap"><span class="pill reward">${esc(a.ascendancy_ru || a.class_ru || "")}</span><span class="pill node">${a.level || "?"} ур.</span>
          ${a.league ? `<span class="pill info">${esc(a.league)}</span>` : ""}${a.playing ? `<span class="pill node">▶ в игре${live.area ? " · " + esc(live.area) : ""}</span>` : ""}
          ${a.budget_amount ? `<span class="pill money">💰 ${a.budget_amount} ${esc({divine: "div", exalted: "ex", chaos: "chaos"}[a.budget_currency] || "")}</span>` : ""}</div></div></div>
      <div class="row" style="margin-top:12px;flex-wrap:wrap"><button class="btn sm primary" data-go="build_view">🛡 Мой билд</button><button class="btn sm" data-go="tree">🌳 Древо</button>
        <button class="btn sm" data-go="audit">🔬 Анализ</button><button class="btn sm ghost" data-go="character">Персонажи</button></div>`
      : `<div class="kb info"><span class="ki">👤</span><div class="kt">Персонаж не выбран. <a href="#" id="d-add">Добавить персонажа</a></div></div>`;
    $("#d-add")?.addEventListener("click", e => { e.preventDefault(); window.P2.addCharacter(); });
    root.querySelectorAll("#d-me [data-go]").forEach(b => b.onclick = () => go(b.dataset.go));
    const bv = await api.get("/api/buildview").catch(() => null);
    if (!bv || bv.empty) {
      $("#d-build").innerHTML = `<div class="sec-h" style="--k:var(--k-item)"><span class="si">🛡</span><div><h3>Билд</h3><div class="sd">шмот, камни и древо персонажа</div></div></div>
        <div class="kb gem"><span class="ki">🔗</span><div class="kt">Подключи аккаунт GGG во вкладке «Персонажи» — билд подтянется сам. Или вставь код PoB.</div></div>`;
      return;
    }
    const r = bv.raw || {};
    const res = ["FireResist", "ColdResist", "LightningResist", "ChaosResist"];
    $("#d-build").innerHTML = `<div class="sec-h" style="--k:var(--k-item)"><span class="si">🛡</span><div><h3>Билд по PoB</h3><div class="sd">${esc((bv.gems[0] && bv.gems[0].skills[0] && bv.gems[0].skills[0].ru) || "")}</div></div>
        <span class="spacer"></span><button class="btn sm" data-go="build_view">Открыть →</button></div>
      <div class="grid g3" style="gap:8px"><div class="stat"><b>${big(r.CombinedDPS || 0)}</b><span>DPS</span></div><div class="stat"><b>${big(r.TotalEHP || 0)}</b><span>эфф. HP</span></div>
        <div class="stat"><b>${big(r.Life || 0)}${r.EnergyShield ? " / " + big(r.EnergyShield) : ""}</b><span>жизнь${r.EnergyShield ? " / ЭЩ" : ""}</span></div></div>
      <div class="row" style="gap:6px;margin-top:10px">${res.map((k, i) => `<span class="pill ${(r[k] || 0) >= 75 || i === 3 ? "node" : "warn"}">${["🔥", "❄", "⚡", "☠"][i]} ${Math.round(r[k] || 0)}%</span>`).join("")}</div>`;
    root.querySelectorAll("#d-build [data-go]").forEach(b => b.onclick = () => go(b.dataset.go));
  }
  const $ = s => root.querySelector(s);

  async function load() {
    loadMe();
    api.get("/api/price/overview?type=Currency").then(ov => {
      document.getElementById("d-league").textContent = ov.league;
      document.getElementById("d-div").textContent = fmt.ex(ov.rates.exalted);
      document.getElementById("d-chaos").textContent = `${fmt.ex(ov.rates.chaos)} Chaos за Divine`;
      document.getElementById("d-cur").innerHTML = ov.rows.slice(0, 12).map(r => `<tr><td>${r.image ? `<img src="${r.image}" loading="lazy">` : ""}${esc(r.name_ru || r.name)}</td>
        <td class="num">${fmt.ex(r.exalted)}</td><td class="num">${fmt.div(r.divine)}</td><td class="num">${fmt.pct(r.change7d)}</td></tr>`).join("");
    }).catch(e => document.getElementById("d-cur").innerHTML = `<tr><td class="muted">poe.ninja недоступен: ${esc(e.message)}</td></tr>`);
    api.get("/api/farm/tracker").then(t => {
      document.getElementById("d-maps").textContent = t.runs;
      document.getElementById("d-maps-sub").textContent = t.runs ? `≈${t.avg_min.toFixed(1)} мин/карта` : "трекер ждёт карт";
    }).catch(() => {});
    api.get("/api/kb/stats").then(s => {
      document.getElementById("d-kb").textContent = s.total.toLocaleString("ru");
      document.getElementById("d-kb-sub").textContent = s.status.running ? `обновляется: ${s.status.step}` : fmt.n(s.sources.length, "источник|источника|источников");
    }).catch(() => {});
    const live = await api.get("/api/character/live");
    // the same hideout entered five times in a row is one event
    const events = live.events.filter((e, i, a) => !i || e.text !== a[i - 1].text);
    document.getElementById("d-events").innerHTML = events.slice(-8).reverse().map(e =>
      `<div class="row" style="padding:4px 0;border-bottom:1px solid var(--line)"><span class="pill ${{death: "warn", level: "node", gain: "reward", whisper: "money"}[e.type] || "info"}">${{death: "☠", level: "⬆", area: "📍", gain: "⭐", whisper: "✉"}[e.type] || "•"}</span><span>${esc(e.text)}</span><span class="spacer"></span><span class="faint tiny">${esc(evTime(e.time))}</span></div>`).join("") || `<div class="faint">Пока тихо</div>`;
  }

  const evTime = t => window.P2.evTime(t);

  onLive(st => {
    const l = st.log || {};

    const c = st.clip || {};
    if (c.text && c.action !== "pob") api.post("/api/price/check", {text: c.text}).catch(() => null).then(r => {
      if (!r) return;
      const s = r.trade?.summary, ex = r.exchange;
      document.getElementById("d-clip").className = "";
      document.getElementById("d-clip").innerHTML = itemCard(r.item) + `<div class="row" style="margin-top:10px">
        ${ex ? `<span class="tag green">${fmt.ex(ex.exalted)} ex</span>` : s && s.count ? `<span class="tag green">~${fmt.ex(s.median_ex)} ex</span><span class="tag">от ${fmt.ex(s.min_ex)} ex</span>` : `<span class="tag amber">цен не найдено</span>`}
        <span class="spacer"></span><button class="btn sm" id="d-open-price">Подробнее</button></div>`;
      document.getElementById("d-open-price").onclick = () => { go("price"); window.P2.priceCheck?.(c.text); };
    });
  });

  registerModule({id: "dash", onShow: load});
})();
