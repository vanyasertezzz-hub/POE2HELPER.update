(function () {
  "use strict";
  const {api, esc, fmt, md, registerModule, assistantPanel, toast, spinBtn} = window.P2;
  const root = document.getElementById("craft-root");
  root.innerHTML = `
    <div class="row" style="gap:10px;margin-bottom:12px"><div class="seg cr-mode"><button data-m="self" class="on">⚒ Для себя</button><button data-m="sell">💰 На продажу</button><button data-m="stash">📦 Сундук</button></div>
      <span class="small muted">на продажу: себестоимость, цена рынка, прибыль, риск и сложность — по реальным данным</span></div>
    <div id="cr-stash" hidden>
      <div class="card glow" style="margin-bottom:12px"><div class="sec-h" style="--k:var(--k-money)"><span class="si">📦</span><div><h3>Твой сундук</h3>
          <div class="sd">предметы приходят из твоих публичных вкладок (через трейд) и из Ctrl+C в игре (жмёшь ты — тула не нажимает за тебя). Каждый предмет: цена с трейда, польза для твоего билда в PoB, потенциал крафта</div></div>
          <span class="spacer"></span><button class="btn sm ghost" id="st-guide-show" hidden>📖 Инструкция</button></div>
        <div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn" id="st-collect">○ Собирать предметы из Ctrl+C</button>
          <button class="btn" id="st-trade">⟳ Мои лоты на трейде</button><button class="btn" id="st-track">○ Следить за публичными вкладками</button><button class="btn primary" id="st-eval">✦ Оценить всё</button>
          <button class="btn" id="st-advice">🧠 ИИ: что делать с сундуком</button><span class="spacer"></span><span id="st-eval-st"></span><button class="btn sm ghost danger" id="st-clear">Очистить</button></div>
        <div class="row" style="gap:8px;margin-top:8px"><textarea class="inp" id="st-text" rows="2" placeholder="или вставь сюда текст предмета (Ctrl+C в игре, русский или английский)" style="flex:1"></textarea><button class="btn" id="st-add">Добавить</button></div>
        <div class="st-guide" id="st-guide">
          <div class="row"><b class="st-gh">📖 Как сделать, чтобы тула видела все твои вкладки</b><span class="spacer"></span><button class="btn sm ghost" id="st-guide-hide">свернуть</button></div>
          <div class="small muted" style="margin:4px 0 8px">У PoE2 нет API тайника — так работают и другие тулы: вкладка становится публичной, сайт трейда GGG видит её предметы, а тула находит их поиском по твоему аккаунту.</div>
          <ol class="st-steps">
            <li><b>Подходят только премиум-вкладки</b> (и специальные вкладки, если игра даёт сделать их публичными). Обычные вкладки публичными не бывают —
              переложи нужные предметы в премиум-вкладку. Вкладка <b>Торговца</b> (Анж, асинхронная торговля) тоже видна трейду, но там у каждого предмета своя цена и их правда покупают.</li>
            <li><b>Сделай вкладку публичной:</b> в игре открой тайник → правой кнопкой по названию премиум-вкладки → в её настройках включи <b>«Публичная»</b>.</li>
            <li><b>Задай цену всей вкладке</b> там же: «одна цена на все предметы». Хочешь продавать — ставь реальную цену (тула отметит, что продалось).
              <b>Не хочешь продавать</b> — поставь заведомо большую цену, например <b>9999 divine</b>: трейд видит предметы, но никто их не купит.
              Отдельному предмету цену можно задать правой кнопкой по нему.</li>
            <li><b>Смени зону</b> (зайди в убежище или через портал) — после этого предметы появляются на сайте трейда, обычно через 1–5 минут.</li>
            <li><b>Аккаунт:</b> тула ищет по имени <b id="st-acc">—</b> во всех лигах, где у тебя есть персонажи. Если имя не то — переподключи аккаунт во вкладке «Персонажи».</li>
            <li><b>Включи «● Следить за публичными вкладками»</b> ниже. Раз в 30 минут тула сама подтянет новые предметы, оценит каждый (цена, польза для билда, крафт)
              и отметит пропавшие — скорее всего проданные. «⟳ Мои лоты на трейде» — проверить прямо сейчас.</li>
            <li>Повтори шаги 2–4 для каждой вкладки, которую хочешь отслеживать.</li>
          </ol>
          <div class="kb warn" style="margin-top:6px"><span class="ki">⚠</span><div class="kt">Публичную вкладку видят все на сайте трейда; вкладка Торговца продаёт мгновенно, даже когда ты не в игре — всегда проверяй цены.
            За одну проверку тула видит до 100 последних предметов на лигу (лимит запросов трейда GGG). Валюту в стаках здесь не оценить — для неё будет чтение экрана;
            предметы из непубличных вкладок добавляй через «○ Собирать предметы из Ctrl+C».</div></div>
        </div>
        <div class="cs-kpis" id="st-sum" style="margin-top:10px"></div>
        <div class="seg" id="st-filters" style="margin-top:4px"></div><div id="st-adv"></div></div>
      <div id="st-cur" style="margin:8px 0"></div>
      <div class="st-grid" id="st-grid"></div>
    </div>
    <div class="card glow" style="margin-bottom:16px" id="cr-pickcard">
      <div class="sec-h" style="--k:var(--k-item)"><span class="si">⚒</span><div><h3>Что крафтим</h3><div class="sd">выбери базу и уровень предмета, затем отметь нужные моды в пуле — тула посчитает все способы</div></div></div>
      <div class="row" style="gap:8px;margin-bottom:10px"><input class="inp" id="cr-wish" style="flex:1"
          placeholder="Опиши своими словами: «кольцо: +100 здоровья, 40% к огню, 30% редкости» или «копьё с физ. уроном и скоростью атаки»">
        <button class="btn primary" id="cr-wish-go">✦ Разобрать</button></div>
      <div class="cr-pick">
        <div class="field"><label>Тип предмета</label><button id="cr-class"></button></div>
        <div class="field"><label>База</label><button id="cr-base"></button></div>
        <div class="field"><label>Уровень предмета (ilvl)</label><select class="inp" id="cr-ilvl">${[86, 84, 83, 82, 81, 80, 78, 75, 72, 70, 65, 60, 50, 40]
          .map(v => `<option value="${v}" ${v === 82 ? "selected" : ""}>${v}</option>`).join("")}</select></div>
      </div>
      <div id="cr-targets" class="cr-targets"></div>
      <div class="row" style="margin-top:10px"><button class="btn primary" id="cr-calc" disabled>✦ Посчитать все способы крафта</button>
        <button class="btn" id="cr-buy" disabled>🛒 Сколько стоит купить готовое</button>
        <button class="btn primary" id="cr-profit" hidden disabled>💰 Посчитать выгоду на продажу</button>
        <button class="btn" id="cr-scan" hidden>🔎 Найти выгодные крафты для этой базы</button><span class="small muted" id="cr-hint">отметь 1–6 модов в пуле ниже</span></div>
    </div>
    <div id="cr-result"></div>
    <div id="cr-sell" hidden><div class="grid g2" style="margin-bottom:16px">
      <div class="card"><div class="sec-h" style="--k:var(--k-money)"><span class="si">⭐</span><div><h3>Отслеживаемые крафты</h3><div class="sd">тула перепроверяет их сама раз в 3 часа и предупредит, когда выгода появится или пропадёт</div></div></div><div id="cs-watch-list"></div></div>
      <div class="card" style="grid-column:1/-1"><div class="sec-h" style="--k:var(--k-money)"><span class="si">💹</span><div><h3>Что выгодно крафтить сейчас — по всей игре</h3>
          <div class="sd">тула сама перебирает все классы предметов и рецепты из постов и видео: себестоимость — симуляция, цена — живой трейд · дорогой крафт не помеха, важна окупаемость</div></div></div><div id="cs-market"></div>
        <div class="kb gem" style="margin-top:10px"><span class="ki">🎲</span><div class="kt"><b class="kh">Лотерея: Loreweave из 60 уникальных колец</b>
          <span class="small">Dannig (Руины Кингсмарча), после книги «Journey to the East» из Grand Expedition: три случайных мода колец, продажа зависит от них.</span>
          <div class="row" style="gap:8px;margin-top:6px"><button class="btn sm" id="cs-lore">Посчитать по рынку</button><span class="small" id="cs-lore-out"></span></div></div></div>
        <div class="kb gem" style="margin-top:10px"><span class="ki">⚒</span><div class="kt"><b class="kh">Кузница рун: руда → уникальный предмет</b>
          <span class="small">Руда превращается в уникальный предмет на наковальне бесплатно (вики). Рынок покупки и продажи разный: разница иногда есть. Цена уникального зависит от роллов.</span>
          <div class="row" style="gap:8px;margin-top:6px"><button class="btn sm" id="cs-forge">Посчитать по рынку</button></div><div class="small" id="cs-forge-out" style="margin-top:6px"></div></div></div></div>
      <div class="card" style="grid-column:1/-1"><div class="sec-h" style="--k:var(--k-gem)"><span class="si">📚</span><div><h3>Рецепты из гайдов</h3>
          <div class="sd">схемы из гайдов по крафту (моды проверены по пулу PoE2DB) · выгоду тула пересчитывает сама по текущему рынку</div></div>
          <span class="spacer"></span><input class="inp" id="cs-rq" placeholder="🔍 кольцо, ботинки, amulet…" style="width:200px"><button class="btn sm" id="cs-rrefresh">⟳ Обновить из гайдов</button></div>
        <div class="row" style="gap:8px;flex-wrap:wrap;align-items:flex-end;margin:8px 0">
          <label class="fld"><span>Затраты до, div</span><input class="inp" id="cs-rmax" type="number" min="0" step="1" placeholder="любые" style="width:110px"></label>
          <label class="fld"><span>Прибыль от, div</span><input class="inp" id="cs-rmin" type="number" min="0" step="1" placeholder="любая" style="width:110px"></label>
          <label class="fld"><span>Риск</span><select class="inp" id="cs-rrisk" style="width:auto"><option value="">любой</option><option value="гарантия">только гарантия</option><option value="safe">гарантия и низкий риск</option></select></label>
          <label class="fld"><span>Сортировка</span><select class="inp" id="cs-rsort" style="width:auto"><option value="profit">по прибыли</option><option value="roi">по окупаемости</option><option value="cost">дешевле начать</option><option value="new">новые сначала</option></select></label>
          <label class="row" style="gap:5px;font-size:12px"><input type="checkbox" id="cs-rpriced"> только посчитанные</label></div>
        <div id="cs-recipes"></div></div>
      <div class="card"><div class="sec-h" style="--k:var(--k-reward)"><span class="si">🔎</span><div><h3>Идеи: что выгодно крафтить</h3><div class="sd">сильные комбинации модов выбранной базы (T1 и T2), оценённые по реальным ценам · клик — подробный расчёт</div></div></div><div id="cs-scan-box"></div></div>
    </div></div>
    <div class="card" style="margin-bottom:16px" id="cr-poolcard"><div class="sec-h" style="--k:var(--k-gem)"><span class="si">🎲</span><div><h3>Пул модов</h3>
        <div class="sd">реальные веса PoE2DB для этой базы · % — шанс, что следующий случайный мод будет этим (среди своей стороны)</div></div>
        <span class="spacer"></span><input class="inp" id="cr-filter" placeholder="🔍 фильтр: здоровье, скорость, огонь…" style="width:260px"></div>
      <div id="cr-pool" class="grid g2"><div class="muted small">Выбери базу.</div></div>
      <div id="cr-extra" style="margin-top:12px"></div></div>
    <div id="cr-assist"></div>`;
  const $ = s => root.querySelector(s);
  let catalog = null, clsPick = null, basePick = null, pool = null, targets = new Map();

  async function loadCatalog() {
    if (catalog) return;
    catalog = await api.get("/api/craft/catalog");
    const RU = {Tablet: "Таблетка", "Body Armour": "Нательник", Helmet: "Шлем", Gloves: "Перчатки", Boots: "Ботинки", Ring: "Кольцо", Amulet: "Амулет",
      Belt: "Пояс", Shield: "Щит", Buckler: "Баклер", Focus: "Фокус", Quiver: "Колчан", Spear: "Копьё", Bow: "Лук", Crossbow: "Арбалет",
      Wand: "Жезл", Staff: "Посох", Sceptre: "Скипетр", Warstaff: "Боевой посох", Talisman: "Талисман", Claw: "Когти", Dagger: "Кинжал",
      Flail: "Цеп", "One Hand Sword": "Одноручный меч", "One Hand Axe": "Одноручный топор", "One Hand Mace": "Одноручная булава",
      "Two Hand Sword": "Двуручный меч", "Two Hand Axe": "Двуручный топор", "Two Hand Mace": "Двуручная булава",
      LifeFlask: "Флакон жизни", ManaFlask: "Флакон маны", UtilityFlask: "Оберег"};
    const items = Object.entries(catalog).map(([cls, bases]) => ({value: cls, label: RU[cls] || cls, sub: `${cls} · ${fmt.n(bases.length, "база|базы|баз")}`, icon: bases[0].icon,
      group: /Flask/.test(cls) ? "Флаконы и обереги" : ["Ring", "Amulet", "Belt"].includes(cls) ? "Бижутерия" : ["Body Armour", "Helmet", "Gloves", "Boots", "Shield", "Buckler", "Focus", "Quiver"].includes(cls) ? "Броня и вторая рука" : "Оружие"}))
      .sort((a, b) => a.group.localeCompare(b.group) || a.label.localeCompare(b.label, "ru"));
    clsPick = window.P2.picker($("#cr-class"), {items, placeholder: "Кольцо, перчатки, копьё…", width: 340, onChange: v => { fillBases(v); }});
    basePick = window.P2.picker($("#cr-base"), {items: [], placeholder: "сначала тип предмета", width: 360, onChange: () => loadPool()});
  }
  function fillBases(cls, pick) {
    const items = (catalog[cls] || []).map(b => ({value: b.name, label: b.name, sub: `уровень базы ${b.level}`, icon: b.icon}));
    basePick.setItems(items);
    basePick.set(pick || (items[0] && items[0].value) || "");
    loadPool();
  }
  $("#cr-ilvl").onchange = () => loadPool();

  // «what I want» in free words → class, base and target mods from the real pool, then the full calculation
  $("#cr-wish-go").onclick = async e => {
    const text = $("#cr-wish").value.trim();
    if (!text) return toast("info", "Напиши, что хочешь скрафтить");
    const b = e.currentTarget; spinBtn(b, true, "Разбираю…");
    try {
      await loadCatalog();
      const w = await api.post("/api/craft/wish", {text});
      clsPick.set(w.cls);
      const sel = [...$("#cr-ilvl").options].map(o => +o.value);
      $("#cr-ilvl").value = sel.includes(w.ilvl) ? w.ilvl : 82;
      fillBases(w.cls, w.base);
      for (let i = 0; i < 40 && !(pool && pool.base === w.base); i++) await new Promise(r => setTimeout(r, 150));
      targets.clear();
      for (const m of w.mods) {
        const f = (pool.prefix || []).concat(pool.suffix || []).find(x => x.key === m.key);
        if (f) targets.set(m.key, {gen: f.gen, tier: Math.min(m.tier, f.tiers.length), f});
      }
      renderPool(); renderTargets();
      if (w.missing.length) toast("info", "Не нашёл в пуле этой базы", w.missing.join(", "));
      if (targets.size) calcPlan(); else toast("err", "Ни один мод не подошёл к пулу", "уточни формулировку");
    } catch (err) { toast("err", "Не разобрал", err.message); }
    finally { spinBtn(b, false); }
  };

  async function loadPool() {
    const base = basePick && basePick.value;
    if (!base) return;
    $("#cr-pool").innerHTML = `<div class="skel"></div><div class="skel"></div>`;
    try { pool = await api.get(`/api/craft/pool2?base=${encodeURIComponent(base)}&ilvl=${$("#cr-ilvl").value}`); }
    catch (e) { $("#cr-pool").innerHTML = `<div class="kb warn"><span class="ki">⚠</span><div class="kt">${esc(e.message)}</div></div>`; return; }
    for (const [k] of targets) if (!pool.prefix.concat(pool.suffix).some(f => f.key === k) && !(pool.desecrated || []).some(e => desKey(e) === k)) targets.delete(k);
    renderPool(); renderTargets();
  }
  function famRow(f) {
    const on = targets.has(f.key);
    const best = f.tiers[0];
    return `<div class="cr-mod ${on ? "on" : ""}" data-key="${esc(f.key)}">
      <div class="cr-mt"><b>${esc(best.text_ru)}</b><span>${esc(best.text)}</span></div>
      <div class="cr-mp"><b>${f.p_side.toFixed(1)}%</b><span>${f.tiers.length}/${f.all_tiers} тир.</span></div>
      <div class="cr-bar"><i style="width:${Math.min(100, f.p_side * 4)}%"></i></div></div>`;
  }
  function renderPool() {
    const q = ($("#cr-filter").value || "").toLowerCase();
    const flt = f => !q || (f.text_ru + " " + f.text).toLowerCase().includes(q);
    $("#cr-pool").innerHTML = ["prefix", "suffix"].map(side => `<div><div class="bv-sgh" style="--k:var(--k-${side === "prefix" ? "item" : "gem"})">${side === "prefix" ? "Префиксы" : "Суффиксы"} · ${pool[side].length}</div>
      ${pool[side].filter(flt).map(famRow).join("")}</div>`).join("");
    $("#cr-extra").innerHTML = (pool.essences.length ? `<details><summary class="small"><b>💧 Эссенции для этой базы</b> (гарантированный мод) · ${pool.essences.length}</summary>
        <div class="grid g2" style="margin-top:6px">${pool.essences.map(e => `<div class="kb gem" style="margin:3px 0"><span class="ki">💧</span><div class="kt"><b>${esc(e.name)}</b><div class="small">${esc(e.text_ru)}</div></div></div>`).join("")}</div></details>` : "")
      + (pool.desecrated.length ? `<details style="margin-top:6px" ${[...targets.keys()].some(k => k.startsWith("des:")) ? "open" : ""}><summary class="small"><b>🦴 Осквернённые моды</b> (кости Бездны: открываешь у Колодца и выбираешь 1 из 3 — нажми, чтобы сделать целью) · ${pool.desecrated.length}</summary>
        <div class="grid g2" style="margin-top:6px">${pool.desecrated.map((e, i) => `<div class="kb act cr-des ${targets.has(desKey(e)) ? "on" : ""}" data-i="${i}" style="margin:3px 0;cursor:pointer${targets.has(desKey(e)) ? ";outline:1px solid var(--accent)" : ""}"><span class="ki">🦴</span><div class="kt"><b>${esc(e.name)}</b> <span class="tiny faint">${e.gen === "prefix" ? "префикс" : "суффикс"} · ур. ${e.ilvl}</span><div class="small">${esc(e.text_ru)}</div></div></div>`).join("")}</div></details>` : "");
    root.querySelectorAll(".cr-mod").forEach(el => el.onclick = () => toggle(el.dataset.key));
    root.querySelectorAll(".cr-des").forEach(el => el.onclick = () => toggle(desKey(pool.desecrated[+el.dataset.i]), pool.desecrated[+el.dataset.i]));
  }
  $("#cr-filter").oninput = () => pool && renderPool();

  // a desecrated mod as a target: one tier (its own text); the plan adds the bone step for it
  const desKey = e => `des:${e.name}:${e.text}`;
  function toggle(key, des) {
    if (targets.has(key)) targets.delete(key);
    else {
      const f = des ? {key, gen: des.gen, tiers: [{tier: 1, text: des.text, text_ru: des.text_ru}]} : pool.prefix.concat(pool.suffix).find(x => x.key === key);
      const sameSide = [...targets.values()].filter(t => t.gen === f.gen).length, cap = pool.cap || 3;
      if (sameSide >= cap) { toast("info", `Максимум ${cap} ${f.gen === "prefix" ? "префикса" : "суффикса"}${cap === 2 ? " (у самоцвета)" : ""}`); return; }
      targets.set(key, {gen: f.gen, tier: des ? 1 : Math.min(f.tiers.length, 2), f});
    }
    renderPool(); renderTargets();
  }
  function wantedLines() {
    return [...targets.values()].map(t => { const tier = t.f.tiers[t.tier - 1] || t.f.tiers[0];
      const m = tier.text.match(/\((\d+(?:\.\d+)?)-(\d+(?:\.\d+)?)\)/); return m ? tier.text.replace(m[0], m[1]) : tier.text; });
  }
  // the same targets as the player reads them (session titles and goals; trade and the simulator take wantedLines)
  const wantedRu = () => [...targets.values()].map(t => (t.f.tiers[t.tier - 1] || t.f.tiers[0]).text_ru);
  function renderTargets() {
    const list = [...targets.entries()];
    $("#cr-targets").innerHTML = list.length ? list.map(([k, t]) => `<div class="cr-chip ${t.gen}"><span>${t.gen === "prefix" ? "P" : "S"}</span>
        <select data-k="${esc(k)}">${t.f.tiers.map((x, i) => `<option value="${i + 1}" ${i + 1 === t.tier ? "selected" : ""}>T${x.tier}+ · ${esc(x.text_ru)}</option>`).join("")}</select>
        <button data-x="${esc(k)}">✕</button></div>`).join("") : "";
    root.querySelectorAll(".cr-chip select").forEach(s => s.onchange = () => { targets.get(s.dataset.k).tier = +s.value; });
    root.querySelectorAll(".cr-chip [data-x]").forEach(b => b.onclick = () => toggle(b.dataset.x));
    $("#cr-calc").disabled = $("#cr-buy").disabled = $("#cr-profit").disabled = !list.length;
    $("#cr-hint").textContent = list.length ? `${list.length} цел. · тир можно сменить в списке` : "отметь 1–6 модов в пуле ниже";
  }

  let lastPlan = null;
  function methodCard(m, best) {
    const isBest = best && m.method + (m.tier ? ":" + m.tier : "") === best;
    return `<div class="cr-meth ${isBest ? "best" : ""} ${m.expected_ex ? "" : "off"}">
      <div class="row"><b style="font-size:15px">${isBest ? "🏆 " : ""}${esc(m.title)}</b><span class="spacer"></span>
        ${m.expected_ex ? `<span class="cr-cost">${m.expected_div != null && m.expected_div >= 1 ? fmt.div(m.expected_div) + " div" : fmt.ex(m.expected_ex) + " ex"}</span>` : `<span class="pill warn">почти невозможно</span>`}</div>
      <div class="row" style="gap:6px;margin:6px 0"><span class="pill info">успех с одной базы: ${m.success_rate}%</span>${m.expected_ex ? `<span class="pill money">≈ ${fmt.ex(m.expected_ex)} ex всего</span>` : ""}${roughPill(m)}${(m.unpriced || []).map(n => `<span class="pill warn" title="на рынке нет предложений — обычно выпадает сама; в стоимость не включена">цена ${esc(n)} неизвестна</span>`).join("")}</div>
      ${m.currency.length ? `<div class="cr-cur">${m.currency.map(c => `<div title="${esc(c.name)}${c.ex ? ` · ${fmt.ex(c.ex)} ex/шт` : ""}">${c.icon ? `<img src="${esc(c.icon)}" alt="">` : "<span>🧱</span>"}<b>×${c.count >= 10 ? Math.round(c.count) : c.count}</b><small>${esc((c.ru || c.name).replace(/^Сфера /, "").replace(/^Orb of /, "").replace(/ Orb$/, ""))}</small></div>`).join("")}</div>` : ""}
      ${m.expected_ex && m.shopping && m.shopping.rows.length ? shopHtml(m.shopping) : ""}
      ${(m.tree || []).length ? `<details style="margin-top:6px" open><summary class="small"><b>🌳 Что делать по ходу крафта</b> <span class="muted">(симуляция: продолжать или брать новую базу)</span></summary>
        <table class="tbl"><thead><tr><th>На предмете</th><th>Решение</th></tr></thead><tbody>${m.tree.map(b => `<tr><td style="white-space:nowrap">${fmt.n(b.mods, "мод|мода|модов")}, целей ${b.hits} из ${b.of}</td><td class="${b.go ? "" : "down"}">${esc(b.text)}</td></tr>`).join("")}</tbody></table>
        ${m.tree.some(b => b.sell) ? `<div class="row" style="gap:8px;margin-top:6px"><button class="btn sm cr-partial">💰 Сколько стоит вещь с одной целью</button><span class="small cr-partial-out"></span></div>` : ""}</details>` : ""}
      <div style="margin-top:8px">${m.steps.map((s, i) => `<div class="kb act" style="margin:4px 0"><span class="ki">${i + 1}</span><div class="kt">${esc(s)}</div></div>`).join("")}</div>
      ${m.summary ? `<div class="kb money" style="margin-top:6px"><span class="ki">Σ</span><div class="kt"><b class="kh">Итого</b>${esc(m.summary)}</div></div>` : ""}</div>`;
  }
  // what to buy on the currency exchange for one finished item: the craft's currency minus the player's copied stacks
  const shopHtml = sh => `<details class="cr-shop" style="margin-top:6px"><summary class="small"><b>🛒 Купить в обменнике валют</b> — ≈ ${fmt.ex(sh.buy_ex)} ex`
    + `${sh.known ? "" : ' <span class="muted">(твоих стаков тула не знает: «📦 Сундук» → сбор, Ctrl+C по стакам)</span>'}</summary>
    <table class="tbl"><thead><tr><th>Что</th><th class="num">Нужно</th><th class="num">Есть</th><th class="num">Купить</th><th class="num">ex</th></tr></thead><tbody>`
    + sh.rows.map(r => `<tr${r.optional ? ' class="muted"' : ""}><td>${esc(r.ru || r.name)}${r.optional ? ' <span class="tiny">(на случай промаха — в итог не входит)</span>' : ""}</td><td class="num">${r.need.toLocaleString("ru")}</td><td class="num">${r.have ? r.have.toLocaleString("ru") : "—"}</td>`
      + `<td class="num"><b>${r.buy.toLocaleString("ru")}</b></td><td class="num">${r.priced ? fmt.ex(r.ex) : '<span class="muted">нет цены</span>'}</td></tr>`).join("")
    + `</tbody></table><div class="tiny faint">В среднем на один готовый предмет (симуляция); реальный крафт может уйти в любую сторону — бери с запасом или докупай по ходу.</div></details>`;
  // a cost from a handful of simulated successes is noise: said next to the number
  const roughPill = m => m.rough ? `<span class="pill warn" title="ожидаемая стоимость из ${m.successes} успехов — реальная может отличаться в разы">⚠ грубо: ${fmt.n(m.successes, "успех|успеха|успехов")} из ${(m.runs || 0).toLocaleString("ru")} прогонов</span>` : "";
  // a desecrated target: the bone step after the craft, its odds and cost (misses cleaned by Omen of Light + Annulment)
  function desecrationHtml(d, r) {
    if (d.impossible) return `<div class="kb warn" style="margin:8px 0"><span class="ki">🦴</span><div class="kt"><b class="kh">${esc(d.target_ru)}</b>${esc(d.why)}</div></div>`;
    const best = (r.methods || []).filter(m => m.expected_ex).sort((a, b) => a.expected_ex - b.expected_ex)[0];
    return `<div class="kb gem" style="margin:8px 0"><span class="ki">🦴</span><div class="kt"><b class="kh">Осквернение: ${esc(d.target_ru)} — ≈ ${fmt.ex(d.expected_ex)} ex, шанс ${d.p}% за попытку</b>
      ${d.steps.map((x, i) => `<div class="small">${i + 1}. ${esc(x)}</div>`).join("")}
      <div class="small muted" style="margin-top:4px">Попытка ≈ ${fmt.ex(d.attempt_ex)} ex (кость + предзнаменования)${d.priced ? "" : "; цены кости на рынке нет — не включена"}.
      ${best ? ` Вместе с крафтом остальных модов ≈ <b>${fmt.ex(best.expected_ex + d.expected_ex)} ex</b>.` : ""}</div>
      ${d.shopping && d.shopping.rows.length ? shopHtml(d.shopping) : ""}</div></div>`;
  }
  // where the white base comes from: own stash first, else the cheapest on trade
  function baseHtml(b) {
    if (!b) return "";
    const own = b.stash || [], t = b.trade || {};
    return `<div class="kb ${own.length ? "node" : "item"}" style="margin:8px 0"><span class="ki">🧱</span><div class="kt"><b class="kh">База: ${esc(b.base)} (ilvl ${b.ilvl}+)</b>
      ${own.length ? `✓ Есть у тебя в сундуке: ${own.slice(0, 4).map(x => `${esc(x.name)} — ilvl ${x.ilvl}${x.rarity === "Magic" ? " (магическая: сначала Сфера отмены/новая база)" : ""}${x.tab ? `, вкладка «${esc(x.tab)}»` : ""}${x.league ? ` (${esc(x.league)})` : ""}`).join("; ")}. Бери её — покупать не нужно.<br>` : "В сундуке подходящей базы нет. "}
      ${t.min_ex != null ? `Купить на трейде: от <b>${fmt.ex(t.min_ex)} ex</b> (в среднем ${fmt.ex(t.ex)} ex у трёх самых дешёвых, всего ${fmt.n(t.total, "лот|лота|лотов")}) ${t.url ? `<a href="${esc(t.url)}" target="_blank" class="btn sm" style="margin-left:6px">🔎 Открыть трейд</a>` : ""}`
        : t.error ? `<span class="muted">цену базы не получил: ${esc(t.error)}</span>` : `<span class="muted">белых баз ilvl ${b.ilvl}+ на трейде нет</span>`}</div></div>`;
  }
  async function calcPlan(spec) {
    const body = spec || {base: basePick.value, ilvl: +$("#cr-ilvl").value, mods: wantedLines()};
    const box = $("#cr-result");
    box.innerHTML = `<div class="card"><div class="skel"></div><div class="skel"></div><div class="small muted">Симулирую крафт тысячи раз по реальным весам…</div></div>`;
    box.scrollIntoView({behavior: "smooth", block: "start"});
    try {
      const r = await api.post("/api/craft/plan", body);
      if (r.base && basePick && basePick.value !== r.base && (catalog[clsPick.value] || []).some(b => b.name === r.base)) basePick.set(r.base);
      box.innerHTML = `<div class="card glow" style="margin-bottom:16px"><div class="sec-h" style="--k:var(--k-money)"><span class="si">💰</span><div><h3>Как скрафтить: ${esc(r.base)} (ilvl ${r.ilvl})</h3>${r.ilvl_note ? `<div class="small" style="color:var(--amber)">${esc(r.ilvl_note)}</div>` : ""}
          <div class="sd">${esc(r.note)}</div></div><span class="spacer"></span><button class="btn sm" id="cr-r-buy">🛒 Сравнить с трейдом</button><button class="btn sm primary" id="cr-r-guide">Вести по шагам</button></div>
        <div class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:10px">${r.targets.map(t => `<span class="pill ${t.gen === "prefix" ? "item" : "gem"}">${t.gen === "prefix" ? "P" : "S"} · ${esc(t.text_ru)} <small>(T${t.tier}+, ${t.p_tier}% тиров)</small></span>`).join("")}</div>
        ${r.missing.length ? `<div class="kb warn"><span class="ki">⚠</span><div class="kt">Не нашёл в пуле этой базы: ${r.missing.map(esc).join(", ")}</div></div>` : ""}
        ${(r.line_notes || []).map(n => `<div class="kb ${n.kind === "above" ? "warn" : "info"}" style="margin:4px 0"><span class="ki">${{sum: "Σ", desecrated: "🦴", essence: "💠", above: "⚡"}[n.kind] || "ℹ"}</span><div class="kt"><b class="kh">${esc(n.line_ru || n.line)}</b>${esc(n.text)}</div></div>`).join("")}
        ${baseHtml(r.base_source)}
        <div class="kb money" style="margin:8px 0"><span class="ki">⚖</span><div class="kt"><b class="kh">Сколько готов отдать за базу?</b>
          <div class="row" style="gap:10px;margin-top:6px"><input type="range" id="cr-bb" min="0" max="100" step="0.5" value="5" style="flex:1">
            <b id="cr-bb-v" style="min-width:70px">5 div</b><button class="btn sm primary" id="cr-bb-go">Подобрать базу и посчитать выхлоп</button></div>
          <div class="small muted">Тула ищет базы в пределах этой суммы, на которых УЖЕ есть часть нужных модов, досчитывает крафт оставшихся и сравнивает с ценой готового предмета.</div>
          <div id="cr-bb-out" style="margin-top:8px"></div></div></div>
        ${r.relaxed ? `<div class="kb warn" style="margin:8px 0"><span class="ki">🎯</span><div class="kt"><b class="kh">Все эти тиры сразу — почти невозможно (ни одного успеха в симуляции)</b>
          Реалистичная цель на ${r.relaxed.step} ${r.relaxed.step === 1 ? "тир" : "тира"} ниже: ${r.relaxed.targets.map(t => `<b>${esc(t.text_ru)}</b>`).join(", ")} —
          ${r.relaxed.methods.map(m => `${esc(m.title)} ≈ ${m.expected_div != null && m.expected_div >= 1 ? fmt.div(m.expected_div) + " div" : fmt.ex(m.expected_ex) + " ex"} (успех с базы ${m.success_rate}%)`).join("; ")}</div></div>` : ""}
        ${(r.desecration || []).map(d => desecrationHtml(d, r)).join("")}
        ${(() => {  // ways 20+ times dearer than the best are noise on the first screen, kept one click away
          const sorted = r.methods.slice().sort((a, b) => (a.expected_ex ?? 1e18) - (b.expected_ex ?? 1e18));
          const top = (sorted[0] || {}).expected_ex, near = sorted.filter(m => !top || (m.expected_ex && m.expected_ex <= top * 20)), far = sorted.filter(m => !near.includes(m));
          return `<div class="cr-meths">${(lastPlan = r, near).map(m => methodCard(m, r.best)).join("")}</div>`
            + (far.length ? `<details style="margin-top:8px"><summary class="small muted">Ещё ${fmt.n(far.length, "способ|способа|способов")} — дороже лучшего в 20+ раз или почти невозможно</summary><div class="cr-meths">${far.map(m => methodCard(m, r.best)).join("")}</div></details>` : "");
        })()}
        <div id="cr-r-trade" style="margin-top:10px"></div></div>`;
      $("#cr-r-buy").onclick = e => buy(e.currentTarget, {base: r.base, ilvl: r.ilvl, mods: r.targets.map(t => t.trade)}, r);
      $("#cr-bb").oninput = () => { $("#cr-bb-v").textContent = $("#cr-bb").value + " div"; };
      $("#cr-bb-go").onclick = async ev => {
        const b = ev.currentTarget; spinBtn(b, true, "Ищу базы и считаю…");
        try {
          const o = await api.post("/api/craft/base_options", {base: r.base, ilvl: r.ilvl, mods: r.targets.map(t => t.want), budget_div: +$("#cr-bb").value});
          const money = v => v == null ? "—" : Math.abs(v) < 1 && o.ex_per_div ? fmt.ex(v * o.ex_per_div) + " ex" : fmt.div(v) + " div";
          $("#cr-bb-out").innerHTML = `<div class="small" style="margin-bottom:6px">Готовый предмет на трейде сейчас: <b>${money(o.value_div)}</b>${o.value_count ? ` (${o.value_count} похожих)` : ""}
              ${o.value_url ? ` <a href="${esc(o.value_url)}" target="_blank">смотреть</a>` : ""}</div>
            <table class="tbl"><thead><tr><th>Старт</th><th class="num">База</th><th class="num">Докрафт</th><th class="num">Всего</th><th class="num">Прибыль</th></tr></thead><tbody>
            ${o.options.map((x, i) => `<tr ${i === o.best ? 'style="background:rgba(52,211,153,.10)"' : ""}><td>${i === o.best ? "🏆 " : ""}<b>${esc(x.title)}</b>
                ${x.have.length ? `<div class="tiny up">уже есть: ${x.have.map(esc).join(", ")}</div>` : ""}
                ${x.whisper ? `<div class="tiny"><button class="btn sm" data-copy="${esc(x.whisper)}">📋 Шепнуть продавцу</button></div>` : x.url ? `<div class="tiny"><a href="${esc(x.url)}" target="_blank">открыть трейд</a></div>` : ""}</td>
              <td class="num">${money(x.price_div)}</td><td class="num">${x.craft_div == null ? "почти невозможно" : money(x.craft_div)}</td>
              <td class="num">${money(x.total_div)}</td><td class="num ${x.profit_div > 0 ? "up" : "down"}">${x.profit_div == null ? "—" : (x.profit_div > 0 ? "+" : "") + money(x.profit_div)}</td></tr>`).join("")}
            </tbody></table><div class="tiny muted" style="margin-top:4px">${esc(o.note)}</div>`;
          $("#cr-bb-out").querySelectorAll("[data-copy]").forEach(btn => btn.onclick = () => { navigator.clipboard.writeText(btn.dataset.copy); toast("ok", "Скопировано", "вставь в чат игры"); });
        } catch (err) { $("#cr-bb-out").innerHTML = `<div class="kb warn"><span class="ki">⚠</span><div class="kt">${esc(err.message)}</div></div>`; }
        finally { spinBtn(b, false); }
      };
      $("#cr-r-guide").onclick = async () => {
        const s = await api.post("/api/craft/new", {base: r.base, ilvl: r.ilvl, goal: r.targets.map(t => t.text_ru).join(", "), budget: ""});
        craftPanel.open(s.id); $("#cr-assist").scrollIntoView({behavior: "smooth"});
        toast("ok", "Пошаговый крафт начат", "после каждого шага вставляй предмет (Ctrl+C в игре) — ассистент скажет, что дальше");
      };
    } catch (e) { box.innerHTML = `<div class="card"><div class="kb warn"><span class="ki">⚠</span><div class="kt">${esc(e.message)}</div></div></div>`; }
  }
  async function buy(btn, body, r) {
    spinBtn(btn, true, "Смотрю трейд…");
    try {
      const t = await api.post("/api/craft/buy", body);
      const s = t.summary || {};
      const best = r && r.methods.filter(m => m.expected_ex).sort((a, b) => a.expected_ex - b.expected_ex)[0];
      // a craft cost without the white bases only proves «buying is cheaper»; «craft is cheaper» needs the base price
      let cheaper = best && s.min_ex ? (s.median_ex || s.min_ex) < best.expected_ex : null;
      const unpriced = r && r.base_priced === false && best && best.bases;
      if (cheaper === false && unpriced) cheaper = null;
      const el = r ? $("#cr-r-trade") : $("#cr-result");
      el.innerHTML = `<div class="kb ${cheaper ? "money" : "node"}"><span class="ki">🛒</span><div class="kt"><b class="kh">Купить готовое</b>
        ${t.total ? `На трейде ${fmt.n(t.total, "лот|лота|лотов")}: от <b>${fmt.ex(s.min_ex)} ex</b>, обычно ~<b>${fmt.ex(s.median_ex)} ex</b>.` : "Готовых предметов с такими модами на трейде нет — только крафт."}
        ${cheaper === true ? " <b>Купить дешевле, чем крафтить.</b>" : cheaper === false ? " <b>Крафт выгоднее покупки.</b>" : ""}
        ${cheaper === null && unpriced && s.median_ex ? `<br>Крафт ≈ ${fmt.ex(best.expected_ex)} ex — без ${fmt.n(Math.round(best.bases), "белой базы|белых баз|белых баз")}, цены базы на трейде нет: ${
          (s.median_ex - best.expected_ex) / best.bases >= 0.1 ? `выгоднее покупки, только если база ≤ <b>${fmt.ex((s.median_ex - best.expected_ex) / best.bases)} ex</b>.` : "выгоды нет при любой цене базы."}` : ""}
        ${t.url ? `<div style="margin-top:6px"><button class="btn sm primary" data-url="${esc(t.url)}">Открыть трейд с фильтрами</button></div>` : ""}</div></div>`;
      el.querySelector("[data-url]")?.addEventListener("click", ev => window.open(ev.currentTarget.dataset.url, "_blank"));
    } catch (e) { toast("err", "Трейд", e.message); }
    spinBtn(btn, false);
  }
  $("#cr-calc").onclick = () => calcPlan();
  $("#cr-buy").onclick = e => buy(e.currentTarget, {base: basePick.value, ilvl: +$("#cr-ilvl").value, mods: wantedLines()});

  const craftPanel = assistantPanel($("#cr-assist"), {
    kind: "craft", newUrl: "/api/craft/new", newTitle: "Пошаговый крафт с ассистентом", createLabel: "Начать",
    formHtml: `<div class="field"><label>Текущий предмет (в игре Ctrl+C или Ctrl+Alt+C, вставь сюда) — или база выше</label><textarea class="inp" name="item" rows="4"></textarea></div>
      <div class="field"><label>Цель</label><div class="c-goal"></div></div>
      <div class="field"><label>Бюджет</label><div class="c-budget"></div></div>`,
    onForm: async f => {
      const c = await window.P2.choices();
      f.querySelector(".c-goal").innerHTML = window.P2.selectHtml("goal", c.goals.craft, {custom: true, placeholder: "свои моды, напр. T1 life + cast speed"});
      f.querySelector(".c-budget").innerHTML = window.P2.selectHtml("budget", c.budgets, {empty: "— не важно —"});
      window.P2.wireSelects(f);
    },
    collect: f => {
      const body = {item_text: f.querySelector("[name=item]").value, base: basePick ? basePick.value : "", ilvl: +$("#cr-ilvl").value || 82,
        goal: window.P2.selectValue(f, "goal") || wantedRu().join(", "), budget: window.P2.selectValue(f, "budget")};
      if (!body.item_text.trim() && !body.base) { toast("info", "Вставь предмет или выбери базу выше"); return null; }
      return body;
    },
    kickoffLabel: "Как скрафтить",
    kickoff: b => `Как скрафтить этот предмет${b.base ? ` (${b.base}, ilvl ${b.ilvl})` : ""}${b.goal ? `: ${b.goal}` : ""}? `
      + "Дай пошаговый план крафта: каждый шаг — какая сфера/эссенция/омен, шанс успеха и цена шага, сколько выйдет всего, "
      + "что делать при промахе, и что выгоднее — крафтить или купить готовое. Про билд не пиши.",
    chips: ["Вот что получилось после шага — что дальше? (вставь предмет)", "Крафтить или дешевле купить готовое?", "Какие омены и эссенции нужны?"],
    emptyHtml: "Ассистент знает пул модов этой базы с весами, цены всей крафт-валюты и оменов. Веди крафт по шагам: после каждого шага вставляй предмет — он скажет, что делать дальше.",
  });

  // deep link «⚒ Скрафтить» from any tab (build view, assistant cards, audit): fill the target and calculate at once
  async function target(spec) {
    await loadCatalog();
    let base = spec.base || "";
    let cls = Object.keys(catalog).find(c => (catalog[c] || []).some(b => b.name === base));
    if (!cls) {
      const want = String(spec.cls || spec.slot || "").replace(/\s*\d+$/, "").toLowerCase();
      cls = Object.keys(catalog).find(c => c.toLowerCase() === want) || Object.keys(catalog).find(c => want.includes(c.toLowerCase()));
    }
    if (cls) { clsPick.set(cls); fillBases(cls, base || undefined); }
    targets.clear(); renderTargets();
    if (!cls && !base) { toast("info", "Выбери базу", "не понял, какой это тип предмета"); return; }
    // no base named: the server picks the one whose implicit helps the target (not the first of the list)
    await calcPlan({base, cls: base ? "" : cls, ilvl: spec.ilvl || 82, mods: spec.mods || []});
  }

  // ───── 💰 craft for sale: every number from data (sim on PoE2DB weights, currency + base + sale prices from the market) ─────
  let mode = "self", prof = null;
  const S = {undercut: 10, risk: "avg", secs: 5, hour: 0, count: 1, minroi: 20, method: 0};
  function setMode(m) {
    mode = m;
    root.querySelectorAll(".cr-mode button").forEach(b => b.classList.toggle("on", b.dataset.m === m));
    $("#cr-calc").hidden = $("#cr-buy").hidden = m === "sell";
    $("#cr-profit").hidden = $("#cr-scan").hidden = m !== "sell";
    $("#cr-sell").hidden = m !== "sell";
    $("#cr-assist").hidden = m !== "self";
    $("#cr-stash").hidden = m !== "stash";
    $("#cr-pickcard").hidden = $("#cr-poolcard").hidden = m === "stash";
    $("#cr-result").innerHTML = "";
    if (m === "sell") { loadWatch(); pollScan(true); loadRecipes(); loadMarket(); }
    if (m === "stash") loadStash();
    renderTargets();
  }
  root.querySelectorAll(".cr-mode button").forEach(b => b.onclick = () => setMode(b.dataset.m));
  const money = ex => { if (ex == null || !isFinite(ex)) return "—"; const d = prof ? prof.ex_per_div : 0;
    return Math.abs(ex) >= d && d ? `${fmt.div(ex / d)} div` : `${fmt.ex(ex)} ex`; };
  const sign = ex => (ex >= 0 ? "+" : "−") + money(Math.abs(ex));

  async function calcProfit(spec) {
    const body = spec || {base: basePick.value, ilvl: +$("#cr-ilvl").value, mods: wantedLines()};
    const box = $("#cr-result");
    box.innerHTML = `<div class="card"><div class="skel"></div><div class="skel"></div><div class="small muted">Симулирую крафт по весам PoE2DB, смотрю цены базы и готовых предметов на трейде…</div></div>`;
    box.scrollIntoView({behavior: "smooth", block: "start"});
    try { prof = await api.post("/api/craft/profit", body); S.method = 0; renderProfit(); }
    catch (e) { box.innerHTML = `<div class="card"><div class="kb warn"><span class="ki">⚠</span><div class="kt">${esc(e.message)}</div></div></div>`; }
  }
  function compute() {
    const m = prof.methods[S.method] || prof.methods[0];
    if (!m) return null;
    const cal = prof.calibration || {cost_k: 1, sale_k: 1, n: 0};
    const cost = (S.risk === "p90" ? m.p90_ex : S.risk === "p75" ? m.p75_ex : m.cost_ex) * cal.cost_k;
    const s = prof.sale, market = (s.median_ex || s.min_ex) && (s.median_ex || s.min_ex) * cal.sale_k;
    const hours = m.actions * S.secs / 3600;
    const difficulty = Math.min(10, Math.max(1, Math.round(Math.log10(Math.max(1, m.tries || 1)) * 3 + m.actions / 150 + (m.key.startsWith("alch") ? 1 : 0))));
    if (!market) return {m, cost, hours, difficulty, noSale: true};
    // no measured base price: the cost leaves out every base the craft burns — never call it profitable
    if (!(prof.base_price && prof.base_price.ex)) {
      // white bases not on trade (they drop, or sit in the stash): the decision is the price a base may cost at most
      const bases = ((m.currency || []).find(c => c.name === "Белая база") || {}).count || 0;
      const sellNow = market * (1 - S.undercut / 100);
      return {m, cost, hours, difficulty, noBase: true, bases, breakEven: bases ? (sellNow - cost) / bases : null, sellNow};
    }
    // every extra copy sells a bit cheaper; the thinner the market, the faster the price drops
    const step = Math.min(0.15, 0.75 / Math.max(1, s.count));
    const factor = Array.from({length: S.count}, (_, i) => Math.max(0.4, 1 - i * step)).reduce((a, b) => a + b, 0) / S.count;
    const sell = market * (1 - S.undercut / 100) * factor;
    const profit = sell - cost, roi = cost ? profit / cost * 100 : 0;
    const timeCost = hours * S.hour * prof.ex_per_div, net = profit - timeCost;
    const perHour = net / Math.max(hours, 1 / 60);
    const coef = net / (prof.ex_per_div || 1) / difficulty;
    // «good» only when it still pays with bad luck (75% of runs fit), above the minimum ROI, on a real market
    const badLuck = sell - m.p75_ex * cal.cost_k - timeCost;
    const verdict = net > 0 && badLuck > 0 && roi >= S.minroi && s.count >= 3 ? "good" : net > 0 ? "thin" : "bad";
    return {m, cost, sell, profit, roi, hours, timeCost, net, perHour, difficulty, coef, verdict, factor, badLuck, cal};
  }
  const slider = (key, label, min, max, step, unit, hint) => `<label class="cs-sl"><span>${label} <b id="cs-v-${key}">${S[key]}${unit}</b></span>
      <input type="range" min="${min}" max="${max}" step="${step}" value="${S[key]}" data-k="${key}" data-u="${unit}"><small>${hint}</small></label>`;
  function renderProfit() {
    const p = prof, s = p.sale, bp = p.base_price || {};
    $("#cr-result").innerHTML = `<div class="card glow" style="margin-bottom:16px">
      <div class="sec-h" style="--k:var(--k-money)"><span class="si">💰</span><div><h3>Крафт на продажу: ${esc(p.base)} (ilvl ${p.ilvl}) · ${esc(p.league)}</h3>
        <div class="sd">шансы — симуляция по весам PoE2DB; цены валюты — poe.ninja; база и готовые предметы — живой трейд. ИИ здесь ничего не выдумывает</div></div>
        <span class="spacer"></span><button class="btn sm" id="cs-recheck">⟳ Пересчитать</button><button class="btn sm primary" id="cs-watch">⭐ Отслеживать</button></div>
      <div class="row" style="gap:6px;flex-wrap:wrap;margin-bottom:10px">${p.targets.map(t => `<span class="pill ${t.gen === "prefix" ? "item" : "gem"}">${t.gen === "prefix" ? "P" : "S"} · ${esc(t.text_ru)} <small>(T${t.tier}+)</small></span>`).join("")}</div>
      ${p.missing.length ? `<div class="kb warn"><span class="ki">⚠</span><div class="kt">Не нашёл в пуле базы: ${p.missing.map(esc).join(", ")}</div></div>` : ""}
      <div id="cs-verdict"></div>
      <div class="cs-kpis" id="cs-kpis"></div>
      ${(p.calibration || {}).n ? `<div class="kb gem" style="margin-bottom:10px"><span class="ki">🧠</span><div class="kt"><b class="kh">Учтён твой опыт: ${p.calibration.n} крафт(ов) этого типа</b>
        себестоимость ×${p.calibration.cost_k}, продажа ×${p.calibration.sale_k} · итог твоих крафтов: ${p.calibration.profit_total_ex >= 0 ? "+" : ""}${fmt.ex(p.calibration.profit_total_ex)} ex</div></div>` : ""}
      <details class="cs-out"><summary>📝 Записать результат этого крафта — тула учится на нём</summary>
        <div class="row" style="gap:8px;margin-top:8px;flex-wrap:wrap"><input class="inp" id="co-spent" type="number" min="0" step="any" placeholder="потратил" style="width:130px">
          <input class="inp" id="co-sold" type="number" min="0" step="any" placeholder="продал за (0 — не продал)" style="width:200px">
          <select class="inp" id="co-unit" style="width:110px"><option value="ex">exalted</option><option value="div">divine</option></select>
          <button class="btn sm primary" id="co-save">Сохранить</button></div>
        <div class="tiny faint" style="margin-top:4px">тула сравнит с прогнозом и поправит будущие расчёты для «${esc(p.cls)}»</div></details>
      <div class="cs-grid">
        <div class="card cs-panel"><div class="bv-sgh" style="--k:var(--k-info)">⚙ Твои условия</div>
          <label class="cs-sl"><span>Способ крафта</span><select class="inp" id="cs-method">${p.methods.map((m, i) => `<option value="${i}" ${i === S.method ? "selected" : ""}>${esc(m.title)} · успех ${m.success}% с базы</option>`).join("")}</select></label>
          <label class="cs-sl"><span>Удача (сколько баз уйдёт)</span><select class="inp" id="cs-risk"><option value="avg">в среднем</option><option value="p75">плохой расклад (75% случаев уложишься)</option><option value="p90">очень плохой (90%)</option></select></label>
          ${slider("undercut", "Продавать дешевле рынка на", 0, 40, 1, "%", "чтобы продалось быстрее")}
          ${slider("count", "Сколько штук скрафтить", 1, 10, 1, " шт", "рынок насыщается — каждая следующая дешевле")}
          ${slider("secs", "Секунд на одно действие", 2, 15, 1, " с", "клик валютой + проверка предмета")}
          ${slider("hour", "Цена твоего часа", 0, 20, 0.5, " div/ч", "0 — время не считать")}
          ${slider("minroi", "Минимальная выгода (ROI)", 0, 100, 5, "%", "ниже — «маржа маленькая»")}</div>
        <div class="card cs-panel"><div class="bv-sgh" style="--k:var(--k-money)">🛒 Рынок сейчас</div>
          <div class="kb ${s.count >= 8 ? "node" : s.count >= 3 ? "info" : "warn"}"><span class="ki">🏷</span><div class="kt"><b class="kh">Готовые предметы с такими модами</b>
            ${s.count ? `от <b>${money(s.min_ex)}</b>, обычно <b>${money(s.median_ex)}</b> · продавцов ${s.count} (всего лотов ${s.total}) · свежих за 3 дня: ${s.fresh}
              ${s.scope === "class" ? "<br>на этой базе почти нет лотов — цена по всему типу предмета" : ""}` : "На трейде таких нет — цену продажи не оценить, это риск"}
            ${s.url ? `<div style="margin-top:6px"><button class="btn sm" data-url="${esc(s.url)}">Открыть трейд (что продают)</button></div>` : ""}</div></div>
          <div class="kb info"><span class="ki">⚪</span><div class="kt"><b class="kh">Белая база ${esc(p.base)} ilvl ${p.ilvl}+</b>
            ${bp.ex ? `≈ <b>${money(bp.ex)}</b> за штуку (продавцов ${bp.count})` : "на трейде не нашлась — стоимость баз в расчёт не включена"}
            ${bp.url ? `<div style="margin-top:6px"><button class="btn sm" data-url="${esc(bp.url)}">Купить базы</button></div>` : ""}</div></div>
          <div id="cs-method-box"></div></div>
      </div></div>`;
    $("#cs-risk").value = S.risk;
    $("#co-save").onclick = async e => {
      const k = $("#co-unit").value === "div" ? p.ex_per_div : 1, spent = +$("#co-spent").value * k, sold = +$("#co-sold").value * k;
      if (!spent) { toast("info", "Впиши, сколько потратил"); return; }
      const c = compute();
      try { const cal = await api.post("/api/craft/outcome", {cls: p.cls, base: p.base, mods: p.targets.map(t => t.trade), spent_ex: spent, sold_ex: sold,
          pred_cost_ex: c ? c.m.cost_ex : null, pred_sale_ex: (p.sale.median_ex || p.sale.min_ex || null), league: p.league});
        toast("ok", "Результат сохранён", `тула учтёт его: по «${p.cls}» теперь ${cal.n} крафт(ов), поправки ×${cal.cost_k} / ×${cal.sale_k}`);
        p.calibration = cal; renderProfit(); }
      catch (err) { toast("err", "Результат", err.message); }
    };
    $("#cs-risk").onchange = e => { S.risk = e.target.value; renderKpi(); };
    $("#cs-method").onchange = e => { S.method = +e.target.value; renderKpi(); };
    root.querySelectorAll(".cs-sl input[type=range]").forEach(r => r.oninput = () => { S[r.dataset.k] = +r.value; $(`#cs-v-${r.dataset.k}`).textContent = r.value + r.dataset.u; renderKpi(); });
    root.querySelectorAll("#cr-result [data-url]").forEach(b => b.onclick = () => window.open(b.dataset.url, "_blank"));
    $("#cs-recheck").onclick = () => calcProfit({base: p.base, ilvl: p.ilvl, mods: p.targets.map(t => t.trade)});
    $("#cs-watch").onclick = async e => { const b = e.currentTarget; spinBtn(b, true, "Добавляю…");
      try { await api.post("/api/craft/watch", {base: p.base, ilvl: p.ilvl, mods: p.targets.map(t => t.trade), label: `${p.base}: ${p.targets.map(t => t.text_ru).join(", ")}`});
        toast("ok", "Крафт отслеживается", "тула перепроверяет его раз в 3 часа и скажет, если выгода появится или пропадёт"); loadWatch(); }
      catch (err) { toast("err", "Отслеживание", err.message); }
      spinBtn(b, false); };
    renderKpi();
  }
  function renderKpi() {
    const c = compute();
    if (!c) { $("#cs-kpis").innerHTML = `<div class="kb warn"><span class="ki">⚠</span><div class="kt">Ни одним способом это почти не скрафтить — выбери другие моды или тиры пониже.</div></div>`; return; }
    const V = {good: ["node", "✅ Выгодно сейчас", "окупается с запасом даже при плохом раскладе (75% случаев) и есть кому продать"],
               thin: ["info", "🟡 Рискованно", `в среднем в плюс, но ${c.badLuck <= 0 ? "при плохом раскладе уйдёшь в минус" : "ниже твоего минимального ROI или рынок тонкий"} — прибыль не гарантирована`],
               bad: ["warn", "❌ Невыгодно", "крафт стоит больше, чем за него дадут — дешевле купить готовое или крафтить другое"]};
    const v = c.noSale ? ["warn", "❓ Цену продажи не оценить", "на трейде нет таких предметов — продавать вслепую рискованно"]
      : c.noBase ? (c.breakEven > 0
        ? ["info", `❓ Окупится, если белая база ≤ ${money(c.breakEven)}`, `белых баз ilvl ${prof.ilvl}+ на трейде нет (обычно с пола или из сундука): на один готовый предмет уходит ≈ ${fmt.n(Math.round(c.bases), "база|базы|баз")}, валюта ≈ ${money(c.cost)}, продашь ≈ ${money(c.sellNow)}`]
        : ["bad", "✗ Не окупится даже с бесплатными базами", `валюта на один предмет ≈ ${money(c.cost)} дороже цены продажи ≈ ${money(c.sellNow)}`]) : V[c.verdict];
    $("#cs-verdict").innerHTML = `<div class="kb ${v[0]}" style="margin-bottom:10px"><span class="ki">⚖</span><div class="kt"><b class="kh">${v[1]}</b>${v[2]}</div></div>`;
    const k = (label, val, cls, sub) => `<div class="cs-kpi ${cls || ""}"><span>${label}</span><b>${val}</b>${sub ? `<small>${sub}</small>` : ""}</div>`;
    $("#cs-kpis").innerHTML = [
      k("Себестоимость", money(c.cost), "", S.risk === "avg" ? `в среднем · ${fmt.n(c.m.tries, "база|базы|баз")}` : S.risk === "p75" ? "плохой расклад (75%)" : "очень плохой расклад (90%)"),
      (c.noSale || c.noBase) ? "" : k("Продашь за", money(c.sell), "", `${S.undercut ? `−${S.undercut}% к рынку` : "по рынку"}${S.count > 1 ? ` · ${S.count} шт, в среднем ×${c.factor.toFixed(2)}` : ""}`),
      (c.noSale || c.noBase) ? "" : k("Прибыль с крафта", sign(c.net), c.net >= 0 ? "up" : "down", S.hour ? `с учётом времени (−${money(c.timeCost)})` : "без учёта времени"),
      (c.noSale || c.noBase) ? "" : k("ROI", `${c.roi >= 0 ? "+" : ""}${c.roi.toFixed(0)}%`, c.roi >= S.minroi ? "up" : c.roi >= 0 ? "" : "down", "прибыль / вложения"),
      (c.noSale || c.noBase) ? "" : k("В час", sign(c.perHour), c.perHour >= 0 ? "up" : "down", `≈ ${Math.max(1, Math.round(c.hours * 60))} мин на успешный крафт`),
      k("Сложность", `${c.difficulty}/10`, c.difficulty >= 7 ? "down" : c.difficulty <= 3 ? "up" : "", `${fmt.n(c.m.actions, "действие|действия|действий")} · успех ${c.m.success}% с базы${c.m.rough ? ` · ⚠ оценка грубая (${fmt.n(c.m.successes, "успех|успеха|успехов")} в симуляции)` : ""}`),
      (c.noSale || c.noBase) ? "" : k("Выгода / сложность", `${c.coef >= 0 ? "+" : ""}${c.coef.toFixed(2)} div`, c.coef > 0 ? "up" : "down", "на 1 пункт сложности"),
    ].join("") + (S.count > 1 && !(c.noSale || c.noBase) ? k(`Всего за ${S.count} шт`, sign(c.net * S.count), c.net >= 0 ? "up" : "down", `вложить ≈ ${money(c.cost * S.count)}`) : "");
    const m = c.m;
    $("#cs-method-box").innerHTML = `<div class="bv-sgh" style="--k:var(--k-act);margin-top:8px">⚒ ${esc(m.title)}</div>
      ${m.currency.length ? `<div class="cr-cur">${m.currency.map(x => `<div title="${esc(x.name)}${x.ex ? ` · ${fmt.ex(x.ex)} ex/шт` : ""}">${x.icon ? `<img src="${esc(x.icon)}" alt="">` : "<span>🧱</span>"}<b>×${x.count >= 10 ? Math.round(x.count) : x.count}</b><small>${esc((x.ru || x.name).replace(/^Сфера /, "").replace(/^Orb of /, "").replace(/ Orb$/, ""))}</small></div>`).join("")}</div>` : ""}
      ${m.steps.map((x, i) => `<div class="kb act" style="margin:4px 0"><span class="ki">${i + 1}</span><div class="kt">${esc(x)}</div></div>`).join("")}`;
  }
  $("#cr-profit").onclick = () => calcProfit();

  // ───── 📦 «Твой сундук»: items from Ctrl+C and the player's trade listings, judged with real numbers ─────
  let stashTimer = null, stashFilter = "all", stashData = null;
  const VK = {wear: ["node", "🛡 надеть"], sell: ["money", "💰 продать"], craft: ["gem", "⚒ докрафтить"], junk: ["skip", "🗑 мусор"]};
  async function loadStash() {
    clearTimeout(stashTimer);
    try { stashData = await api.get("/api/craft/stash"); } catch (_) { return; }
    renderStash();
    // poll only while the stash is on screen (another tab or mode stops it; coming back restarts it)
    if (mode === "stash" && root.offsetParent) stashTimer = setTimeout(loadStash, stashData.eval.running ? 2500 : 4000);
  }
  function renderStash() {
    const d = stashData, its = d.items;
    const counts = {all: its.length};
    its.forEach(x => { const k = x.verdict ? x.verdict.kind : "new"; counts[k] = (counts[k] || 0) + 1; });
    const total = its.reduce((s, x) => s + ((x.price && x.price.ex) || 0), 0);
    const list = its.filter(x => stashFilter === "all" || (x.verdict ? x.verdict.kind : "new") === stashFilter);
    $("#st-acc").textContent = d.account || "аккаунт не подключён";
    $("#st-collect").classList.toggle("on", d.collect);
    $("#st-track").classList.toggle("on", d.track.on);
    $("#st-track").textContent = d.track.on ? `● Слежу за публичными вкладками${d.track.last ? " · " + fmt.ago(d.track.last) : ""}` : "○ Следить за публичными вкладками";
    $("#st-collect").textContent = d.collect ? "● Собираю Ctrl+C — жми в игре на предметах" : "○ Собирать предметы из Ctrl+C";
    $("#st-eval-st").innerHTML = d.eval.running ? `<span class="pill info"><span class="spin-s"></span> оцениваю ${d.eval.done} из ${d.eval.total}: ${esc(d.eval.step || "")}</span>` : "";
    $("#st-sum").innerHTML = `<div class="cs-kpi"><span>Предметов</span><b>${its.length}</b></div>
      <div class="cs-kpi up"><span>Надеть</span><b>${counts.wear || 0}</b></div><div class="cs-kpi"><span>Продать</span><b>${counts.sell || 0}</b></div>
      <div class="cs-kpi"><span>Докрафтить</span><b>${counts.craft || 0}</b></div><div class="cs-kpi"><span>Оценка всего</span><b>${fmt.ex(total)} ex</b></div>`;
    $("#st-filters").innerHTML = [["all", "Все"], ["wear", "🛡 Надеть"], ["sell", "💰 Продать"], ["craft", "⚒ Докрафтить"], ["junk", "🗑 Мусор"], ["new", "Не оценено"]]
      .map(([k, l]) => `<button class="${stashFilter === k ? "on" : ""}" data-f="${k}">${l}${counts[k] ? ` <small>${counts[k]}</small>` : ""}</button>`).join("");
    root.querySelectorAll("#st-filters [data-f]").forEach(b => b.onclick = () => { stashFilter = b.dataset.f; renderStash(); });
    const cur = Object.entries(d.currency || {}).sort((a, b) => b[1] - a[1]);
    $("#st-cur").innerHTML = cur.length ? `<div class="small"><b>💱 Твоя валюта</b> <span class="muted">(стаки по Ctrl+C за 14 дней — крафт вычтет её из списка покупок)</span>
      <button class="btn sm ghost" id="st-cur-clear">очистить</button></div><div class="row" style="gap:6px;flex-wrap:wrap;margin-top:4px">`
      + cur.map(([n, c]) => `<span class="pill">${esc(n)} ×${c.toLocaleString("ru")}</span>`).join("") + "</div>"
      : `<div class="tiny faint">💱 Валюта: при включённом сборе наведи на стак (сферы, омены, эссенции) и Ctrl+C — крафт посчитает, что докупить в обменнике.</div>`;
    const cc = $("#st-cur-clear");
    if (cc) cc.onclick = async () => { await api.del("/api/craft/stash/currency"); loadStash(); };
    $("#st-grid").innerHTML = list.length ? list.map(x => { const v = x.verdict, p = x.price || {}, me = x.self, cr = x.craft;
      return `<div class="st-card ${v ? "v-" + v.kind : ""}" data-id="${esc(x.id)}">
        <div class="row" style="gap:10px;align-items:flex-start">${x.icon ? `<img class="st-ic" src="${esc(x.icon)}" alt="" loading="lazy">` : `<div class="st-ic"></div>`}
          <div style="min-width:0;flex:1"><b class="st-n r-${esc((x.rarity || "").toLowerCase())}">${esc(x.name || x.base || "?")}</b>
            <div class="tiny faint">${esc(x.base || "")}${x.ilvl ? " · ilvl " + x.ilvl : ""}${x.corrupted ? " · осквернён" : ""} · ${x.source === "trade" ? "лот на трейде" : "из игры"}</div></div>
          ${v ? `<span class="pill ${VK[v.kind][0]}">${VK[v.kind][1]}</span>` : `<span class="pill">не оценено</span>`}</div>
        ${(x.mods || []).length ? `<div class="st-mods">${x.mods.slice(0, 6).map(m => `<div>${esc(m)}</div>`).join("")}</div>` : ""}
        ${v ? `<div class="small" style="margin-top:6px">${esc(v.text)}</div>` : ""}
        ${x.finish ? `<div class="kb ${x.finish.verdict === "craft" ? "node" : "warn"}" style="margin:6px 0"><span class="ki">💹</span><div class="kt"><b class="kh">${esc(x.finish.text)}</b>
          ${(x.finish.options || []).slice(0, 4).map(o => `<div class="tiny">${esc(o.action)}: цена ${fmt.ex(o.cost_ex)} ex · в среднем вернёт ${fmt.ex(o.ev_ex)} ex · ценный мод ${o.p}% → <b class="${o.net_ex > 0 ? "up" : "down"}">${o.net_ex > 0 ? "+" : ""}${fmt.ex(o.net_ex)} ex</b></div>`).join("")}
          ${(x.finish.priced || []).length ? `<details class="tiny"><summary>что прибавит каждый мод (трейд)</summary>${x.finish.priced.map(m => `<div>${esc(m.text)}: ${m.sale_ex == null ? `рынка нет (${m.count})` : `${fmt.ex(m.sale_ex)} ex, +${fmt.ex(m.gain_ex)} ex`}</div>`).join("")}</details>` : ""}</div></div>` : ""}
        <div class="row tiny faint" style="gap:10px;margin-top:4px;flex-wrap:wrap">
          ${p.pending ? `<span>цена: трейд просит подождать — повторю</span>` : p.ex ? `<span>цена ~${fmt.ex(p.ex)} ex (${p.count} похожих)</span>` : x.price ? "<span>похожих на трейде нет</span>" : ""}
          ${x.listed ? `<span>выставлен за ${esc(String(x.listed.amount))} ${esc(x.listed.currency || "")}</span>` : ""}
          ${x.gone ? `<span style="color:#fcd34d">пропал с трейда ${fmt.ago(x.gone)} — продан?</span>` : ""}
          ${me ? `<span>в билде: DPS ${me.dps >= 0 ? "+" : ""}${me.dps}% · EHP ${me.ehp >= 0 ? "+" : ""}${me.ehp}%</span>` : ""}
          ${cr && Object.keys(cr.free || {}).length ? `<span>свободно: ${Object.entries(cr.free).map(([s, n]) => `${n} ${s === "prefix" ? "преф." : "суфф."}`).join(", ")}</span>` : ""}</div>
        <div class="row" style="gap:6px;margin-top:6px">${p.url ? `<button class="btn sm ghost" data-url="${esc(p.url)}">Трейд ↗</button>` : ""}
          ${cr && x.rarity === "Rare" ? `<button class="btn sm ghost" data-sell="${esc(x.id)}">💰 Крафт на продажу</button>` : ""}
          ${cr && x.rarity === "Rare" && Object.keys(cr.free || {}).length ? `<button class="btn sm" data-fin="${esc(x.id)}" title="около 6 поисков на трейде">💹 Окупится докрафт?</button>` : ""}
          <button class="btn sm ghost" data-ev="${esc(x.id)}">⟳</button><button class="btn sm ghost danger" data-del="${esc(x.id)}">✕</button></div></div>`; }).join("")
      : `<div class="faint small" style="padding:10px">${its.length ? "Ничего по фильтру." : "Пусто. Включи «Собирать предметы из Ctrl+C» и в игре пройдись по вкладке тайника, нажимая Ctrl+C на предметах, — или нажми «Мои лоты на трейде»."}</div>`;
    root.querySelectorAll("#st-grid [data-url]").forEach(b => b.onclick = () => window.open(b.dataset.url, "_blank"));
    root.querySelectorAll("#st-grid [data-del]").forEach(b => b.onclick = async () => { await api.del(`/api/craft/stash/${b.dataset.del}`); loadStash(); });
    root.querySelectorAll("#st-grid [data-ev]").forEach(b => b.onclick = async () => { spinBtn(b, true, "…"); try { await api.post(`/api/craft/stash/evaluate?iid=${b.dataset.ev}`); } catch (e) { toast("err", "Оценка", e.message); } loadStash(); });
    root.querySelectorAll("#st-grid [data-fin]").forEach(b => b.onclick = async () => { spinBtn(b, true, "Считаю по рынку…"); try { await api.post(`/api/craft/stash/finish?iid=${b.dataset.fin}`); } catch (e) { toast("err", "Докрафт", e.message); } loadStash(); });
    root.querySelectorAll("#st-grid [data-sell]").forEach(b => b.onclick = () => { const x = its.find(i => i.id === b.dataset.sell); window.P2.craftProfit({base: x.base, ilvl: x.ilvl || 82, mods: x.mods.slice(0, 4)}); });
  }
  $("#st-collect").onclick = async () => { const on = !(stashData && stashData.collect);
    await api.post("/api/craft/stash/collect", {on}); toast(on ? "ok" : "info", on ? "Собираю сундук" : "Сбор выключен", on ? "в игре наводи на предмет и жми Ctrl+C — он появится здесь" : ""); loadStash(); };
  // the guide stays open until the player folds it (remembered in this browser)
  const guideOpen = v => { $("#st-guide").hidden = !v; $("#st-guide-show").hidden = v; try { localStorage.setItem("p2.stashGuide", v ? "1" : "0"); } catch (_) {} };
  $("#st-guide-hide").onclick = () => guideOpen(false);
  $("#st-guide-show").onclick = () => guideOpen(true);
  try { if (localStorage.getItem("p2.stashGuide") === "0") guideOpen(false); } catch (_) {}
  $("#st-track").onclick = async () => { const on = !(stashData && stashData.track.on);
    await api.post("/api/craft/stash/track", {on}); toast(on ? "ok" : "info", on ? "Слежу за публичными вкладками" : "Слежение выключено",
      on ? "раз в 30 минут: новые предметы, оценка, проданные" : ""); if (on) api.post("/api/craft/stash/trade").catch(() => {}); loadStash(); };
  $("#st-trade").onclick = async e => { const b = e.currentTarget; spinBtn(b, true, "Ищу лоты…");
    try { const r = await api.post("/api/craft/stash/trade"); toast("ok", "Лоты с трейда", `добавлено новых: ${r.added}`); } catch (err) { toast("err", "Трейд", err.message); }
    spinBtn(b, false); loadStash(); };
  $("#st-eval").onclick = async () => { await api.post("/api/craft/stash/evaluate"); toast("info", "Оцениваю сундук", "цена с трейда, польза в PoB, крафт — по одному предмету"); loadStash(); };
  $("#st-advice").onclick = async e => { const b = e.currentTarget; spinBtn(b, true, "Думаю…");
    try { const r = await api.post("/api/craft/stash/advice"); $("#st-adv").innerHTML = `<div class="card glow" style="margin-top:12px"><div class="md">${md(r.text)}</div></div>`; }
    catch (err) { toast("err", "ИИ", err.message); } spinBtn(b, false); };
  $("#st-add").onclick = async () => { const t = $("#st-text").value.trim(); if (!t) return;
    try { await api.post("/api/craft/stash/add", {text: t}); $("#st-text").value = ""; loadStash(); } catch (err) { toast("err", "Сундук", err.message); } };
  $("#st-clear").onclick = async () => { if (!confirm("Очистить сундук в туле? (в игре ничего не изменится)")) return; await api.del("/api/craft/stash"); loadStash(); };

  // deep link from other tabs (stash, assistant): «is crafting this for sale worth it?»
  window.P2.craftProfit = async spec => { await loadCatalog(); setMode("sell"); return calcProfit(spec); };

  // tracked crafts
  async function loadWatch() {
    const box = $("#cs-watch-list");
    let list = [];
    try { list = await api.get("/api/craft/watch"); } catch (_) {}
    box.innerHTML = list.length ? list.map(e => { const n = e.now || {}, pv = e.prev || {};
      const trend = n.profit_ex != null && pv.profit_ex != null ? (n.profit_ex > pv.profit_ex ? "↗" : n.profit_ex < pv.profit_ex ? "↘" : "→") : "";
      let streak = 0; for (const h of (e.history || []).slice().reverse()) { if (h.profit_ex > 0) streak++; else break; }
      return `<div class="cs-wrow" data-id="${esc(e.id)}"><div style="min-width:0;flex:1"><b>${esc(e.label)}</b>
        <div class="tiny faint">ilvl ${e.ilvl} · проверено ${e.last_check ? fmt.ago(e.last_check) : "—"}</div></div>
        ${streak >= 2 ? `<span class="pill node" title="в плюсе ${streak} проверки подряд">стабильно ×${streak}</span>` : ""}
        <span class="pill ${n.profit_ex == null ? "info" : n.profit_ex > 0 ? "node" : "warn"}">${n.profit_ex == null ? (n.break_even_base_ex > 0 ? `окупится при базе ≤ ${fmt.ex(n.break_even_base_ex)} ex` : n.break_even_base_ex != null ? "не окупится" : "нет цены") : (n.profit_ex >= 0 ? "+" : "") + fmt.ex(n.profit_ex) + " ex"} ${trend}</span>
        <button class="btn sm ghost" data-a="open" title="Открыть расчёт">📊</button><button class="btn sm ghost" data-a="check" title="Перепроверить сейчас">⟳</button><button class="btn sm ghost danger" data-a="del" title="Убрать">✕</button></div>`; }).join("")
      : `<div class="faint small">Пока пусто. Посчитай крафт и нажми «⭐ Отслеживать» — тула будет перепроверять его сама.</div>`;
    box.querySelectorAll(".cs-wrow").forEach(r => r.querySelectorAll("[data-a]").forEach(b => b.onclick = async () => {
      const e = list.find(x => x.id === r.dataset.id);
      if (b.dataset.a === "open") return calcProfit({base: e.base, ilvl: e.ilvl, mods: e.mods});
      if (b.dataset.a === "del") { await api.del(`/api/craft/watch/${e.id}`); return loadWatch(); }
      spinBtn(b, true, "…"); try { await api.post(`/api/craft/watch/${e.id}/check`); } catch (err) { toast("err", "Проверка", err.message); } loadWatch();
    }));
  }
  // recipes from crafting guides
  let recipesData = null, recTimer = null;
  async function loadRecipes() {
    clearTimeout(recTimer);
    try { recipesData = await api.get("/api/craft/recipes"); } catch (_) { return; }
    renderRecipes();
    if (recipesData.state.running) recTimer = setTimeout(loadRecipes, 3000);
  }
  root.addEventListener("click", async e => {
    const b = e.target.closest(".cr-partial");
    if (!b || !lastPlan) return;
    const out = b.parentElement.querySelector(".cr-partial-out");
    spinBtn(b, true, "…");
    try { const rows = await api.post("/api/craft/partial", {base: lastPlan.base, targets: lastPlan.targets});
      out.innerHTML = rows.map(r => `«${esc(r.text)}»: ${r.median_ex != null ? `обычно <b>${fmt.ex(r.median_ex)} ex</b>, от ${fmt.ex(r.min_ex)} ex` : r.count ? `мало лотов (${r.count}), от ${fmt.ex(r.min_ex)} ex` : "на рынке нет"}`).join(" · "); }
    catch (err) { out.textContent = err.message; } finally { spinBtn(b, false); }
  });
  root.addEventListener("click", async e => {
    if (!e.target.closest("#cs-forge")) return;
    const out = $("#cs-forge-out"); spinBtn(e.target, true, "…");
    try { const d = await api.get("/api/craft/forge");
      out.innerHTML = d.rows.length ? `<table class="tbl"><thead><tr><th>Руда</th><th>Предмет</th><th class="num">Руда</th><th class="num">Продажа: от / обычно</th><th class="num">Лотов</th><th class="num">Выгода</th></tr></thead><tbody>${d.rows.map(r => `<tr><td>${esc(r.ore)}</td><td>${r.url ? `<a href="${esc(r.url)}" target="_blank">${esc(r.unique)}</a>` : esc(r.unique)}</td><td class="num">${r.ore_ex != null ? fmt.ex(r.ore_ex) + " ex" : "нет на рынке"}</td><td class="num">${r.sale_min_ex != null ? `${fmt.ex(r.sale_min_ex)} / ${fmt.ex(r.sale_median_ex)} ex` : "—"}</td><td class="num">${r.count}</td><td class="num">${r.profit_ex != null ? `<b class="${r.profit_ex > 0 ? "up" : "down"}">${r.profit_ex > 0 ? "+" : ""}${fmt.ex(r.profit_ex)} ex</b>` : `<span class="faint" title="меньше 4 лотов или руды нет на рынке: сравнивать не с чем">—</span>`}</td></tr>`).join("")}</tbody></table>` : "В вики нет таблицы рецептов кузницы."; }
    catch (err) { out.textContent = err.message; } finally { spinBtn(e.target, false); }
  });
  root.addEventListener("click", async e => {
    if (!e.target.closest("#cs-lore")) return;
    const out = $("#cs-lore-out"); spinBtn(e.target, true, "…");
    try { const d = await api.get("/api/craft/loreweave"); out.innerHTML = `60 колец ≈ <b>${fmt.ex(d.rings_ex)} ex</b> (от ${fmt.ex(d.ring_min_ex)} ex за штуку) · Loreweave на рынке: от ${fmt.ex(d.sale_min_ex)}, обычно ${fmt.ex(d.sale_median_ex)} ex · <b class="${d.profit_median_ex > 0 ? "up" : "down"}">${d.profit_median_ex > 0 ? "+" : ""}${fmt.ex(d.profit_median_ex)} ex</b> при обычной цене. Выпавшие моды могут сдвинуть итог в разы.`; }
    catch (err) { out.textContent = err.message; } finally { spinBtn(e.target, false); }
  });
  async function loadMarket() {
    const box = $("#cs-market");
    if (!box) return;
    let d; try { d = await api.get("/api/craft/market"); } catch (_) { return; }
    const head = `<div class="tiny faint" style="margin-bottom:6px">проверено крафтов: ${d.checked.toLocaleString("ru")}${d.left ? ` · в очереди ещё ${d.left.toLocaleString("ru")}` : ""} · скан идёт в фоне сам (в бою медленнее)</div>`;
    if (!d.rows.length) { box.innerHTML = head + `<div class="faint small">${d.checked ? "Сейчас ни один проверенный крафт не окупается — как только появится, он будет здесь." : "Скан ещё не дал результатов: он работает в окне тулы, с низким приоритетом на трейде."}</div>`; return; }
    box.innerHTML = head + `<table class="tbl"><thead><tr><th>Предмет и цели</th><th class="num">Себестоимость</th><th class="num">Продашь за</th><th class="num">Прибыль</th><th>Рынок</th><th></th></tr></thead><tbody>`
      + d.rows.map((r, i) => `<tr><td><b>${esc(r.base)}</b>${r.source !== "скан" ? ` <span class="pill gem">${esc(r.source)}</span>` : ""}<div class="small">${r.targets.map(esc).join(" · ")}</div>${r.bought ? `<div class="tiny up" title="${esc(r.bought.title)}">🛒 дешевле начать с готовой базы: ${fmt.ex(r.bought.price_ex)} ex и докрафт, всего ${fmt.ex(r.bought.total_ex)} ex, экономия ${fmt.ex(r.bought.saves_ex)} ex</div>` : ""}<div class="tiny faint">${esc(r.method)} · успех с базы ${r.success}%${r.rough ? " · ⚠ оценка грубая" : ""}</div></td>
        <td class="num">${fmt.ex(r.cost_ex)} ex</td><td class="num">${fmt.ex(r.sale_ex)} ex</td>
        <td class="num">${r.profit_ex != null ? `<b class="up">+${fmt.ex(r.profit_ex)} ex</b><div class="tiny">${r.safe ? "и при неудаче" : "только при средней удаче"}</div>` : `<span class="small">база ≤ ${fmt.ex(r.break_even_base_ex)} ex</span>`}</td>
        <td class="small">${fmt.n(r.count, "продавец|продавца|продавцов")}, свежих ${r.fresh}<div class="tiny faint">${fmt.ago(r.t)}</div></td>
        <td>${(r.mods || []).length ? `<button class="btn sm primary" data-mi="${i}">Посчитать</button>` : r.url ? `<a class="btn sm" href="${esc(r.url)}" target="_blank">Трейд ↗</a>` : ""}</td></tr>`).join("") + `</tbody></table>`;
    box.querySelectorAll("[data-mi]").forEach(b => b.onclick = () => { const r = d.rows[+b.dataset.mi]; calcProfit({base: r.base, ilvl: 82, mods: r.mods}); });
  }
  // pages: the catalog may hold thousands of recipes; the filters and the sort work over all of them, a page shows 30
  const REC_PAGE = 30;
  let recPage = 0;
  function pager(n) {
    const pages = Math.ceil(n / REC_PAGE);
    if (recPage >= pages) recPage = Math.max(0, pages - 1);
    if (pages <= 1) return n ? `<div class="tiny faint" style="margin:4px 0">рецептов: ${n}</div>` : "";
    return `<div class="row" style="gap:6px;margin:6px 0;align-items:center"><button class="btn sm" data-rpage="-1" ${recPage ? "" : "disabled"}>← назад</button>
      <span class="small">страница ${recPage + 1} из ${pages} · рецептов ${n}</span><button class="btn sm" data-rpage="1" ${recPage < pages - 1 ? "" : "disabled"}>вперёд →</button></div>`;
  }
  function renderRecipes() {
    const box = $("#cs-recipes"), st = recipesData.state, q = ($("#cs-rq").value || "").toLowerCase();
    // the cost, the sale and the chance come from the background scan (exalted); the filters read them in divine
    const exDiv = recipesData.ex_per_div || 0, div = ex => exDiv && ex != null ? ex / exDiv : null;
    const maxCost = +$("#cs-rmax").value || 0, minProfit = +$("#cs-rmin").value || 0, risk = $("#cs-rrisk").value, sort = $("#cs-rsort").value;
    const priced = $("#cs-rpriced").checked;
    const list = recipesData.recipes.filter(r => {
      const m = r.market;
      if (q && ![r.title, r.cls, r.base, ...(r.mods_ru || []), ...(r.mods || [])].join(" ").toLowerCase().includes(q)) return false;
      if ((priced || maxCost || minProfit || risk) && !m) return false;
      if (maxCost && !(div(m.cost_ex) <= maxCost)) return false;
      if (minProfit && !(div(m.profit_ex) >= minProfit)) return false;
      if (risk === "гарантия" && m.risk !== "гарантия") return false;
      if (risk === "safe" && m.risk === "риск") return false;
      return true;
    }).sort((a, b) => {
      const ma = a.market || {}, mb = b.market || {};
      if (sort === "new") return (b.new ? 1 : 0) - (a.new ? 1 : 0);
      if (sort === "cost") return (ma.cost_ex ?? 1e12) - (mb.cost_ex ?? 1e12);
      if (sort === "roi") return (mb.roi ?? -1e12) - (ma.roi ?? -1e12);
      return (mb.profit_ex ?? -1e12) - (ma.profit_ex ?? -1e12);
    });
    const money = ex => ex == null ? "—" : exDiv && Math.abs(ex) >= exDiv ? `${(ex / exDiv).toFixed(1)} div` : `${fmt.ex(ex)} ex`;
    const RISK = {"гарантия": ["node", "✅ гарантия"], "низкий риск": ["gem", "🟢 низкий риск"], "риск": ["warn", "🎲 риск"]};
    // a recipe the game's weights don't let anyone make: the reason and the market's price of the finished item, no cost
    const chance = v => v == null ? "—" : v >= 1 ? Math.round(v) + "%" : v > 0 ? v.toLocaleString("ru", {maximumFractionDigits: 2}) + "%" : "0%";
    const econ = r => r.market && r.market.impossible ? `<div class="kb warn" style="margin:6px 0"><span class="ki">⛔</span><div class="kt"><b class="kh">Тула не нашла, как это скрафтить</b>
        ${esc(r.market.impossible)}.${r.market.sale_ex ? ` Готовый такой предмет на рынке ≈ <b>${money(r.market.sale_ex)}</b> (${fmt.n(r.market.count || 0, "продавец|продавца|продавцов")}).` : ""}
        <span class="tiny faint">${fmt.ago(r.market.t)}</span></div></div>`
      : r.market ? `<div class="cs-econ"><span>Затраты <b>${money(r.market.cost_ex)}</b></span><span>Продажа <b>${money(r.market.sale_ex)}</b></span>
        <span>Прибыль ${r.market.profit_ex != null ? `<b class="${r.market.profit_ex > 0 ? "up" : "down"}">${r.market.profit_ex > 0 ? "+" : ""}${money(r.market.profit_ex)}</b>` : `<span class="small">окупится при базе ≤ ${money(r.market.break_even_base_ex)}</span>`}</span>
        <span>Шанс <b>${chance(r.market.success)}</b></span><span class="pill ${RISK[r.market.risk][0]}">${RISK[r.market.risk][1]}</span>
        ${r.market.relaxed ? `<span class="pill warn" title="все лучшие тиры сразу в симуляции не выпали ни разу — посчитана реальная цель; продажа — за те же моды">тиры на ${r.market.relaxed} ниже</span>` : ""}
        <span class="tiny faint">${esc(r.market.method || "")} · ${fmt.n(r.market.count || 0, "продавец|продавца|продавцов")} · ${fmt.ago(r.market.t)}</span>
        ${r.market.relaxed ? `<div class="tiny" style="flex-basis:100%;color:var(--amber)">посчитано: ${esc((r.market.targets || []).join(", "))}</div>` : ""}
        ${r.market.profit_ex > 0 ? `<span class="row" style="gap:4px">🏭 на конвейер × <input class="inp cs-batch" type="number" min="1" max="500" value="1" data-ri="${recipesData.recipes.indexOf(r)}" style="width:64px;padding:2px 6px"></span><span class="cs-batch-out tiny"></span>` : ""}</div>`
      : `<div class="tiny faint" style="margin-top:4px">💱 затраты и цену продажи тула считает в фоне${r.queued ? ` — в очереди №${r.queued}` : ""}; сразу — «Посчитать сейчас»</div>`;
    box.innerHTML = (st.running ? `<div class="kb info"><span class="ki"><span class="spin-s"></span></span><div class="kt"><b class="kh">Читаю гайды: ${st.done} из ${st.total || "?"}</b>${esc(st.step || "")}</div></div>` : "")
      + (st.error ? `<div class="kb warn"><span class="ki">⚠</span><div class="kt">${esc(st.error)}</div></div>` : "")
      + pager(list.length)
      + (list.length ? `<div class="cs-recs">${list.slice(recPage * REC_PAGE, (recPage + 1) * REC_PAGE).map((r, i) => `<div class="cs-rec">
          <div class="row" style="gap:6px"><b>${esc(r.title)}</b><span class="spacer"></span>${r.new ? '<span class="pill node" title="тула нашла этот рецепт за последние 3 дня">🆕 новый</span>' : ""}${r.recent_sources > 1 ? `<span class="pill warn" title="о нём пишут в разных источниках за 2 недели">🔥 ${fmt.n(r.recent_sources, "источник|источника|источников")}</span>` : ""}<span class="pill ${r.purpose === "sell" ? "money" : "info"}">${r.purpose === "sell" ? "на продажу" : "для себя"}</span>${r.patch ? `<span class="pill">${esc(r.patch)}</span>` : ""}</div>
          <div class="tiny faint">${esc(r.base)} · ilvl ${r.ilvl}${r.claimed_price_div ? ` · в гайде: продаётся ~${r.claimed_price_div} div` : ""}</div>
          <div class="row" style="gap:4px;flex-wrap:wrap;margin:5px 0">${(r.mods_ru || []).map(m => `<span class="pill gem">${esc(m)}</span>`).join("")}</div>
          ${econ(r)}
          ${(r.steps || []).length ? `<div class="small" style="line-height:1.5">${r.steps.slice(0, 5).map((x, j) => `${j + 1}. ${esc(x)}`).join("<br>")}</div>` : ""}
          ${r.note ? `<div class="tiny" style="color:#fde68a;margin-top:3px">⚠ ${esc(r.note)}</div>` : ""}
          ${(r.unknown || []).length ? `<div class="tiny" style="color:#fca5a5;margin-top:3px">⚠ Проверка тулой: в игре нет «${r.unknown.map(esc).join("», «")}» — гайд или его пересказ ошибается, сверь название</div>` : ""}
          <div class="row" style="gap:6px;margin-top:6px"><button class="btn sm primary" data-ri="${recipesData.recipes.indexOf(r)}">💰 Посчитать сейчас</button>
            ${r.url ? `<button class="btn sm ghost" data-rurl="${esc(r.url)}" title="${esc(r.source_title || r.url)}">источник ↗</button>` : ""}</div></div>`).join("")}</div>`
        : st.running ? "" : `<div class="faint small">${recipesData.recipes.length ? "Ничего не нашлось по фильтру." : "Рецептов пока нет — нажми «⟳ Обновить из гайдов»: тула загрузит гайды по крафту и выпишет из них схемы."}</div>`)
      + ((recipesData.hidden || []).length ? `<details class="tiny faint" style="margin-top:8px"><summary>Скрыто рецептов: ${recipesData.hidden.length} — в их шагах названия, которых нет в игре</summary>${recipesData.hidden.map(h => `<div>✖ ${esc(h.title || "рецепт")}: ${h.unknown.map(esc).join(", ")}</div>`).join("")}</details>` : "");
    box.querySelectorAll("button[data-ri]").forEach(b => b.onclick = () => { const r = recipesData.recipes[+b.dataset.ri]; calcProfit({base: r.base, ilvl: r.ilvl, mods: r.mods}); });
    // a batch: N crafts at once — the totals, and a warning when the market can't take that many at this price
    box.querySelectorAll(".cs-batch").forEach(inp => {
      const show = () => {
        const r = recipesData.recipes[+inp.dataset.ri], m = r.market, n = Math.max(1, Math.min(500, +inp.value || 1));
        const out = inp.closest(".cs-econ").querySelector(".cs-batch-out");
        const thin = (m.count || 0) < n * 2;
        out.innerHTML = `затраты <b>${money(m.cost_ex * n)}</b> · выручка <b>${money(m.sale_ex * n)}</b> · прибыль <b class="${m.profit_ex > 0 ? "up" : "down"}">${money(m.profit_ex * n)}</b>`
          + (thin ? ` · <span style="color:#fbbf24">на рынке ${fmt.n(m.count || 0, "продавец|продавца|продавцов")} — ${n} шт. сразу собьют цену, продавай частями</span>` : "");
      };
      inp.oninput = show;
      show();
    });
    box.querySelectorAll("[data-rurl]").forEach(b => b.onclick = () => window.open(b.dataset.rurl, "_blank"));
  }
  $("#cs-rq").oninput = () => { recPage = 0; recipesData && renderRecipes(); };
  ["#cs-rmax", "#cs-rmin", "#cs-rrisk", "#cs-rsort", "#cs-rpriced"].forEach(id => { const el = $(id); if (el) el.oninput = el.onchange = () => { recPage = 0; recipesData && renderRecipes(); }; });
  $("#cs-recipes").addEventListener("click", e => {
    const b = e.target.closest("[data-rpage]");
    if (!b) return;
    recPage += +b.dataset.rpage;
    renderRecipes();
    $("#cs-recipes").scrollIntoView({block: "start"});
  });
  $("#cs-rrefresh").onclick = async () => { try { await api.post("/api/craft/recipes/refresh"); toast("info", "Читаю гайды по крафту", "загружаю страницы и выписываю рецепты — пару минут"); loadRecipes(); } catch (e) { toast("err", "Рецепты", e.message); } };

  // idea scanner
  let scanTimer = null;
  $("#cr-scan").onclick = async () => {
    const base = basePick && basePick.value;
    if (!base) { toast("info", "Выбери базу", "тула переберёт сильные комбинации модов этой базы"); return; }
    try { await api.post("/api/craft/scan", {base, ilvl: +$("#cr-ilvl").value}); pollScan(); }
    catch (e) { toast("err", "Поиск идей", e.message); }
  };
  async function pollScan() {
    clearTimeout(scanTimer);
    let st;
    try { st = await api.get("/api/craft/scan"); } catch (_) { return; }
    const box = $("#cs-scan-box");
    if (!st.base) { box.innerHTML = `<div class="faint small">Выбери базу и нажми «🔎 Найти выгодные крафты» — тула переберёт сильные комбинации модов и оценит каждую по реальным ценам.</div>`; return; }
    box.innerHTML = `<div class="row" style="gap:8px;margin-bottom:6px"><b>${esc(st.base)} · ilvl ${st.ilvl}</b>${st.running ? `<span class="pill info"><span class="spin-s"></span> ${st.done} из ${st.total}</span>` : `<span class="pill node">готово</span>`}</div>
      ${st.error ? `<div class="kb warn"><span class="ki">⚠</span><div class="kt">${esc(st.error)}</div></div>` : ""}
      ${st.results.map((r, i) => `<div class="cs-wrow" data-i="${i}" style="cursor:pointer"><div style="min-width:0;flex:1"><b>${r.targets.map(esc).join(" + ")}</b>
        <div class="tiny faint">${esc(r.method || "")} · успех ${r.success ?? "—"}% с базы · продавцов ${r.count}</div></div>
        <span class="tiny faint">крафт ${r.cost_ex != null ? fmt.ex(r.cost_ex) + " ex" : "—"} → продажа ${r.sale_ex != null ? fmt.ex(r.sale_ex) + " ex" : "—"}</span>
        ${r.safe ? `<span class="pill node" title="в плюсе даже при плохом раскладе">надёжно</span>` : ""}
        <span class="pill ${r.profit_ex == null ? "info" : r.profit_ex > 0 ? "node" : "warn"}">${r.profit_ex == null ? (r.break_even_base_ex > 0 ? `окупится при базе ≤ ${fmt.ex(r.break_even_base_ex)} ex` : r.break_even_base_ex != null ? "не окупится" : "нет цены") : (r.profit_ex >= 0 ? "+" : "") + fmt.ex(r.profit_ex) + " ex"}</span></div>`).join("")}`;
    box.querySelectorAll("[data-i]").forEach(row => row.onclick = () => { const r = st.results[+row.dataset.i]; calcProfit({base: st.base, ilvl: st.ilvl, mods: r.mods}); });
    if (st.running) scanTimer = setTimeout(pollScan, 2500);
  }

  // what the simulator can't model yet — a new patch's currency included: the game's own description and the market's price
  async function loadUnmodeled() {
    let box = root.querySelector("#cr-unmod");
    if (!box) { box = document.createElement("details"); box.id = "cr-unmod"; box.className = "card"; box.style.marginTop = "16px"; root.appendChild(box); }
    let rows;
    try { rows = await api.get("/api/craft/unmodeled"); } catch (_) { box.hidden = true; return; }
    box.hidden = !rows.length;
    box.innerHTML = `<summary><b>Валюта и омены, которые симулятор пока не считает</b> <span class="muted small">(${rows.length})</span></summary>
      <div class="small muted" style="margin:6px 0">Есть в игре и на рынке, но шансы и шаги с ними тула не моделирует — ни одна цифра про них не выдумана.
        Что предмет делает — текст самой игры, цена — poe.ninja. Новая валюта патча появляется здесь сама.</div>
      <div class="tbl-scroll"><table class="tbl"><tbody>${rows.map(r => `<tr><td><b>${esc(r.name)}</b> <span class="tiny faint">${r.kind === "omen" ? "омен" : "валюта"}</span></td>
        <td class="small">${esc(r.description)}</td><td class="num small">${r.divine >= 1 ? `${(r.divine >= 10 ? Math.round(r.divine) : r.divine.toFixed(1)).toLocaleString("ru")} div` : r.exalted != null ? `${Math.round(r.exalted).toLocaleString("ru")} ex` : "—"}</td></tr>`).join("")}</tbody></table></div>`;
  }
  registerModule({id: "craft", onShow: () => { loadCatalog(); loadUnmodeled(); if (mode === "stash") loadStash(); }, target});
})();
