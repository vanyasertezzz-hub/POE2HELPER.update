(function () {
  "use strict";
  const {api, esc, fmt, md, stream, spinBtn, registerModule, toast} = window.P2;
  const root = document.getElementById("tree-root");
  root.innerHTML = `
    <div class="tr-grid">
      <div>
        <div class="row" style="margin-bottom:10px;gap:8px">
          <input class="inp" id="tr-search" placeholder="🔍 Поиск по древу: здоровье, скорость атаки, Ветер…" style="max-width:340px">
          <span class="pill info" id="tr-label">древо не загружено</span><span class="spacer"></span>
          <button class="btn sm ghost" id="tr-clear" hidden>Скрыть план</button></div>
        <div id="tr-need"></div>
        <div id="tr-view"></div>
      </div>
      <div class="tr-side">
        <div class="card"><div class="sec-h" style="--k:var(--k-info)"><span class="si">🌳</span><div><h3>Чьё древо</h3><div class="sd">по умолчанию — активный персонаж</div></div></div>
          <div id="tr-src"></div><button class="btn primary" id="tr-load" style="width:100%;margin-top:8px">Показать древо</button>
          <button class="btn" id="tr-refresh" style="width:100%;margin-top:6px" title="шмот с сайта PoE2, древо и камни из Path of Building">⟳ Обновить билд</button></div>
        <div class="card"><div class="sec-h" style="--k:var(--k-node)"><span class="si">✦</span><div><h3>План респека</h3>
            <div class="sd">тула посчитает в Path of Building каждую ноду и подсветит: <b style="color:#f87171">красным</b> — что снять, <b style="color:#4ade80">зелёным</b> — куда перекинуть очки</div></div></div>
          <div id="tr-goal"></div>
          <button class="btn primary" id="tr-plan" style="width:100%;margin-top:8px" disabled>✦ Построить план на древе</button>
          <div id="tr-planout" style="margin-top:10px"></div></div>
        <div class="card"><div class="sec-h" style="--k:var(--k-gem)"><span class="si">⚔</span><div><h3>Пассивки наборов оружия</h3>
            <div class="sd">у каждого набора свои очки: каждая нода замерена в PoB с этим набором в руках</div></div></div>
          <button class="btn" id="tr-sets" style="width:100%" disabled>Посчитать наборы (≈30 с)</button><div id="tr-setsout" style="margin-top:8px"></div></div>
        <div class="card"><div class="sec-h" style="--k:var(--k-boss)"><span class="si">♛</span><div><h3>Восхождение на твоём билде</h3>
            <div class="sd">узлы, которые на пустой заготовке не видны, замерены на твоём шмоте и настройках PoB</div></div></div>
          <button class="btn" id="tr-asc" style="width:100%" disabled>Посчитать восхождение (≈15 с)</button><div id="tr-ascout" style="margin-top:8px"></div></div>
        <div class="card"><div class="sec-h" style="--k:var(--k-reward)"><span class="si">Σ</span><div><h3>Сумма с древа</h3><div class="sd">все взятые бонусы, сложенные</div></div></div>
          <div id="tr-sum" class="small muted">Загрузи древо.</div></div>
        <div class="card"><div class="sec-h" style="--k:var(--k-act)"><span class="si">✎</span><div><h3>Разбор текстом</h3><div class="sd">подробно: что не так и почему</div></div>
          <span class="spacer"></span><span class="tiny faint" id="tr-who"></span></div>
          <button class="btn" id="tr-ai" style="width:100%" disabled>Разобрать древо</button><div class="md small" id="tr-out" style="margin-top:10px"></div></div>
      </div>
    </div>`;
  const $ = s => root.querySelector(s);
  let tv = null, src = null, loaded = null;

  async function ensureView() {
    if (tv) return tv;
    tv = new window.P2.TreeView($("#tr-view"), {height: "calc(100vh - 210px)", onNode: n => {}});
    await tv.load(); tv.fit();
    return tv;
  }
  const kindName = {notable: "значимая", keystone: "ключевая", normal: "малая"};

  async function load(silent) {
    let v = window.P2.sourceValue($("#tr-src")) || {};
    if (v.need) {  // the character has no build yet: pull it from the account first
      if (silent) { $("#tr-label").textContent = "у персонажа ещё нет билда"; return; }
      const btn = $("#tr-load"); spinBtn(btn, true, "Загружаю билд…");
      try { await window.P2.loadBuild(v.need); } catch (e) { spinBtn(btn, false); toast("err", "Древо", e.message); return; }
      spinBtn(btn, false); root.dataset.key = ""; $("#tr-need").innerHTML = ""; return mod.onShow();
    }
    src = v.code ? {pob: v.code} : v;
    const btn = $("#tr-load"); spinBtn(btn, true, "Гружу…");
    try {
      await ensureView();
      const r = await api.post("/api/tree/load", src);
      loaded = r;
      tv.setPlan(null); $("#tr-planout").innerHTML = ""; $("#tr-clear").hidden = true;
      tv.setAllocated(r.nodes.map(String), {cls: r.class, ascendancy: r.ascendancy});
      tv.setReach(r.analysis.reachable);
      tv.focusAllocated();
      $("#tr-label").textContent = `${r.label} · ${fmt.n(r.analysis.count, "очко|очка|очков")}`;
      $("#tr-sum").innerHTML = (r.analysis.totals.slice(0, 24).map(t => `<div class="tr-tot">${esc(t)}</div>`).join("") || "—")
        + ((r.analysis.totals_swap || []).length ? `<div class="tiny faint" style="margin-top:8px">Только со вторым набором оружия (переключение оружия):</div>`
          + r.analysis.totals_swap.slice(0, 12).map(t => `<div class="tr-tot faint">${esc(t)}</div>`).join("") : "");
      $("#tr-plan").disabled = $("#tr-ai").disabled = $("#tr-sets").disabled = $("#tr-asc").disabled = false;
    } catch (e) { if (!silent) toast("err", "Древо", e.message); else $("#tr-label").textContent = e.message; }
    spinBtn(btn, false);
  }
  $("#tr-load").onclick = () => load(false);
  $("#tr-refresh").onclick = e => window.P2.refreshBuild(e.currentTarget).then(() => { root.dataset.key = ""; return mod.onShow(); }).catch(() => {});
  $("#tr-search").oninput = e => tv && tv.setSearch(e.target.value);
  $("#tr-clear").onclick = () => { tv.setPlan(null); $("#tr-planout").innerHTML = ""; $("#tr-clear").hidden = true; };

  function planRow(x, kind) {
    return `<div class="kb ${kind === "add" ? "node" : "warn"} tr-step" data-id="${esc(x.id)}" style="cursor:pointer"><span class="ki">${kind === "add" ? "＋" : "−"}</span>
      <div class="kt"><b>${esc(x.ru || x.name)}</b> <span class="tiny faint">${esc(x.name !== x.ru ? x.name : "")}</span>
      <div class="small muted">${esc(x.why || "")}</div></div><span class="pill info">шаг ${x.step}</span></div>`;
  }
  // weapon-set passives: each set read as itself (its role: damage or speed), swaps only by measurement
  $("#tr-sets").onclick = async e => {
    const btn = e.currentTarget, out = $("#tr-setsout");
    spinBtn(btn, true, "Считаю наборы в PoB…");
    out.innerHTML = `<div class="skel"></div>`;
    const pc = v => `<b class="${v >= 0 ? "up" : "down"}">${v >= 0 ? "+" : ""}${String(v).replace(".", ",")}%</b>`;
    try {
      const r = await api.post("/api/tree/sets", src);
      out.innerHTML = r.sets.length ? r.sets.map(s => {
        const what = s.role === "speed" ? "скорость" : "урон";
        return `<div class="kb info" style="margin:6px 0"><span class="ki">${s.set}</span><div class="kt"><b class="kh">Набор ${s.set} — ${esc(s.role_ru)} · ${s.points} оч.</b>
          ${s.nodes.map(n => `<div class="small">${esc(n.ru)} — ${what} ${pc(n.main)}, живучесть ${pc(n.ehp)} · ${n.cost} оч.</div>`).join("")}
          ${s.unmeasured.length ? `<div class="tiny faint">PoB не считает на этом наборе (условие, заряды, эффект вне цифр — не значит бесполезно): ${s.unmeasured.map(esc).join(", ")}</div>` : ""}
          ${s.best_new.length ? `<div class="tiny muted" style="margin-top:4px">Рядом можно взять: ${s.best_new.slice(0, 3).map(c => `${esc(c.ru)} (${what} ${pc(c.main)}, живучесть ${pc(c.ehp)}, ${c.cost} оч.)`).join("; ")}</div>` : ""}
          ${s.swaps.map(w => `<div class="kb node" style="margin-top:6px"><span class="ki">⇄</span><div class="kt"><b class="kh">Снять ${esc(w.take_off_ru)} → взять ${esc(w.take_ru)}</b>
            на наборе ${s.set}: ${what} ${pc(w.main)}, живучесть ${pc(w.ehp)} · очков ${esc(w.points)} (замер всей замены)</div></div>`).join("")
            || `<div class="tiny faint" style="margin-top:4px">Замены, которая по замеру дала бы больше, нет — набор собран хорошо.</div>`}</div></div>`;
      }).join("") : `<div class="small muted">${esc(r.note || "Пассивок наборов нет.")}</div>`;
    } catch (err) { out.innerHTML = `<div class="small muted">${esc(err.message)}</div>`; }
    spinBtn(btn, false);
  };
  $("#tr-asc").onclick = async e => {
    const btn = e.currentTarget, out = $("#tr-ascout");
    spinBtn(btn, true, "Считаю восхождение в PoB…");
    out.innerHTML = `<div class="skel"></div>`;
    const pc = v => `<b class="${v >= 0 ? "up" : "down"}">${v >= 0 ? "+" : ""}${String(v).replace(".", ",")}%</b>`;
    try {
      const r = await api.post("/api/tree/asc", src);
      out.innerHTML = r.note ? `<div class="small muted">${esc(r.note)}</div>` : `<div class="small"><b>${esc(r.ascendancy)}</b> · очков в билде ${r.points} из 8</div>
        ${r.nodes.map(n => `<div class="small">${esc(n.ru)} — урон ${pc(n.main)}, живучесть ${pc(n.ehp)} · ${n.cost} оч.</div>`).join("")}
        ${r.unmeasured.length ? `<div class="tiny faint">PoB не считает и на твоём билде (условие, заряды, эффект вне цифр — не значит бесполезно): ${r.unmeasured.map(esc).join(", ")}</div>` : ""}
        ${r.adds.map(a => `<div class="kb node" style="margin-top:6px"><span class="ki">＋</span><div class="kt"><b class="kh">За свободные очки: ${esc(a.take_ru)}</b>
          урон ${pc(a.main)}, живучесть ${pc(a.ehp)} · ${a.points} оч. — если очки есть (пройдены все испытания восхождения)</div></div>`).join("")}
        ${r.swaps.map(w => `<div class="kb node" style="margin-top:6px"><span class="ki">⇄</span><div class="kt"><b class="kh">Снять ${esc(w.take_off_ru)} → взять ${esc(w.take_ru)}</b>
          урон ${pc(w.main)}, живучесть ${pc(w.ehp)} · очков ${esc(w.points)} (замер всей замены)</div></div>`).join("")}
        ${!r.adds.length && !r.swaps.length ? `<div class="tiny faint" style="margin-top:4px">Замены, которая по замеру дала бы больше, нет.${r.best_new.length ? ` Лучшие невзятые: ${r.best_new.slice(0, 3).map(c => `${esc(c.ru)} (урон ${pc(c.main)}, живучесть ${pc(c.ehp)}, ${c.cost} оч.)`).join("; ")}` : ""}</div>` : ""}`;
    } catch (err) { out.innerHTML = `<div class="small muted">${esc(err.message)}</div>`; }
    spinBtn(btn, false);
  };
  $("#tr-plan").onclick = async e => {
    const btn = e.currentTarget; spinBtn(btn, true, "Считаю в Path of Building…");
    $("#tr-planout").innerHTML = `<div class="skel"></div><div class="small muted" id="tr-prog">перебираю варианты в PoB…</div>`;
    const prog = setInterval(async () => { try { const p = await api.get("/api/tree/plan/progress");
      const el = root.querySelector("#tr-prog"); if (el && p.running) el.textContent = `${p.step}: ${p.done} из ${p.total} расчётов PoB`; } catch (_) {} }, 1500);
    try {
      const p = await api.post("/api/tree/plan", {...src, goal: window.P2.selectValue($("#tr-goal"), "goal")});
      tv.setPlan(p);
      const ns = [...p.remove, ...p.add].map(x => tv.L.byId[x.id]).filter(Boolean);
      if (ns.length) tv.fit(ns);
      $("#tr-clear").hidden = false;
      const mainRem = p.remove.filter(x => x.main), mainAdd = p.add.filter(x => x.main);
      const ck = p.check;
      $("#tr-planout").innerHTML = `${p.unmeasured ? `<div class="kb warn"><span class="ki">⚠</span><div class="kt"><b class="kh">План не измерен</b>Здесь только дерево без шмота и камней, посчитать нечего: это мнение модели, а не замер. Обнови билд персонажа, и план посчитается в PoB.</div></div>` : ""}${p.summary ? `<div class="kb info"><span class="ki">ℹ</span><div class="kt">${esc(p.summary)}</div></div>` : ""}
        ${ck ? `<div class="kb ${ck.ok ? "node" : "warn"}"><span class="ki">🧪</span><div class="kt"><b class="kh">Проверено в Path of Building${p.attempts > 1 ? " · перестроено после проверки" : ""}</b>
          DPS <b class="${ck.dps >= 0 ? "up" : "down"}">${ck.dps >= 0 ? "+" : ""}${ck.dps}%</b> · EHP <b class="${ck.ehp >= 0 ? "up" : "down"}">${ck.ehp >= 0 ? "+" : ""}${ck.ehp}%</b>
          ${ck.res_drop.length ? ` · ⚠ теряешь кап резистов: ${ck.res_drop.join(", ")}` : ""}${ck.ok ? "" : "<br>Лучшего варианта ИИ не нашёл — применяй осторожно."}</div></div>` : ""}
        <div class="row" style="gap:6px;margin:8px 0"><span class="pill warn">снять: ${p.freed} оч.</span><span class="pill node">взять: ${p.cost} оч.</span>
          <span class="pill ${p.cost - p.freed > 0 ? "money" : "info"}">${p.cost - p.freed > 0 ? `нужно ещё ${p.cost - p.freed} оч.` : `останется ${p.freed - p.cost} оч.`}</span></div>
        ${mainRem.map(x => planRow(x, "rem")).join("")}${mainAdd.map(x => planRow(x, "add")).join("")}
        ${(p.tips || []).map(t => `<div class="kb act"><span class="ki">✅</span><div class="kt">${esc(t)}</div></div>`).join("")}
        ${(p.best_free || []).length ? `<div class="bv-sgh" style="--k:var(--k-node);margin-top:10px">Лучшие ноды на свободные очки (PoB)</div>${p.best_free.map(b =>
          `<div class="kb node tr-step" data-id="${esc(b.id)}" style="cursor:pointer;margin:3px 0"><span class="ki">＋</span><div class="kt"><b>${esc(b.ru)}</b> · ${b.cost} оч.
            <span class="small">DPS <b class="${b.dps >= 0 ? "up" : "down"}">${b.dps >= 0 ? "+" : ""}${b.dps}%</b> · EHP <b class="${b.ehp >= 0 ? "up" : "down"}">${b.ehp >= 0 ? "+" : ""}${b.ehp}%</b></span></div></div>`).join("")}` : ""}
        ${!mainRem.length && !mainAdd.length ? `<div class="kb info"><span class="ki">ℹ</span><div class="kt">Менять в древе нечего — оно уже хорошо собрано под твой скилл.</div></div>` : ""}
        <div class="tiny faint" style="margin-top:6px">Клик по пункту — показать на древе. Наведи на ноду — причина.</div>`;
      $("#tr-planout").querySelectorAll(".tr-step").forEach(el => el.onclick = () => tv.focus(el.dataset.id));
    } catch (err) { $("#tr-planout").innerHTML = `<div class="kb warn"><span class="ki">⚠</span><div class="kt">${esc(err.message)}</div></div>`; }
    clearInterval(prog);
    spinBtn(btn, false);
  };

  $("#tr-ai").onclick = async () => {
    let acc = ""; const out = $("#tr-out"); out.innerHTML = `<div class="skel"></div><div class="skel"></div>`;
    await stream("/api/tree/analyze", {...src, goal: window.P2.selectValue($("#tr-goal"), "goal")}, {
      onTool: t => { if (!acc) out.innerHTML = `<div class="small muted">⏳ ${esc(t)}</div><div class="skel"></div><div class="skel"></div>`; },
      onProvider: p => $("#tr-who").textContent = p, onReplace: t => { acc = t; out.innerHTML = md(acc); }, onText: t => { acc += t; out.innerHTML = md(acc); },
      onError: e => out.innerHTML += `<div class="kb warn"><span class="ki">⚠</span><div class="kt">${esc(e)}</div></div>`});
  };

  // focus a node from other tabs (action cards «показать на древе»)
  window.P2.treeFocus = async name => {
    await ensureView();
    const n = tv.L.nodes.find(x => (x.name || "").toLowerCase() === String(name).toLowerCase() || (x.ru || "").toLowerCase() === String(name).toLowerCase());
    if (n) { tv.setSearch(n.name); tv.focus(n.id); $("#tr-search").value = n.ru || n.name; }
  };

  const mod = {id: "tree", onShow: async () => {
    await ensureView().catch(e => toast("err", "Древо", e.message));
    const c = await window.P2.choices();
    await window.P2.sourcePicker($("#tr-src"), {onChange: v => v && !v.code && load(false)});
    const act = (c.characters || []).find(ch => ch.id === c.active);
    if (act && !c.main_build) {
      // no build yet: load it from the account automatically and show the tree when it lands
      $("#tr-need").innerHTML = `<div style="margin-bottom:10px">${window.P2.autoBuildHtml(act.name)}</div>`;
      window.P2.autoBuild(act.id).then(() => { root.dataset.key = ""; $("#tr-need").innerHTML = ""; return mod.onShow(); })
        .catch(e => { $("#tr-need").innerHTML = `<div class="kb warn" style="margin-bottom:10px"><span class="ki">⚠</span><div class="kt"><b class="kh">Билд ${esc(act.name)} пока не загрузился</b>${esc(e.message)}</div></div>`; });
    } else $("#tr-need").innerHTML = "";
    if (!$("#tr-goal select")) {
      $("#tr-goal").innerHTML = window.P2.selectHtml("goal", c.goals.tree, {custom: true, empty: "— цель —", placeholder: "своя цель"});
      window.P2.wireSelects($("#tr-goal"));
    }
    const key = JSON.stringify([c.active, c.main_build]);
    if (loaded === null || root.dataset.key !== key) { root.dataset.key = key; if (c.main_build) load(true); }
    tv.draw();
  }};
  registerModule(mod);
})();
