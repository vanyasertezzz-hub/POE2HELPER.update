/* POE2 Helper — game-like passive tree renderer (canvas), shared by «Древо» and «Текущий билд».
   new P2.TreeView(container, {height, ascendancy, onNode})
     .load()                         layout from /api/tree/layout (cached for the session)
     .setAllocated(ids, {cls, ascendancy})
     .setPlan({remove: [{id, why}], add: [{id, why}], steps})   red = take off, green = put points here
     .setSearch(text) .fit() .focusAllocated() .focus(id)
   Node pictures come from the game art on the PoE2DB CDN; frames and arcs are drawn procedurally. */
(function () {
  "use strict";
  const P2 = window.P2;
  const esc = P2.esc;
  let LAYOUT = null, LAYOUT_P = null;
  const IMG = new Map();
  const R = {normal: 25, notable: 40, keystone: 56, jewel: 36, start: 90, ascstart: 34, mastery: 36};
  const KIND_RU = {normal: "малая", notable: "значимая", keystone: "ключевая", jewel: "гнездо самоцвета", start: "старт класса", ascstart: "старт восхождения", mastery: "мастерство"};

  async function getLayout() {
    if (LAYOUT) return LAYOUT;
    LAYOUT_P = LAYOUT_P || P2.api.get("/api/tree/layout").then(L => {
      L.byId = {};
      L.nodes.forEach(n => { L.byId[n.id] = n; n.r = n.attr ? 22 : R[n.k] || 25; });
      L.adj = {};
      L.edges.forEach(e => { (L.adj[e[0]] = L.adj[e[0]] || []).push(e[1]); (L.adj[e[1]] = L.adj[e[1]] || []).push(e[0]); });
      LAYOUT = L; return L;
    });
    return LAYOUT_P;
  }

  class TreeView {
    constructor(container, o = {}) {
      this.o = o;
      this.alloc = new Set(); this.add = new Map(); this.remove = new Map(); this.reach = new Map();
      this.search = ""; this.asc = o.ascendancy || null; this.view = {x: 0, y: 0, s: 0.05};
      container.innerHTML = `<div class="tv-wrap" style="height:${o.height || "calc(100vh - 230px)"}">
        <canvas class="tv-cv"></canvas><div class="tv-tip"></div>
        <div class="tv-legend"><span><i style="background:#f2c45a"></i>взято</span><span><i style="background:#4ade80"></i>взять</span>
          <span><i style="background:#f87171"></i>снять</span><span><i style="background:#67e8f9"></i>поиск</span></div>
        <div class="tv-zoom"><button data-z="in">+</button><button data-z="out">−</button><button data-z="fit" title="Показать взятое">⤢</button></div></div>`;
      this.wrap = container.querySelector(".tv-wrap");
      this.cv = container.querySelector(".tv-cv"); this.ctx = this.cv.getContext("2d");
      this.tip = container.querySelector(".tv-tip");
      this._wire();
      new ResizeObserver(() => this.draw()).observe(this.wrap);
    }
    async load() { this.L = await getLayout(); return this; }

    setAllocated(ids, meta = {}) {
      this.alloc = new Set((ids || []).map(String));
      if (meta.ascendancy !== undefined) this.asc = meta.ascendancy;
      this.cls = meta.cls || null;
      this.draw();
    }
    setReach(list) { this.reach = new Map((list || []).map(x => [String(x.id), x.cost])); this.draw(); }
    setPlan(plan) {
      this.add = new Map((plan && plan.add || []).map(x => [String(x.id), x]));
      this.remove = new Map((plan && plan.remove || []).map(x => [String(x.id), x]));
      this.draw();
    }
    setSearch(q) { this.search = (q || "").trim().toLowerCase(); this.draw(); }
    visible(n) { return !n.asc || n.asc === this.asc || this.alloc.has(n.id) || this.add.has(n.id); }

    fit(nodes) {
      if (!this.L) return;
      const list = (nodes && nodes.length ? nodes : this.L.nodes.filter(n => !n.asc));
      const xs = list.map(n => n.x), ys = list.map(n => n.y);
      const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
      const w = this.cv.clientWidth || 800, h = this.cv.clientHeight || 600;
      this.view.s = Math.min(0.35, Math.min(w / (x1 - x0 + 1600), h / (y1 - y0 + 1600)));
      this.view.x = (x0 + x1) / 2; this.view.y = (y0 + y1) / 2;
      this.draw();
    }
    focusAllocated() {
      const ns = this.L.nodes.filter(n => (this.alloc.has(n.id) || this.add.has(n.id)) && !n.asc);
      this.fit(ns.length ? ns : null);
    }
    focus(id) {
      const n = this.L && this.L.byId[String(id)];
      if (!n) return;
      this.view.x = n.x; this.view.y = n.y; this.view.s = Math.max(this.view.s, 0.22); this.flash = n.id; this.draw();
      setTimeout(() => { this.flash = null; this.draw(); }, 1600);
    }

    _img(url) {
      let im = IMG.get(url);
      if (!im) {
        im = new Image(); im.src = url; IMG.set(url, im);
        im.onload = () => this.draw();
      }
      return im.complete && im.naturalWidth ? im : null;
    }

    draw() {
      if (!this.L || this._raf) return;
      this._raf = requestAnimationFrame(() => { this._raf = null; this._draw(); });
    }
    _draw() {
      const cv = this.cv, ctx = this.ctx, L = this.L, dpr = window.devicePixelRatio || 1;
      const w = cv.clientWidth, h = cv.clientHeight;
      if (!w || !h) return;
      if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) { cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr); }
      const s = this.view.s * dpr, ox = cv.width / 2 - this.view.x * s, oy = cv.height / 2 - this.view.y * s;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      const bg = ctx.createRadialGradient(cv.width / 2, cv.height / 2, 0, cv.width / 2, cv.height / 2, Math.max(cv.width, cv.height) * 0.7);
      bg.addColorStop(0, "#14101f"); bg.addColorStop(1, "#07050c");
      ctx.fillStyle = bg; ctx.fillRect(0, 0, cv.width, cv.height);
      ctx.setTransform(s, 0, 0, s, ox, oy);
      const minX = -ox / s - 200, minY = -oy / s - 200, maxX = (cv.width - ox) / s + 200, maxY = (cv.height - oy) / s + 200;
      const inView = n => n.x > minX && n.x < maxX && n.y > minY && n.y < maxY;
      const by = L.byId, alloc = this.alloc, add = this.add, rem = this.remove;
      const px = 1 / s;  // one screen pixel in tree units

      // ── connections: stone base, then gold/green/red overlays ──
      const state = (a, b) => {
        if (rem.has(a) || rem.has(b)) return alloc.has(a) && alloc.has(b) ? "rem" : "base";
        if ((add.has(a) || alloc.has(a)) && (add.has(b) || alloc.has(b)) && (add.has(a) || add.has(b))) return "add";
        if (alloc.has(a) && alloc.has(b)) return "on";
        return "base";
      };
      const paths = {base: new Path2D(), on: new Path2D(), add: new Path2D(), rem: new Path2D()};
      for (const e of L.edges) {
        const A = by[e[0]], B = by[e[1]];
        if (!this.visible(A) || !this.visible(B)) continue;
        if (!inView(A) && !inView(B)) continue;
        const p = paths[state(e[0], e[1])];
        if (e.length === 5) {
          const [, , cx, cy, r] = e;
          let a1 = Math.atan2(A.y - cy, A.x - cx), a2 = Math.atan2(B.y - cy, B.x - cx);
          let d = a2 - a1; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI;
          p.moveTo(A.x, A.y); p.arc(cx, cy, r, a1, a1 + d, d < 0);
        } else { p.moveTo(A.x, A.y); p.lineTo(B.x, B.y); }
      }
      ctx.lineCap = "round";
      ctx.strokeStyle = "#2a241d"; ctx.lineWidth = Math.max(13, 2.2 * px); ctx.stroke(paths.base);
      ctx.strokeStyle = "#3d3428"; ctx.lineWidth = Math.max(6, 1.2 * px); ctx.stroke(paths.base);
      const glow = (p, c, core) => {
        ctx.save(); ctx.shadowColor = c; ctx.shadowBlur = 14 * dpr;
        ctx.strokeStyle = c; ctx.lineWidth = Math.max(15, 2.6 * px); ctx.globalAlpha = 0.55; ctx.stroke(p);
        ctx.globalAlpha = 1; ctx.shadowBlur = 0; ctx.strokeStyle = core; ctx.lineWidth = Math.max(6, 1.2 * px); ctx.stroke(p); ctx.restore();
      };
      glow(paths.on, "#c9973a", "#ffe29a");
      glow(paths.add, "#22c55e", "#bbf7d0");
      ctx.save(); ctx.setLineDash([22, 16]); glow(paths.rem, "#dc2626", "#fecaca"); ctx.restore();

      // ── nodes ──
      const q = this.search, showIcons = s > 0.075, showLabels = s > 0.16;
      const labels = [];
      for (const n of L.nodes) {
        if (!this.visible(n) || !inView(n)) continue;
        const on = alloc.has(n.id), isAdd = add.has(n.id), isRem = rem.has(n.id);
        const hit = q && ((n.ru || "").toLowerCase().includes(q) || (n.name || "").toLowerCase().includes(q)
          || (n.stats_ru || n.stats).some(t => t.toLowerCase().includes(q)) || n.stats.some(t => t.toLowerCase().includes(q)));
        const r = n.r, sr = r * s;
        if (sr < 1.2 && !on && !isAdd && !isRem && !hit) continue;
        const ring = isRem ? "#f87171" : isAdd ? "#4ade80" : on ? "#f2c45a" : hit ? "#67e8f9" : n.k === "keystone" ? "#8a7550" : n.k === "notable" ? "#7a6748" : "#5b4f3c";
        if (on || isAdd || isRem || hit || this.flash === n.id) {
          ctx.save(); ctx.shadowColor = ring; ctx.shadowBlur = (n.k === "normal" ? 10 : 18) * dpr * (this.flash === n.id ? 3 : 1);
          ctx.beginPath(); ctx.arc(n.x, n.y, r * 1.02, 0, 7); ctx.fillStyle = ring; ctx.globalAlpha = 0.35; ctx.fill(); ctx.restore();
        }
        // inner: icon (game art) or a coloured disc when zoomed out
        const im = showIcons && n.icon && sr > 6 ? this._img(n.icon) : null;
        ctx.save(); ctx.beginPath(); ctx.arc(n.x, n.y, r * 0.86, 0, 7); ctx.closePath();
        ctx.fillStyle = n.k === "start" ? "#3b2a12" : "#120e18"; ctx.fill();
        if (im) { ctx.clip(); ctx.drawImage(im, n.x - r * 0.86, n.y - r * 0.86, r * 1.72, r * 1.72);
          if (!on && !isAdd && !hit) { ctx.fillStyle = "rgba(6,4,10,.58)"; ctx.fill(); } }
        else if (!showIcons || !n.icon) { ctx.fillStyle = on ? "#d9a441" : isAdd ? "#22c55e" : isRem ? "#dc2626" : hit ? "#0891b2" : n.k === "keystone" ? "#6d5a8f" : n.k === "notable" ? "#5a4a33" : "#3b3328"; ctx.fill(); }
        ctx.restore();
        // frame: small = thin ring, notable = double gold ring, keystone = heavy ornate ring
        ctx.strokeStyle = ring;
        ctx.lineWidth = Math.max(n.k === "normal" ? 3 : 5, (n.k === "keystone" ? 2.4 : n.k === "notable" ? 1.8 : 1.1) * px);
        ctx.beginPath(); ctx.arc(n.x, n.y, r, 0, 7); ctx.stroke();
        if (n.k === "notable" || n.k === "keystone" || n.k === "start") {
          ctx.lineWidth = Math.max(2, 0.8 * px); ctx.globalAlpha = 0.8;
          ctx.beginPath(); ctx.arc(n.x, n.y, r * (n.k === "keystone" ? 1.2 : 1.14), 0, 7); ctx.stroke(); ctx.globalAlpha = 1;
        }
        if (isRem && sr > 5) { ctx.strokeStyle = "#fee2e2"; ctx.lineWidth = Math.max(4, px); ctx.beginPath();
          ctx.moveTo(n.x - r * 0.45, n.y - r * 0.45); ctx.lineTo(n.x + r * 0.45, n.y + r * 0.45);
          ctx.moveTo(n.x + r * 0.45, n.y - r * 0.45); ctx.lineTo(n.x - r * 0.45, n.y + r * 0.45); ctx.stroke(); }
        if ((showLabels && (n.k === "notable" || n.k === "keystone")) || (n.k === "start" && n.cls && s > 0.03) || ((isAdd || isRem) && sr > 7 && n.k !== "normal"))
          labels.push(n);
      }
      // labels in screen space so the text stays crisp
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.textAlign = "center"; ctx.textBaseline = "top";
      for (const n of labels) {
        const x = n.x * s + ox, y = (n.y + n.r * 1.25) * s + oy;
        const t = n.k === "start" ? (n.cls_ru || n.cls || []).join(" / ") : (n.ru || n.name);
        ctx.font = `${(n.k === "keystone" ? 12.5 : 11) * dpr}px Inter, sans-serif`;
        ctx.lineWidth = 3 * dpr; ctx.strokeStyle = "rgba(5,3,9,.9)"; ctx.strokeText(t, x, y);
        ctx.fillStyle = this.remove.has(n.id) ? "#fecaca" : this.add.has(n.id) ? "#bbf7d0" : this.alloc.has(n.id) ? "#ffe9b3" : "#c9bfae";
        ctx.fillText(t, x, y);
      }
    }

    _world(e) {
      const rect = this.cv.getBoundingClientRect();
      const mx = e.clientX - rect.left - rect.width / 2, my = e.clientY - rect.top - rect.height / 2;
      return {mx, my, wx: this.view.x + mx / this.view.s, wy: this.view.y + my / this.view.s, rect};
    }
    _pick(e) {
      const {wx, wy} = this._world(e);
      let best = null, bd = 1e18;
      for (const n of this.L.nodes) {
        if (!this.visible(n)) continue;
        const d = (n.x - wx) ** 2 + (n.y - wy) ** 2;
        if (d < bd) { bd = d; best = n; }
      }
      return best && Math.sqrt(bd) < Math.max(best.r * 1.3, 10 / this.view.s) ? best : null;
    }
    _wire() {
      const cv = this.cv;
      let drag = null, moved = false;
      cv.addEventListener("mousedown", e => { drag = {x: e.clientX, y: e.clientY, vx: this.view.x, vy: this.view.y}; moved = false; cv.style.cursor = "grabbing"; });
      window.addEventListener("mouseup", e => {
        if (drag && !moved && e.target === cv) { const n = this._pick(e); if (n && this.o.onNode) this.o.onNode(n, this); }
        drag = null; cv.style.cursor = "grab";
      });
      cv.addEventListener("mousemove", e => {
        if (drag) {
          if (Math.abs(e.clientX - drag.x) + Math.abs(e.clientY - drag.y) > 3) moved = true;
          this.view.x = drag.vx - (e.clientX - drag.x) / this.view.s; this.view.y = drag.vy - (e.clientY - drag.y) / this.view.s;
          this.tip.style.display = "none"; this.draw(); return;
        }
        this._hover(e);
      });
      cv.addEventListener("mouseleave", () => { this.tip.style.display = "none"; });
      cv.addEventListener("wheel", e => {
        e.preventDefault();
        const {mx, my, wx, wy} = this._world(e);
        this.view.s = Math.max(0.01, Math.min(0.8, this.view.s * (e.deltaY < 0 ? 1.2 : 1 / 1.2)));
        this.view.x = wx - mx / this.view.s; this.view.y = wy - my / this.view.s; this.draw();
      }, {passive: false});
      this.wrap.querySelectorAll("[data-z]").forEach(b => b.onclick = () => {
        if (b.dataset.z === "fit") return this.alloc.size ? this.focusAllocated() : this.fit();
        this.view.s = Math.max(0.01, Math.min(0.8, this.view.s * (b.dataset.z === "in" ? 1.35 : 1 / 1.35))); this.draw();
      });
    }
    _hover(e) {
      const n = this._pick(e), tip = this.tip;
      if (!n) { tip.style.display = "none"; return; }
      const on = this.alloc.has(n.id), a = this.add.get(n.id), r = this.remove.get(n.id), rc = this.reach.get(n.id);
      const stats = (n.stats_ru && n.stats_ru.length ? n.stats_ru : n.stats);
      tip.innerHTML = `<div class="row" style="gap:10px;align-items:center">${n.icon ? `<img src="${esc(n.icon)}" width="38" height="38" style="border-radius:50%;border:2px solid ${on ? "#f2c45a" : "#5b4f3c"}">` : ""}
          <div><b class="tv-name k-${n.k}">${esc(n.ru || n.name || "Нода")}</b>${n.ru && n.ru !== n.name ? `<div class="tiny faint">${esc(n.name)}</div>` : ""}
          <div class="row" style="gap:4px;margin-top:3px"><span class="pill info">${esc(KIND_RU[n.k] || n.k)}${n.attr ? " · атрибут" : ""}</span>${n.asc ? `<span class="pill reward">${esc(P2.l10nClass ? P2.l10nClass(n.asc) : n.asc)}</span>` : ""}
          ${on ? `<span class="pill reward">взята</span>` : ""}${rc ? `<span class="pill node">${rc} оч. пути</span>` : ""}</div></div></div>
        <div class="tv-stats">${stats.map(t => `<div>${esc(t)}</div>`).join("") || `<div class="faint">без статов</div>`}</div>
        ${a ? `<div class="kb node" style="margin:8px 0 0"><span class="ki">＋</span><div class="kt"><b class="kh">Взять${a.step ? " · шаг " + a.step : ""}</b>${esc(a.why || "по плану ассистента")}</div></div>` : ""}
        ${r ? `<div class="kb warn" style="margin:8px 0 0"><span class="ki">−</span><div class="kt"><b class="kh">Снять${r.step ? " · шаг " + r.step : ""}</b>${esc(r.why || "по плану ассистента")}</div></div>` : ""}`;
      const {mx, my, rect} = this._world(e);
      tip.style.display = "block";
      const tw = tip.offsetWidth, th = tip.offsetHeight;
      let x = mx + rect.width / 2 + 18, y = my + rect.height / 2 + 18;
      if (x + tw > rect.width - 6) x = mx + rect.width / 2 - tw - 18;
      if (y + th > rect.height - 6) y = Math.max(6, my + rect.height / 2 - th - 18);
      tip.style.left = x + "px"; tip.style.top = y + "px";
    }
  }
  P2.TreeView = TreeView;
  P2.treeLayout = getLayout;
})();
