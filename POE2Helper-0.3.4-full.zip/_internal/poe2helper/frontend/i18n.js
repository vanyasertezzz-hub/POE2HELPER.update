/* Interface strings for RU / UK / EN. Assistant answers follow the same language (server side, prefs.language).
   Shell, menu, settings and common controls are translated; module bodies fall back to Russian. */
window.P2_I18N = {
  ru: {},
  uk: {
    "dash": "Огляд", "meta": "Мета і патчі", "assistant": "Асистент", "price": "Прайс-чек", "leveling": "Путівник по актах",
    "build": "Білд", "tree": "Дерево талантів", "craft": "Крафт", "farm": "Ендгейм і фарм", "character": "Персонаж",
    "kb": "База знань", "settings": "Налаштування",
    "Поиск": "Пошук", "лига": "ліга", "Персонаж не найден": "Персонажа не знайдено", "Client.txt не подключён": "Client.txt не підключено",
    "AI-ассистент экзайла": "AI-асистент екзайла", "Свернуть меню": "Згорнути меню",
    "Общие": "Загальні", "Игра и аккаунт": "Гра та акаунт", "Прайс-чек": "Прайс-чек", "Оверлей и хоткеи": "Оверлей і хоткеї",
    "ИИ и API": "ШІ та API", "База знаний": "База знань", "Данные": "Дані", "Сохранить": "Зберегти", "Сбросить": "Скинути",
    "Язык": "Мова", "Акцент темы": "Акцент теми", "Масштаб интерфейса": "Масштаб інтерфейсу", "Компактный режим": "Компактний режим",
    "Стартовая страница": "Стартова сторінка", "Уведомления": "Сповіщення", "Звук": "Звук",
    "Сохранено": "Збережено", "Остаток квоты": "Залишок квоти", "Проверить все": "Перевірити всі",
  },
  en: {
    "dash": "Overview", "meta": "Meta & patches", "assistant": "Assistant", "price": "Price check", "leveling": "Act guide",
    "build": "Build", "tree": "Passive tree", "craft": "Crafting", "farm": "Endgame & farming", "character": "Character",
    "kb": "Knowledge base", "settings": "Settings",
    "Поиск": "Search", "лига": "league", "Персонаж не найден": "No character found", "Client.txt не подключён": "Client.txt not connected",
    "AI-ассистент экзайла": "AI assistant for exiles", "Свернуть меню": "Collapse menu",
    "Общие": "General", "Игра и аккаунт": "Game & account", "Прайс-чек": "Price check", "Оверлей и хоткеи": "Overlay & hotkeys",
    "ИИ и API": "AI & API", "База знаний": "Knowledge base", "Данные": "Data", "Сохранить": "Save", "Сбросить": "Reset",
    "Язык": "Language", "Акцент темы": "Theme accent", "Масштаб интерфейса": "Interface scale", "Компактный режим": "Compact mode",
    "Стартовая страница": "Start page", "Уведомления": "Notifications", "Звук": "Sound",
    "Сохранено": "Saved", "Остаток квоты": "Quota left", "Проверить все": "Check all",
  },
};
