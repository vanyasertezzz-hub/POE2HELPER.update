/* The whole interface in the chosen language: every Russian text on the page is looked up by its shape, numbers aside.
   Strings are built in hundreds of places, here and on the server, so this works on what the page shows. See poe2helper/i18n.py. */
(function () {
  "use strict";
  const RU = /[а-яё]/i, NUM = /\d+(?:[.,]\d+)?/g;
  const SKIP = new Set(["SCRIPT", "STYLE", "TEXTAREA", "CODE", "KBD"]);
  const ATTRS = ["title", "placeholder", "aria-label"];
  const lane = u => /^(127\.0\.0\.1|localhost)$/.test(location.hostname) ? `http://l1.localhost:${location.port}${u}` : u;
  let lang = null, dict = {}, timer = null, retry = null;
  const queue = new Set();
  const keyOf = s => s.trim().replace(NUM, "#");
  const put = (tr, s) => { const nums = s.match(NUM) || []; let i = 0; return tr.replace(/#/g, () => nums[i++] ?? "#"); };

  function say(text) {
    const tr = dict[keyOf(text)];
    if (tr == null) return null;
    return text.match(/^\s*/)[0] + put(tr, text.trim()) + text.match(/\s*$/)[0];
  }

  function ask(text) {
    queue.add(keyOf(text));
    if (!timer) timer = setTimeout(flush, 150);
  }

  function fixNode(node) {
    const v = node.nodeValue;
    if (!v || !RU.test(v)) return;
    const p = node.parentElement;
    // the assistant's answers keep their Russian in the English layout, the player's choice: only the game's names in them are English, and those the model writes itself
    if (!p || SKIP.has(p.tagName) || p.closest("[contenteditable], .md")) return;
    const out = say(v);
    if (out != null) { if (out !== v) node.nodeValue = out; return; }
    ask(v);
  }

  function fixAttrs(el) {
    for (const a of ATTRS) {
      const v = el.getAttribute && el.getAttribute(a);
      if (!v || !RU.test(v)) continue;
      const out = say(v);
      if (out != null) { if (out !== v) el.setAttribute(a, out); } else ask(v);
    }
  }

  function walk(root) {
    if (root.nodeType === 3) return fixNode(root);
    if (root.nodeType !== 1) return;
    fixAttrs(root);
    root.querySelectorAll("[title],[placeholder],[aria-label]").forEach(fixAttrs);
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    for (let n = w.nextNode(); n; n = w.nextNode()) fixNode(n);
  }

  async function flush() {
    timer = null;
    const texts = [...queue].slice(0, 300);
    if (!texts.length) return;
    texts.forEach(t => queue.delete(t));
    try {
      const r = await fetch(lane("/api/settings/i18n/translate"), {method: "POST", headers: {"Content-Type": "application/json", "X-P2": "1"}, body: JSON.stringify({lang, texts})}).then(x => x.json());
      Object.assign(dict, r.known || {});
      walk(document.body);
      if (r.pending && !retry) retry = setTimeout(() => { retry = null; walk(document.body); }, 2500);
    } catch { retry = retry || setTimeout(() => { retry = null; walk(document.body); }, 5000); }
    if (queue.size && !timer) timer = setTimeout(flush, 150);
  }

  const observer = new MutationObserver(list => {
    for (const m of list) {
      if (m.type === "characterData") fixNode(m.target);
      else if (m.type === "attributes") fixAttrs(m.target);
      else m.addedNodes.forEach(walk);
    }
  });

  window.P2_setLanguage = async function (next) {
    if (next === lang) return;
    const was = lang;
    lang = next;
    observer.disconnect();
    if (next === "ru") { if (was) location.reload(); return; }  // the originals are gone from the page: redraw it
    dict = await fetch(`/api/settings/i18n?lang=${encodeURIComponent(next)}`).then(r => r.json()).catch(() => ({}));
    walk(document.body);
    if (RU.test(document.title)) { const out = say(document.title); if (out) document.title = out; }
    observer.observe(document.body, {subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ATTRS});
  };
  // the small windows have no shell around them: they ask for the language themselves
  if (document.body.dataset.ownLanguage != null) fetch("/api/settings/prefs").then(r => r.json()).then(({values}) => window.P2_setLanguage(values.language || "ru")).catch(() => {});
})();
