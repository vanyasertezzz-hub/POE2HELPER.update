(function () {
  "use strict";
  const {esc, registerModule, helpHtml, go} = window.P2;
  const root = document.getElementById("help-root");
  const ORDER = ["start", "characters", "hotkeys", "character", "settings", "audit", "price", "trades", "history", "leveling", "build", "pob", "tree", "craft", "farm", "meta", "assistant", "kb", "dash"];
  const H = window.P2_HELP || {};
  root.innerHTML = `<div class="split" style="grid-template-columns:240px minmax(0,1fr)">
    <div class="card" style="padding:8px;position:sticky;top:0"><div class="nav">${ORDER.filter(k => H[k]).map(k =>
      `<button data-k="${k}"><span class="lbl">${esc(H[k].title)}</span></button>`).join("")}</div></div>
    <div class="grid">${ORDER.filter(k => H[k]).map(k => `<div class="card ${k === "start" ? "glow" : ""}" id="help-${k}">${helpHtml(k)}
      ${!["start", "hotkeys"].includes(k) ? `<div class="row end" style="margin-top:10px"><button class="btn sm" data-open="${k}">Открыть раздел →</button></div>` : ""}</div>`).join("")}</div></div>`;
  root.querySelectorAll("[data-k]").forEach(b => b.onclick = () => document.getElementById(`help-${b.dataset.k}`).scrollIntoView({behavior: "smooth", block: "start"}));
  root.querySelectorAll("[data-open]").forEach(b => b.onclick = () => go(b.dataset.open));
  registerModule({id: "help"});
})();
