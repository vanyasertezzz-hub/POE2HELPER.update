(function () {
  "use strict";
  const {api, esc, fmt, md, spinBtn, registerModule, toast} = window.P2;
  const root = document.getElementById("kb-root");
  const KINDS = {game: "Данные игры (PoB)", video: "Видео YouTube", wiki: "Вики", unique: "Уники", craft: "Крафт", passive: "Пассивки", gem: "Гемы", price: "Цены", endgame: "Эндгейм",
    patch: "Патч-ноуты", community: "Reddit", news: "Новости", digest: "Дайджесты (Ollama)", guide: "Гайды", build: "Билды/PoB",
    learned: "Выучено из опыта", wiki: "Вики PoE2 (все статьи)", db: "PoE2DB"};
  root.innerHTML = `
    <div class="grid g3">
      <div class="card glow" style="grid-column:span 2"><div class="row"><h3 style="margin:0">Источники</h3><span class="spacer"></span><span class="small muted" id="kb-total"></span>
        <button class="btn sm" id="kb-prices">Обновить цены</button><button class="btn sm primary" id="kb-all">Пересобрать всё</button></div>
        <div id="kb-src" style="margin-top:12px"></div><div class="tiny faint" id="kb-log" style="margin-top:8px"></div></div>
      <div class="card"><h3>Добавить знания</h3>
        <div class="seg" id="kb-type" style="margin-bottom:10px"><button class="on" data-t="url">Ссылка</button><button data-t="text">Текст</button><button data-t="pob">PoB</button></div>
        <div class="field"><input class="inp" id="kb-title" placeholder="Название (для текста/PoB)"></div>
        <div class="field"><textarea class="inp" id="kb-val" rows="5" placeholder="Текст гайда, заметки, PoB-код…"></textarea></div>
        <button class="btn primary" id="kb-add" style="width:100%">Добавить в базу</button>
        <div class="tiny faint" style="margin-top:8px">Ассистенты автоматически находят и цитируют добавленное.</div></div>
    </div>
    <div class="card glow" style="margin-top:16px"><div class="row"><h3 style="margin:0">📚 Вся база PoE2</h3><span class="spacer"></span>
        <button class="btn primary sm" id="kb-mega">Загрузить всё сейчас</button></div>
      <div class="small muted" style="margin:6px 0">Все статьи вики poe2wiki.net (~6 000: механики, боссы, зоны, предметы, лиги, валюта), данные игры из PoB, все патч-ноуты и видео-гайды — локально, для всех ИИ тулы.
        Тула делает это сама в фоне и раз в 2 недели обновляет устаревшее; вежливо, один запрос раз в 2 секунды.</div>
      <div id="kb-mega-st"></div></div>
    <div class="card" style="margin-top:16px"><div class="kb info"><span class="ki">ℹ</span><div class="kt"><b class="kh">Гайды с сайтов</b>
      Maxroll запрещает программам собирать свои страницы (их правила), Mobalytics не отдаёт страницы программам —
      тула их не качает. Понравился гайд: нажми на сайте «Copy PoB» и вставь код на вкладке Path of Building, или вставь текст гайда в «Добавить знания» → Текст.
      Видео-гайды, вики и патч-ноуты тула собирает сама.</div></div></div>
    <div class="card" style="margin-top:16px"><div class="row"><h3 style="margin:0">Проверить поиск</h3><input class="inp" id="kb-q" placeholder="omen exalted prefix / Ancestral Bond / ring life" style="flex:1"><button class="btn" id="kb-go">Найти</button></div>
      <div id="kb-res" style="margin-top:12px"></div></div>`;
  const $ = s => root.querySelector(s);
  let type = "url";
  root.querySelectorAll("#kb-type button").forEach(b => b.onclick = () => { type = b.dataset.t; root.querySelectorAll("#kb-type button").forEach(x => x.classList.toggle("on", x === b)); });

  let by = {};
  const openKinds = new Set(), filters = {}, SHOW = 100;
  function drawKind(k) {
    const q = (filters[k] || "").toLowerCase();
    const arr = (by[k] || []).filter(x => !q || (x.note || x.source).toLowerCase().includes(q));
    const box = root.querySelector(`[data-list="${CSS.escape(k)}"]`);
    if (!box) return;
    box.innerHTML = `<table class="tbl"><tbody>${arr.slice(0, SHOW).map(x => `<tr><td>${esc(x.note || x.source)}</td><td class="num">${x.count}</td>
      <td class="faint small">${fmt.ago(x.updated)}</td><td><button class="btn sm ghost danger" data-del="${esc(x.source)}" title="Убрать из базы">✕</button></td></tr>`).join("")}</tbody></table>`
      + (arr.length > SHOW ? `<div class="tiny faint">показано ${SHOW} из ${arr.length.toLocaleString("ru")} — уточни фильтр</div>` : "");
    box.querySelectorAll("[data-del]").forEach(b => b.onclick = async () => { await api.del(`/api/kb/source?source=${encodeURIComponent(b.dataset.del)}`); load(); });
  }

  async function load() {
    const s = await api.get("/api/kb/stats");
    $("#kb-total").textContent = fmt.n(s.total, "документ|документа|документов");
    by = {};
    s.sources.forEach(x => (by[x.kind] = by[x.kind] || []).push(x));
    if (document.activeElement?.matches?.("#kb-src [data-filter]")) { openKinds.forEach(drawKind); return finish(s); }  // don't steal the cursor
    // one line per kind (the wiki alone is ~6 000 pages): open a kind to see and filter its sources
    $("#kb-src").innerHTML = Object.entries(by).map(([k, arr]) => `<details data-kind="${esc(k)}" ${openKinds.has(k) ? "open" : ""} style="border-bottom:1px solid var(--line);padding:6px 0">
      <summary class="row" style="cursor:pointer"><span class="tag">${esc(KINDS[k] || k)}</span><span>${arr.length.toLocaleString("ru")} источн.</span>
        <span class="faint small">${arr.reduce((a, x) => a + (x.count || 0), 0).toLocaleString("ru")} фрагментов · обновлено ${fmt.ago(Math.max(...arr.map(x => x.updated || 0)))}</span></summary>
      ${arr.length > 8 ? `<input class="inp" data-filter="${esc(k)}" placeholder="фильтр по названию" style="margin:6px 0;width:260px" value="${esc(filters[k] || "")}">` : ""}
      <div data-list="${esc(k)}"></div></details>`).join("");
    root.querySelectorAll("#kb-src details").forEach(d => {
      d.ontoggle = () => { d.open ? openKinds.add(d.dataset.kind) : openKinds.delete(d.dataset.kind); if (d.open) drawKind(d.dataset.kind); };
      if (d.open) drawKind(d.dataset.kind);
    });
    root.querySelectorAll("[data-filter]").forEach(i => i.oninput = () => { filters[i.dataset.filter] = i.value; drawKind(i.dataset.filter); });
    finish(s);
  }
  function finish(s) {
    $("#kb-log").textContent = s.status.running ? `⟳ ${s.status.step}` : (s.status.log.slice(-1)[0] || "");
    if (s.status.running) setTimeout(load, 3000);
  }
  let megaTimer = null;
  async function mega() {
    clearTimeout(megaTimer);
    let s; try { s = await api.get("/api/kb/mega"); } catch (_) { return; }
    $("#kb-mega-st").innerHTML = s.running
      ? `<div class="kb info"><span class="ki"><span class="spin-s"></span></span><div class="kt"><b class="kh">Загружаю: ${s.done} из ${s.total || "?"} статей · добавлено ${s.pages}</b>${esc(s.step || "")}</div></div>`
      : s.started ? `<div class="small">Последний проход: добавлено/обновлено ${fmt.n(s.pages, "страница|страницы|страниц")}${s.errors ? `, ошибок ${s.errors}` : ""} · ${esc(s.step || "")}</div>` : "";
    const v = s.vectors || {};
    $("#kb-mega-st").innerHTML += v.running ? `<div class="small" style="margin-top:4px"><span class="spin-s"></span> Поиск по смыслу: ${v.done} из ${v.total} фрагментов</div>`
      : `<div class="small muted" style="margin-top:4px">Поиск по смыслу (русский вопрос → английские статьи): ${v.vectors ? v.vectors + " фрагментов" : "ещё не построен"}</div>`;
    if (s.running || v.running) megaTimer = setTimeout(() => { mega(); load(); }, 5000);
  }
  $("#kb-mega").onclick = async () => { await api.post("/api/kb/mega"); toast("info", "Загружаю всю базу PoE2", "вики, данные игры, патч-ноуты и видео YouTube — в фоне, можно пользоваться тулой"); mega(); };
  mega();
  $("#kb-all").onclick = async () => { await api.post("/api/kb/rebuild", {}); toast("info", "Пересборка запущена", "вики, моды, гемы, цены"); setTimeout(load, 1500); };
  $("#kb-prices").onclick = async () => { await api.post("/api/kb/rebuild", {parts: ["prices"]}); setTimeout(load, 2500); };
  $("#kb-add").onclick = async e => {
    const btn = e.currentTarget; spinBtn(btn, true, "Добавляю…");
    try { const r = await api.post("/api/kb/add", {type, value: $("#kb-val").value, title: $("#kb-title").value, kind: type === "pob" ? "build" : "guide"});
      toast("ok", "Добавлено", `${r.count} фрагментов`); $("#kb-val").value = ""; load(); }
    catch (err) { toast("err", "Не добавилось", err.message); }
    spinBtn(btn, false);
  };
  const search = async () => {
    const r = await api.get(`/api/kb/search?q=${encodeURIComponent($("#kb-q").value)}`);
    $("#kb-res").innerHTML = r.map(d => `<div style="padding:10px 0;border-bottom:1px solid var(--line)"><div class="row"><span class="tag">${esc(KINDS[d.kind] || d.kind)}</span><b>${esc(d.title)}</b>
      ${d.url ? `<a class="small" href="${esc(d.url)}" target="_blank">источник ↗</a>` : ""}</div><div class="small muted md">${md(d.body.slice(0, 600))}</div></div>`).join("") || `<div class="muted">Ничего</div>`;
  };
  $("#kb-go").onclick = search; $("#kb-q").onkeydown = e => { if (e.key === "Enter") search(); };
  registerModule({id: "kb", onShow: load});
})();
