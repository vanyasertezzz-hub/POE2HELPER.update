(function () {
  "use strict";
  const {api, esc, fmt, registerModule, assistantPanel, spinBtn, toast} = window.P2;
  const root = document.getElementById("farm-root");
  root.innerHTML = `
    <div class="card glow" style="margin-bottom:16px"><div class="sec-h" style="--k:var(--k-reward)"><span class="si">📚</span><div><h3>Библиотека фарма</h3>
        <div class="sd">каждая стратегия — строгая цепочка: атлас → таблетки → вейстоуны → что делать на карте → лут → продажа → доход.
        Собрано из видео и гайдов текущего патча, вики, патч-ноутов и живых цен; обновляется само, когда в базе появляется новое</div></div></div>
      <div id="fm-you"></div>
      <div id="fm-lib" class="fm-lib"><div class="skel"></div></div></div>
    <div class="grid g3">
      <div class="card glow" style="grid-column:span 2"><h3>Рынок механик: что сейчас дорого <span class="muted small" id="fm-league"></span></h3>
        <div class="small faint" style="margin:-6px 0 12px">score = цена топ-лута + ликвидность (объём торгов) + тренд 7 дней, по poe.ninja. Это НЕ доход: как часто лут падает, рынок не знает. Реальный доход — в «Сессиях фарма» ниже</div>
        <div id="fm-meta"><div class="skel"></div><div class="skel"></div><div class="skel"></div></div></div>
      <div class="card"><div class="row"><h3 style="margin:0">Трекер карт</h3><span class="spacer"></span>
          <select class="inp" id="fm-hours" style="width:auto;padding:4px 8px;font-size:12px">${[[3, "3 часа"], [12, "12 часов"], [24, "сутки"], [168, "неделя"], [720, "месяц"]]
            .map(([v, l]) => `<option value="${v}" ${v === 12 ? "selected" : ""}>${l}</option>`).join("")}</select></div><div id="fm-track" style="margin-top:10px"></div></div>
    </div>
    <div class="grid g2" style="margin-top:16px">
      <div class="card"><div class="row"><h3 style="margin:0">🗺 Маршрут атласа</h3><span class="spacer"></span>
          <select class="inp" id="fm-strat" style="width:auto"></select><button class="btn sm primary" id="fm-atlas-go">Построить</button></div>
        <div class="small muted" style="margin:6px 0">Этапы по тирам: что взять в атласе, какие таблетки, какие моды вейстоунов катать и каких избегать — под твой билд и бюджет.</div>
        <div id="fm-atlas"></div></div>
      <div class="card"><div class="row"><h3 style="margin:0">💰 Сессии фарма и доход</h3><span class="spacer"></span><button class="btn sm" id="fm-stash">Оценить стеш</button></div>
        <div id="fm-sess" style="margin-top:10px"></div></div>
    </div>
    <div class="card" style="margin-top:16px"><div class="row" style="gap:8px;flex-wrap:wrap"><h3 style="margin:0">📜 Шпаргалки механик</h3><span class="spacer"></span><div class="row" id="fm-cheat-list" style="gap:6px;flex-wrap:wrap"></div></div>
      <div class="small muted" style="margin:6px 0">Коротко по механике: описание из самой игры и памятка по статье вики. Памятка сверена со статьёй: строку с числом или названием не из неё тула убирает.</div>
      <div id="fm-cheat"></div></div>
    <div class="card" style="margin-top:16px"><div class="row" style="gap:8px;flex-wrap:wrap"><h3 style="margin:0">🧹 Лут-фильтр под билд</h3><span class="spacer"></span>
        <select class="inp" id="fm-filter-strict" style="width:auto"><option value="1">мягкий</option><option value="2" selected>обычный</option><option value="3">строгий</option></select>
        <button class="btn sm primary" id="fm-filter-go">Собрать</button></div>
      <div class="small muted" style="margin:6px 0">Валюта и всё биржевое — по ценам poe.ninja и poe2scout с объёмом торгов (ярусы S / A / B), неогранённые камни — по цене уровня, уники всегда, базы твоего билда из PoB — синей рамкой. Строгость прячет только броню и оружие и только на картах: валюту, уники, камни, ключи, вейстоуны, бижутерию никогда.</div>
      <div id="fm-filter"></div></div>
    <div style="margin-top:16px" id="fm-assist"></div>`;
  const $ = s => root.querySelector(s);

  const STEP_ICON = {atlas: ["🌐", "act"], tablet: ["🔹", "gem"], waystone: ["🗝", "item"], map: ["🗺", "info"], fight: ["⚔", "boss"],
    loot: ["💎", "reward"], sell: ["💰", "money"], warn: ["⚠", "warn"], tip: ["✅", "node"]};
  async function openGuide(kind, force) {
    const m = window.P2.modal("Гайд по фарму", `<div class="skel"></div><div class="skel"></div><div class="small muted">Собираю цены, механику и твой билд, пишу пошаговый план…</div>`, 860);
    let g;
    try { g = await api.get(`/api/farm/guide/${encodeURIComponent(kind)}${force ? "?force=true" : ""}`); }
    catch (e) { m.el.innerHTML = `<div class="kb warn"><span class="ki">⚠</span><div class="kt">${esc(e.message)}</div></div>`; return; }
    const tabSpec = g.tablet ? esc(JSON.stringify({cls: "tablet", base: g.tablet.name, mods: []})) : "";
    m.el.innerHTML = `<div class="row" style="gap:14px;align-items:center">${g.atlas_icon ? `<img src="${esc(g.atlas_icon)}" style="width:56px;height:56px">` : g.top[0] && g.top[0].image ? `<img src="${esc(g.top[0].image)}" style="width:56px;height:56px;object-fit:contain">` : ""}
        <div><div style="font-size:20px;font-weight:800">${esc(g.mechanic)}</div><div class="row" style="gap:6px;margin-top:4px"><span class="pill info">score ${g.score}</span>
          <span class="pill skip">${esc(g.league)}</span></div></div>
        <span class="spacer"></span><button class="btn sm ghost" id="fg-re">⟳ Обновить</button><button class="btn sm primary" id="fg-sess">▶ Начать сессию фарма</button></div>
      <div class="kb info"><span class="ki">ℹ</span><div class="kt">${esc(g.summary || "")}</div></div>
      ${(g.unverified || []).length ? `<div class="kb warn"><span class="ki">⚠</span><div class="kt"><b class="kh">Проверка тулой</b>
        Этих названий нет в данных игры и базе знаний — это догадка модели, не опирайся на них: ${esc(g.unverified.join(", "))}</div></div>` : ""}
      ${g.fit ? `<div class="kb node"><span class="ki">🛡</span><div class="kt"><b class="kh">Для твоего билда</b>${esc(g.fit)}</div></div>` : ""}
      <div class="bv-sgh" style="--k:var(--k-reward);margin-top:12px">Что падает и почём сейчас</div>
      <div class="fg-loot">${g.top.map(t => `<div class="fg-li">${t.image ? `<img src="${esc(t.image)}">` : ""}<b>${esc(t.name)}</b><span>${fmt.ex(t.exalted)} ex · ${fmt.div(t.divine)} div</span>
        ${t.change7d != null ? `<small>${fmt.pct(t.change7d)}</small>` : ""}</div>`).join("")}</div>
      ${g.tablet ? `<div class="kb gem" style="margin-top:10px"><img src="${esc(g.tablet.icon)}" style="width:42px;height:42px;object-fit:contain"><div class="kt"><b class="kh">Таблетка механики</b>${esc(g.tablet.name)}
        <div style="margin-top:4px"><button class="btn sm" data-p2act="trade" data-spec="${tabSpec}">🔎 Купить на трейде</button></div></div></div>` : ""}
      <div class="bv-sgh" style="--k:var(--k-act);margin-top:12px">Пошагово</div>
      ${(g.steps || []).map((st, i) => { const [ic, k] = STEP_ICON[st.icon] || ["•", "info"];
        return `<div class="kb ${k}"><span class="ki">${ic}</span><div class="kt"><b class="kh">${i + 1}. ${esc(st.title || "")}</b>${esc(st.text || "")}</div></div>`; }).join("")}
      <div class="grid g2" style="margin-top:10px">
        ${(g.atlas || []).length ? `<div><div class="bv-sgh" style="--k:var(--k-act)">🌐 Атлас</div>${g.atlas.map(a => `<div class="small" style="padding:2px 0">• ${esc(a)}</div>`).join("")}</div>` : ""}
        ${g.waystone ? `<div><div class="bv-sgh" style="--k:var(--k-item)">🗝 Вейстоуны</div>${(g.waystone.roll || []).map(a => `<div class="small up">✓ ${esc(a)}</div>`).join("")}
          ${(g.waystone.avoid || []).map(a => `<div class="small down">✗ ${esc(a)}</div>`).join("")}</div>` : ""}
        ${(g.loot || []).length ? `<div><div class="bv-sgh" style="--k:var(--k-reward)">💎 Подбирать</div>${g.loot.map(a => `<div class="small">• ${esc(a)}</div>`).join("")}</div>` : ""}
        ${(g.sell || []).length ? `<div><div class="bv-sgh" style="--k:var(--k-money)">💰 Продавать</div>${g.sell.map(a => `<div class="small">• ${esc(a)}</div>`).join("")}</div>` : ""}
      </div>`;
    m.el.querySelector("#fg-re").onclick = () => { m.close(); openGuide(kind, true); };
    m.el.querySelector("#fg-sess").onclick = async () => {
      try { await api.post("/api/farm/session/start", {strategy: g.mechanic, value: null}); toast("ok", "Сессия фарма начата", g.mechanic + " — доход посчитаю по картам из лога"); m.close(); loadSessions && loadSessions(); }
      catch (e) { toast("err", "Сессия", e.message); }
    };
  }
  window.P2.farmGuide = openGuide;

  // ── farm library: strict chains per strategy ──
  async function loadLibrary() {
    let lib; try { lib = await api.get("/api/farm/library"); } catch (e) { $("#fm-lib").innerHTML = `<div class="muted">${esc(e.message)}</div>`; return; }
    $("#fm-lib").innerHTML = lib.map(s => `<button class="fm-libc" data-sid="${esc(s.id)}"><b>${esc(s.title)}</b>
      <span class="tiny muted">${s.ready ? "цепочка готова · " + fmt.ago(s.made) : "соберу по запросу (~30 с)"}</span>
      ${s.thin ? `<span class="tiny" style="color:#fbbf24">⚠ мало материала: ${esc(s.thin)}</span>` : ""}
      ${s.measured ? `<span class="tiny up">📏 твой замер: ${s.measured.div_per_hour ?? "—"} div/час за ${s.measured.hours.toFixed(1)} ч${s.measured.solid ? "" : " (мало данных)"}</span>` : ""}
      ${s.buzz && s.buzz.hot ? `<span class="tiny" title="${esc(s.buzz.latest || "")}">🔥 обсуждают: ${fmt.n(s.buzz.week, "материал|материала|материалов")} за неделю, неделей раньше ${s.buzz.before}</span>` : ""}
      ${s.yield ? `<span class="tiny" style="color:${/в минус/i.test(s.yield) ? "#f87171" : /чистыми \+/.test(s.yield) ? "#4ade80" : "var(--muted)"}" title="посчитано из проверенных чисел источников и твоих замеров">💰 ${esc(s.yield)}</span>` : ""}
      ${s.summary ? `<span class="tiny">${esc(s.summary.slice(0, 120))}${s.summary.length > 120 ? "…" : ""}</span>` : ""}
      ${(s.unverified || []).length ? `<span class="tiny" style="color:#fca5a5">⚠ нет в данных игры: ${esc(s.unverified.join(", "))}</span>` : ""}<span class="tiny fm-think"></span></button>`).join("");
    root.querySelectorAll(".fm-libc").forEach(b => b.onclick = () => openChain(b.dataset.sid));
    // the way a strong player decides, on the player's own numbers: pace, his yield, his risk, the inputs, when to sell
    api.get("/api/farm/think").then(g => {
      // the player's pace and deaths are the same for every strategy: once, above the cards
      const you = (g.lines || {})._you || [];
      $("#fm-you").innerHTML = you.length ? `<div class="kb ${you.some(l => /^Риск: смерть в \d+% карт \(/.test(l)) ? "warn" : "info"}" style="margin-bottom:12px">
        <span class="ki">🧠</span><div class="kt"><b class="kh">Ты сейчас — для любой стратегии</b>${you.map(l => `<div class="small">${esc(l)}</div>`).join("")}</div></div>` : "";
      root.querySelectorAll(".fm-libc").forEach(b => {
        const lines = (g.lines || {})[b.dataset.sid] || [], el = b.querySelector(".fm-think");
        if (el && lines.length) el.innerHTML = "🧠 " + lines.map(l => `<span style="display:block;color:var(--muted)">${esc(l)}</span>`).join("");
      });
    }).catch(() => {});
  }
  async function openChain(sid, force) {
    const m = window.P2.modal("Цепочка фарма", `<div class="skel"></div><div class="skel"></div><div class="small muted">Собираю из базы знаний: видео и гайды текущего патча, вики, патч-ноут, цены… до минуты</div>`);
    let g;
    try { g = await api.get(`/api/farm/library/${encodeURIComponent(sid)}${force ? "?force=true" : ""}`); }
    catch (e) { m.el.innerHTML = `<div class="kb warn"><span class="ki">⚠</span><div class="kt">${esc(e.message)}</div></div>`; return; }
    const list = (xs, f) => (xs || []).map(f).join("");
    m.el.innerHTML = `<div class="row"><div><div style="font-size:20px;font-weight:800">${esc(g.title)}</div>
        <div class="row" style="gap:6px;margin-top:4px"><span class="pill skip">${esc(g.league)} · патч 0.${g.patch}</span>
        ${g.thin ? `<span class="pill warn" title="на таком материале цепочке нельзя верить как полному гайду">⚠ мало материала: ${esc(g.thin)}</span>` : ""}
        ${g.measured ? `<span class="pill money" title="твои сессии фарма: богатство в начале и в конце, карты из лога игры">📏 твой замер: ${g.measured.div_per_hour ?? "—"} div/час · ${fmt.n(g.measured.sessions, "сессия|сессии|сессий")}, ${g.measured.hours.toFixed(1)} ч</span>` : `<span class="pill skip" title="начни сессию фарма — тула посчитает реальный доход">📏 своего замера нет</span>`}
        <span class="pill info">источников: ${g.evidence}</span></div></div>
        <span class="spacer"></span><button class="btn sm ghost" id="fc-re">⟳ Пересобрать</button></div>
      ${(g.unverified || []).length ? `<div class="kb warn" style="margin-top:10px"><span class="ki">⚠</span><div class="kt"><b class="kh">Проверка тулой</b>
        Этих названий нет в данных игры и базе знаний — это догадка модели, не опирайся на них: ${esc(g.unverified.join(", "))}</div></div>` : ""}
      ${g.versus ? `<div class="kb money" style="margin-top:10px"><span class="ki">📏</span><div class="kt">${esc(g.versus)}</div></div>` : ""}
      <div class="kb info" style="margin-top:10px"><span class="ki">ℹ</span><div class="kt">${esc(g.summary || "")}</div></div>
      ${g.fit ? `<div class="kb node"><span class="ki">🛡</span><div class="kt"><b class="kh">Твой персонаж</b>${esc(g.fit)}</div></div>` : ""}
      ${(g.requirements || []).length ? `<div class="bv-sgh" style="--k:var(--k-act);margin-top:10px">Что нужно до старта</div>${list(g.requirements, x => `<div class="small">• ${esc(x)}</div>`)}` : ""}
      <div class="bv-sgh" style="--k:var(--k-act);margin-top:12px">Цепочка действий</div>
      ${list(g.chain, (ph, pi) => `<div class="card" style="padding:10px 12px;margin:6px 0"><b class="small">${pi + 1}. ${esc(ph.phase || "")}</b>
        ${list(ph.steps, (s, i) => `<div class="kb act" style="margin:4px 0"><span class="ki">${i + 1}</span><div class="kt">${esc(s)}</div></div>`)}</div>`)}
      <div class="grid g2" style="margin-top:10px">
        ${(g.atlas || []).length ? `<div><div class="bv-sgh" style="--k:var(--k-act)">🌐 Атлас</div>${list(g.atlas, a => `<div class="small" style="padding:2px 0">• <b>${esc(a.node || a)}</b>${a.why ? " — " + esc(a.why) : ""}</div>`)}</div>` : ""}
        ${(g.tablets || []).length ? `<div><div class="bv-sgh" style="--k:var(--k-gem)">🔹 Таблетки</div>${list(g.tablets, t => `<div class="small" style="padding:2px 0">• <b>${esc(t.name || "")}</b>${(t.mods || []).length ? ": " + t.mods.map(esc).join(", ") : ""}${t.why ? ` <span class="muted">(${esc(t.why)})</span>` : ""}</div>`)}</div>` : ""}
        ${g.waystones ? `<div><div class="bv-sgh" style="--k:var(--k-item)">🗝 Вейстоуны ${esc(g.waystones.tier || "")}</div>${list(g.waystones.roll, a => `<div class="small up">✓ ${esc(a)}</div>`)}${list(g.waystones.avoid, a => `<div class="small down">✗ ${esc(a)}</div>`)}</div>` : ""}
        ${(g.loot || []).length ? `<div><div class="bv-sgh" style="--k:var(--k-reward)">💎 Лут</div>${list(g.loot, l => `<div class="small">• ${esc(l.item || l)}${l.value ? ` — <b>${esc(l.value)}</b>` : ""}</div>`)}</div>` : ""}
        ${(g.sell || []).length ? `<div><div class="bv-sgh" style="--k:var(--k-money)">💰 Продажа</div>${list(g.sell, a => `<div class="small">• ${esc(a)}</div>`)}</div>` : ""}
        ${(g.mistakes || []).length ? `<div><div class="bv-sgh" style="--k:var(--k-boss)">⚠ Частые ошибки</div>${list(g.mistakes, a => `<div class="small">• ${esc(a)}</div>`)}</div>` : ""}
      </div>
      ${(g.prices || []).length ? `<div class="bv-sgh" style="--k:var(--k-reward);margin-top:10px">Цены лута сейчас</div><div class="fg-loot">${list(g.prices, t => `<div class="fg-li">${t.image ? `<img src="${esc(t.image)}">` : ""}<b>${esc(t.name)}</b><span>${fmt.div(t.divine)} div</span></div>`)}</div>` : ""}
      <div class="small muted" style="margin-top:6px">Доход покажет только твоя сессия фарма: как часто что падает, заранее неизвестно.</div>
      ${g.total ? `<div class="kb money" style="margin-top:10px"><span class="ki">Σ</span><div class="kt"><b class="kh">Итого</b>${esc(g.total.replace(/^Итого:\s*/i, ""))}</div></div>` : ""}
      ${(g.patch_lines || []).length ? `<details style="margin-top:8px"><summary class="small">Что изменил текущий патч (${g.patch_lines.length})</summary>${list(g.patch_lines, l => `<div class="tiny" style="padding:2px 0">${esc(l)}</div>`)}</details>` : ""}
      <details style="margin-top:6px"><summary class="small">Источники (${(g.sources || []).length})</summary>${list(g.sources, s => `<div class="tiny" style="padding:2px 0">[${esc(s.kind)}] ${s.url ? `<a href="${esc(s.url)}" target="_blank">${esc(s.title)}</a>` : esc(s.title)}</div>`)}</details>`;
    m.el.querySelector("#fc-re").onclick = () => { m.close(); openChain(sid, true); };
    loadLibrary();
  }

  async function load() {
    loadLibrary();
    api.get("/api/farm/meta").then(d => {
      $("#fm-league").textContent = d.league;
      const max = Math.max(...d.rows.map(r => r.score), 1);
      $("#fm-meta").innerHTML = `<div class="small muted" style="margin-bottom:6px">👆 нажми на механику — откроется пошаговый гайд с картинками под твой билд</div>
        <table class="tbl fm-rows"><tbody>${d.rows.map((m, i) => `<tr data-kind="${esc(m.kind)}" style="cursor:pointer" title="Пошаговый гайд"><td style="width:24px" class="faint">${i + 1}</td>
        <td><div class="row" style="gap:8px">${m.top[0] && m.top[0].image ? `<img src="${esc(m.top[0].image)}" style="width:30px;height:30px;object-fit:contain">` : ""}
          <div><b>${esc(m.mechanic)}</b> <span class="pill info" style="font-size:10px">гайд →</span><div class="tiny muted">${m.top.slice(0, 3).map(t => `${esc(t.name)} ${fmt.ex(t.exalted)}ex`).join(" · ")}</div></div></div></td>
        <td style="width:160px"><div class="bar"><i style="width:${100 * m.score / max}%"></i></div></td><td class="num">${m.score}</td>
        <td class="num">${fmt.div(m.top_value_div)} div</td><td class="num">${fmt.pct(m.trend7d)}</td><td class="num">${m.measured && m.measured.solid ? `<span class="up" title="твои сессии фарма">📏 ${m.measured.div_per_hour} div/ч</span>` : ""}</td></tr>`).join("")}</tbody></table>`;
      root.querySelectorAll(".fm-rows tr[data-kind]").forEach(tr => tr.onclick = () => openGuide(tr.dataset.kind));
    }).catch(e => $("#fm-meta").innerHTML = `<div class="muted">${esc(e.message)}</div>`);
    const t = await api.get(`/api/farm/tracker?hours=${+$("#fm-hours").value || 24}`);
    // the map being run: its boss and layout from the game's data (wiki list, PoE2DB names), no model's words
    const bossRu = b => b.ru && b.ru !== b.en ? `${esc(b.ru)} <span class="tiny faint">${esc(b.en)}</span>` : esc(b.en);
    const mapLine = mp => mp ? [mp.bosses.length ? "босс: " + mp.bosses.map(b => b.ru || b.en).join(", ") : "", mp.layout ? "планировка: " + mp.layout : "", ...mp.notes].filter(Boolean).join(" · ") : "";
    const mapNow = m => `<div class="kb boss" style="margin-top:10px"><span class="ki">🗺</span><div class="kt"><b class="kh">Сейчас: ${esc(m.area_ru || m.area)} · ур. ${m.level}</b>
      ${m.map.bosses.length ? `<div class="small">Босс: ${m.map.bosses.map(bossRu).join(", ")}</div>` : ""}
      ${m.map.layout ? `<div class="small">Планировка: ${esc(m.map.layout)}</div>` : ""}${m.map.notes.map(n => `<div class="small">${esc(n)}</div>`).join("")}
      ${m.map.wiki_note ? `<div class="tiny muted">Вики: ${esc(m.map.wiki_note)}</div>` : ""}</div></div>`;
    $("#fm-track").innerHTML = `<div class="grid g3"><div class="stat"><b>${t.runs}</b><span>карт</span></div>
      <div class="stat"><b>${t.avg_min ? t.avg_min.toFixed(1) : "—"}</b><span>мин/карта</span></div><div class="stat"><b>${t.per_hour ? t.per_hour.toFixed(1) : "—"}</b><span>карт/час</span></div></div>
      ${t.now && t.now.map ? mapNow(t.now) : ""}
      <div class="hr"></div>${t.recent.slice().reverse().slice(0, 10).map(m => `<div class="row small" style="padding:3px 0" title="${esc(mapLine(m.map))}"><span>${esc(m.area_ru || m.area)}</span><span class="tag">ур. ${m.level}</span>${m.deaths ? `<span class="tag" style="color:var(--red)" title="смертей в этой карте">☠ ${m.deaths}</span>` : ""}<span class="spacer"></span><span class="faint">${m.open ? "идёт" : m.minutes + " мин"}</span></div>`).join("") || `<div class="faint small">Карт пока не было — трекер начнёт считать, как только зайдёшь в мапу.</div>`}`;
  }

  assistantPanel($("#fm-assist"), {
    kind: "farm", newUrl: "/api/farm/new", newTitle: "План фарма", createLabel: "Подобрать стратегию",
    formHtml: `<div class="skel"></div>`,
    onForm: async f => {
      const c = await window.P2.choices();
      f.innerHTML = `<div class="field"><label>Цель</label>${window.P2.selectHtml("goal", c.goals.farm, {custom: true, placeholder: "своя цель"})}</div>
        <div class="field"><label>Билд (чтобы учесть, что он потянет)</label><div class="f-src"></div></div>
        <div class="field"><label>Бюджет на вложения</label>${window.P2.selectHtml("budget", c.budgets, {empty: "— не важно —"})}</div>
        <div class="field"><label>Сколько играешь</label>${window.P2.selectHtml("hours", c.hours, {empty: "— не важно —"})}</div>`;
      window.P2.wireSelects(f);
      await window.P2.sourcePicker(f.querySelector(".f-src"), {none: "— не учитывать билд —"});
    },
    collect: f => ({goal: window.P2.selectValue(f, "goal"), budget: window.P2.selectValue(f, "budget"),
                    hours: window.P2.selectValue(f, "hours"), ...(window.P2.sourceValue(f.querySelector(".f-src")) || {})}),
    chips: ["Что взять в атласе под эту стратегию?", "Какие таблетки и моды вейстоунов?", "Мой билд потянет эту механику?", "Как продавать лут быстрее?", "Пересмотри стратегию по свежим ценам"],
    emptyHtml: "Ассистент видит рейтинг механик по живым ценам, твою скорость карт из трекера и персонажа — и строит пошаговый план эндгейма.",
  });
  $("#fm-hours").onchange = load;

  // ── atlas route ──
  async function loadStrategies() {
    const d = await api.get("/api/farm/meta").catch(() => ({rows: []}));
    $("#fm-strat").innerHTML = d.rows.map(m => `<option value="${esc(m.mechanic)}">${esc(m.mechanic)} (score ${m.score})</option>`).join("")
      + `<option value="Смешанный фарм (универсально)">Смешанный фарм</option>`;
    const saved = await api.get("/api/farm/atlas").catch(() => ({}));
    const first = Object.values(saved)[0];
    if (first && !$("#fm-atlas").innerHTML) renderAtlas(first);
  }
  function renderAtlas(p) {
    const tab = t => esc(JSON.stringify({cls: "tablet", base: t.name, mods: []}));
    $("#fm-atlas").innerHTML = `${p.stale ? `<div class="kb warn" style="margin-bottom:6px"><span class="ki">⟳</span><div class="kt">План собран до того, как в базе знаний появились новые гайды и патч-ноуты — нажми «Построить», чтобы обновить.</div></div>` : ""}
      <div class="small" style="margin-bottom:8px"><b>${esc(p.strategy)}:</b> ${esc(p.summary || "")}</div>
      ${(p.steps || []).map(st => `<div class="card" style="padding:10px 12px;margin-bottom:8px"><div class="row"><span class="tag green">${esc(st.tier || "")}</span><b class="small">${esc(st.goal || "")}</b></div>
        ${(st.atlas || []).length ? `<div class="tiny" style="margin-top:4px">🌐 Атлас: ${st.atlas.map(esc).join(" · ")}</div>` : ""}
        ${(st.tablets || []).map(t => `<div class="row tiny" style="margin-top:3px">🔹 ${esc(t.name)} — ${esc(t.why || "")}<span class="spacer"></span><button class="btn sm" data-p2act="trade" data-spec="${tab(t)}">🔎</button></div>`).join("")}
        ${st.waystone ? `<div class="tiny" style="margin-top:3px">✓ катать: ${(st.waystone.roll || []).map(esc).join(", ") || "—"}</div>
          <div class="tiny" style="color:var(--red)">✗ избегать: ${(st.waystone.avoid || []).map(esc).join(", ") || "—"}</div>` : ""}
        ${st.farm ? `<div class="tiny muted">⛏ ${esc(st.farm)}</div>` : ""}${st.sell ? `<div class="tiny muted">💰 ${esc(st.sell)}</div>` : ""}</div>`).join("")}
      ${(p.watch_out || []).length ? `<div class="small" style="color:var(--amber)">⚠ ${p.watch_out.map(esc).join(" · ")}</div>` : ""}
      ${(p.unverified || []).length ? `<div class="kb warn" style="margin-top:8px"><span class="ki">⚠</span><div class="kt"><b class="kh">Проверка тулой</b>
        Этих названий нет в данных игры и базе знаний — это догадка модели: ${esc(p.unverified.join(", "))}</div></div>` : ""}
      <button class="btn sm" id="fm-avoid" style="margin-top:8px">Добавить «избегать» в проверку вейстоунов</button>`;
    $("#fm-avoid").onclick = async () => {
      const add = (p.steps || []).flatMap(st => (st.waystone || {}).avoid || []).map(x => x.replace(/[.*+?^${}()|[\]\\]/g, "").replace(/\d+/g, ".*").slice(0, 60)).filter(Boolean);
      const cur = await api.get("/api/price/danger");
      await api.post("/api/price/danger", {patterns: [...new Set([...cur, ...add])]});
      toast("ok", "Добавлено в проверку вейстоунов", `${fmt.n(add.length, "мод|мода|модов")} — Ctrl+Alt+D в игре подсветит их красным`);
    };
  }
  $("#fm-atlas-go").onclick = async e => {
    const btn = e.currentTarget; spinBtn(btn, true, "Строю…");
    $("#fm-atlas").innerHTML = `<div class="skel"></div><div class="skel"></div><div class="skel"></div>`;
    try { renderAtlas(await api.post("/api/farm/atlas", {strategy: $("#fm-strat").value})); }
    catch (err) { $("#fm-atlas").innerHTML = `<div style="color:var(--red)">${esc(err.message)}</div>`; }
    spinBtn(btn, false);
  };

  // ── farm sessions with income ──
  // the stash's worth over the league: one point per full valuation (session start/stop, «Оценить стеш»)
  function wealthLine(w) {
    const p = (w && w.points) || [];
    if (p.length < 2) return p.length ? `<div class="tiny faint" style="margin-top:8px">Стоимость сундука: ${p[0][1]} div — график появится со второй оценки.</div>` : "";
    const W = 320, H = 56, t0 = p[0][0], t1 = p[p.length - 1][0] || t0 + 1;
    const lo = Math.min(...p.map(x => x[1])), hi = Math.max(...p.map(x => x[1])), span = hi - lo || 1;
    const xy = p.map(([t, v]) => `${((t - t0) / (t1 - t0 || 1) * W).toFixed(1)},${(H - 4 - (v - lo) / span * (H - 8)).toFixed(1)}`).join(" ");
    const sgn = v => v == null ? "—" : `<b style="color:var(${v >= 0 ? "--green" : "--red"})">${v >= 0 ? "+" : ""}${v} div</b>`;
    return `<div class="hr"></div><div class="row small"><b>Стоимость сундука за лигу</b><span class="spacer"></span><span class="tag">${w.last} div</span></div>
      <svg viewBox="0 0 ${W} ${H}" preserveAspectRatio="none" style="width:100%;height:${H}px;margin-top:4px"><polyline points="${xy}" fill="none" stroke="var(--accent)" stroke-width="2" vector-effect="non-scaling-stroke"/></svg>
      <div class="tiny muted">за сутки ${sgn(w.day)} · за неделю ${sgn(w.week)} · с начала лиги ${sgn(w.league)} · ${fmt.n(p.length, "оценка|оценки|оценок")}; в счёт идёт только то, что лежит в сундуке тулы (Ctrl+C)</div>`;
  }

  async function loadSessions() {
    const d = await api.get("/api/farm/session");
    const a = d.active;
    $("#fm-sess").innerHTML = (a ? `<div class="card glow" style="padding:12px"><div class="row"><b>▶ Идёт сессия: ${esc(a.strategy)}</b><span class="spacer"></span><span class="tiny faint">с ${new Date(a.start * 1000).toLocaleTimeString()}</span></div>
        <div class="row" style="margin-top:8px"><input class="inp" id="fm-end-val" type="number" step="0.1" placeholder="сколько у тебя сейчас (div)" style="flex:1"><button class="btn primary" id="fm-stop">Завершить</button></div></div>`
      : `<div class="row"><select class="inp" id="fm-sess-strat" style="flex:1">${$("#fm-strat").innerHTML}</select>
          <input class="inp" id="fm-start-val" type="number" step="0.1" placeholder="сейчас у тебя (div)" style="width:170px"><button class="btn primary" id="fm-start">Начать</button></div>
        <div class="tiny faint" style="margin-top:4px">Сумму можно не вводить: тула возьмёт оценку своего сундука (предметы и валюта, скопированные Ctrl+C). В логе игры нет подбора лута, поэтому копируй добычу перед концом сессии. Карты считаются сами.</div>`)
      + (d.by_strategy.length ? `<div class="hr"></div><b class="small">Сравнение стратегий этой лиги</b>${d.advice ? `<div class="small" style="margin:4px 0">${esc(d.advice)}</div>` : ""}<table class="tbl"><thead><tr><th>Стратегия</th><th style="text-align:right">div/час</th><th style="text-align:right">div/карта</th><th style="text-align:right">карт/час</th><th style="text-align:right">часов</th></tr></thead><tbody>
          ${d.by_strategy.map(x => `<tr><td>${esc(x.strategy)}${x.solid ? "" : ` <span class="tiny faint">мало данных</span>`}</td><td class="num"><b>${x.div_per_hour ?? "—"}</b></td><td class="num">${x.div_per_map ?? "—"}</td><td class="num">${x.maps_per_hour ?? "—"}</td><td class="num">${x.hours.toFixed(1)}</td></tr>`).join("")}</tbody></table>` : "")
      + wealthLine(d.wealth)
      + (d.history.length ? `<div class="tiny muted" style="margin-top:8px">Последние: ${d.history.slice(0, 5).map(s => `${esc(s.strategy)} ${s.div_per_hour != null ? s.div_per_hour + " div/ч" : ""}${s.net_div_per_hour != null ? ` <span title="минус вейстоуны по цене трейда: ${s.map_cost && s.map_cost.div} div">(чистыми ${s.net_div_per_hour})</span>` : ""} (${fmt.n(s.maps || 0, "карта|карты|карт")})`).join(" · ")}</div>` : "");
    const st = $("#fm-start"), sp = $("#fm-stop");
    if (st) st.onclick = async () => { await api.post("/api/farm/session/start", {strategy: $("#fm-sess-strat").value, value: $("#fm-start-val").value ? +$("#fm-start-val").value : null}); toast("ok", "Сессия фарма начата"); loadSessions(); };
    if (sp) sp.onclick = async () => { const r = await api.post("/api/farm/session/stop", {value: $("#fm-end-val").value ? +$("#fm-end-val").value : null});
      const cost = r.map_cost && r.map_cost.div != null ? ` · вейстоуны ${r.map_cost.div} div${r.net_div_per_hour != null ? `, чистыми ${r.net_div_per_hour} div/час` : ""}` : "";
      toast("ok", "Сессия завершена", (r.div_per_hour != null ? `${r.div_per_hour} div/час · ${fmt.n(r.maps, "карта|карты|карт")}` : `${fmt.n(r.maps, "карта|карты|карт")} за ${r.hours} ч`) + cost); loadSessions(); };
  }
  $("#fm-stash").onclick = async e => {
    const btn = e.currentTarget; spinBtn(btn, true, "Считаю…");
    try { const r = await api.get("/api/farm/stash");
      toast(r.waiting ? "info" : "ok", `Стеш: ≈ ${r.total_divine} div${r.waiting ? " (неполная оценка)" : ""}`, r.note);
      const v = document.getElementById("fm-start-val") || document.getElementById("fm-end-val"); if (v) v.value = r.total_divine; }
    catch (err) { toast("err", "Стеш", err.message); }
    spinBtn(btn, false);
  };
  // the loot filter: made from the tool's prices and the build, saved into the game's folder on the player's press
  const ruName = x => `<span title="${esc(x.en)}">${esc(x.ru || x.en)}</span>`;
  $("#fm-filter-go").onclick = async e => {
    const btn = e.currentTarget, out = $("#fm-filter");
    spinBtn(btn, true, "Собираю…");
    try {
      const r = await api.post("/api/farm/filter", {strictness: +$("#fm-filter-strict").value});
      const t = r.summary.tiers, g = r.summary.gems;
      out.innerHTML = `<div class="small"><b>${esc(r.strict_ru)}</b> · лига ${esc(r.league)} · билд ${esc(r.build.name || "—")} · ${fmt.n(r.lines, "строка|строки|строк")}</div>
        <div class="row small" style="gap:6px;flex-wrap:wrap;margin:6px 0"><span class="pill boss">S (от 1 div): ${t.S}</span><span class="pill reward">A (от 0,25 div): ${t.A}</span><span class="pill gem">B (от 0,05 div): ${t.B}</span><span class="pill info">без яруса: ${t.C}</span><span class="pill gem">неогранённые камни в ярусах: ${g.S + g.A + g.B}</span></div>
        ${r.summary.top.length ? `<div class="tiny muted">Ярус S, например: ${r.summary.top.map(ruName).join(", ")}</div>` : ""}
        ${r.build.bases.length ? `<div class="tiny muted">Базы билда под крафт (ур. предмета 75+): ${r.build.bases.map(ruName).join(", ")}</div>` : `<div class="tiny muted">У активного персонажа нет билда PoB — базы билда в фильтр не вошли.</div>`}
        ${r.build.uniques.length ? `<div class="tiny muted">Базы уников билда: ${r.build.uniques.map(ruName).join(", ")}</div>` : ""}
        <div class="row" style="gap:8px;margin-top:8px;flex-wrap:wrap"><button class="btn sm primary" id="fm-filter-save">💾 Сохранить в папку игры</button><button class="btn sm" id="fm-filter-copy">📋 Скопировать текст</button>
          <span class="tiny faint">в игре: Настройки → Игра → Фильтр предметов → «POE2 Helper»</span></div>
        <details style="margin-top:6px"><summary class="tiny">Текст фильтра</summary><pre class="tiny" style="max-height:320px;overflow:auto;white-space:pre-wrap">${esc(r.text)}</pre></details>`;
      $("#fm-filter-copy").onclick = () => { navigator.clipboard?.writeText(r.text); toast("ok", "Текст фильтра скопирован"); };
      $("#fm-filter-save").onclick = async ev => {
        const sbtn = ev.currentTarget;  // null once the handler resumes after an await
        spinBtn(sbtn, true, "Сохраняю…");
        try { const s = await api.post("/api/farm/filter/save", {text: r.text}); toast("ok", "Фильтр сохранён", `${s.path} — выбери его в игре: Настройки → Игра → Фильтр предметов`); }
        catch (err) { toast("err", "Фильтр не сохранён", err.message); }
        spinBtn(sbtn, false);
      };
    } catch (err) { out.innerHTML = `<div class="kb warn"><span class="ki">⚠</span><div class="kt">${esc(err.message)}</div></div>`; }
    spinBtn(btn, false);
  };
  async function loadCheats() {
    let list; try { list = await api.get("/api/farm/cheats"); } catch (_) { return; }
    $("#fm-cheat-list").innerHTML = list.map(c => `<button class="btn sm ${c.ready ? "" : "ghost"}" data-cheat="${esc(c.id)}">${esc(c.title)}</button>`).join("");
    root.querySelectorAll("[data-cheat]").forEach(b => b.onclick = async () => {
      const out = $("#fm-cheat");
      spinBtn(b, true, "…");
      try {
        const c = await api.post(`/api/farm/cheats/${encodeURIComponent(b.dataset.cheat)}`, {});
        out.innerHTML = `<div class="card" style="margin-top:6px"><b>${esc(c.title)}</b>
          ${c.game ? `<div class="kb info" style="margin:8px 0"><span class="ki">ℹ</span><div class="kt"><b class="kh">Из игры</b>${esc(c.game)}</div></div>` : ""}
          <div class="md small">${window.P2.md(c.text || "")}</div>${c.check ? `<div class="md tiny" style="margin-top:6px">${window.P2.md(c.check)}</div>` : ""}
          <div class="row" style="margin-top:6px"><span class="tiny faint">по статье вики в базе знаний</span><span class="spacer"></span><button class="btn sm ghost" id="fm-cheat-again">🔄 Заново</button></div></div>`;
        $("#fm-cheat-again").onclick = async () => { await api.post(`/api/farm/cheats/${encodeURIComponent(c.id)}`, {force: true}); b.click(); };
        b.classList.remove("ghost");
      } catch (err) { out.innerHTML = `<div class="kb warn"><span class="ki">⚠</span><div class="kt">${esc(err.message)}</div></div>`; }
      spinBtn(b, false);
    });
  }
  registerModule({id: "farm", onShow: async () => { load(); await loadStrategies(); loadSessions(); loadCheats(); }});
})();
