(function () {
  "use strict";
  const {api, esc, md, stream, registerModule, onLive, toast} = window.P2;
  const root = document.getElementById("leveling-root");
  // one look per zone status: the player reads the icon and the colour, not a paragraph
  const ST = {
    town: {i: "🏠", t: "город", c: "var(--faint)"},
    reward: {i: "⭐", t: "награда — зайди", c: "var(--k-reward)"},
    quest: {i: "🔑", t: "нужна по заданию", c: "var(--k-item)"},
    optional: {i: "◇", t: "по желанию", c: "var(--k-item)"},
    main: {i: "➜", t: "по пути", c: "var(--k-act)"},
    skip: {i: "⏭", t: "пропусти", c: "var(--k-skip)"},
  };
  // chapters: G1…G4 are acts 1–4, P1…P3 the interludes (the data gives them all «act 6»)
  // the zone's list: which fight is worth it and which isn't, in the order of what it gives
  const STEP = {
    reward: {t: "⭐", c: "var(--k-reward)"}, story: {t: "⚔", c: "var(--k-act)"}, optional: {t: "◇", c: "var(--k-item)"},
    skip: {t: "⏭", c: "var(--k-skip)"}, poi: {t: "📍", c: "var(--faint)"},
  };
  const doneKey = (z, i) => `lv-step:${data.character || ""}:${z.id}:${i}`;
  const isDone = (z, i) => { try { return localStorage.getItem(doneKey(z, i)) === "1"; } catch { return false; } };
  const setDone = (z, i, on) => { try { on ? localStorage.setItem(doneKey(z, i), "1") : localStorage.removeItem(doneKey(z, i)); } catch { /* a blocked store only forgets the ticks */ } };
  const stepRows = z => z.steps.map((s, i) => `<div class="lv2-step ${isDone(z, i) ? "done" : ""}" style="--c:${(STEP[s.kind] || STEP.poi).c}">
      <input type="checkbox" data-step="${i}" title="Сделано" ${isDone(z, i) ? "checked" : ""}>
      <div><b>${(STEP[s.kind] || STEP.poi).t} ${esc(s.what)}</b>${s.gives ? `<div class="g">${esc(s.gives)}</div>` : ""}
        ${s.options.length ? `<ul>${s.options.map(o => `<li>${esc(o)}</li>`).join("")}</ul>` : ""}
        ${s.how ? `<div class="h">${esc(s.how)}</div>` : ""}</div></div>`).join("");
  // what a chapter gives in all: the reason not to rush past its stars
  const totals = zs => {
    const sum = {set: 0, pass: 0, spirit: 0, life: 0}, other = [];
    for (const r of zs.flatMap(z => z.rewards)) {
      const n = +(r.match(/^\+(\d+)/) || [])[1];
      if (n && /набора оружия/.test(r)) sum.set += n;
      else if (n && /очк\S* пассивн/.test(r)) sum.pass += n;
      else if (n && /дух/i.test(r)) sum.spirit += n;
      else other.push(r);
    }
    return [sum.pass && `пассивные умения: +${sum.pass}`, sum.set && `для набора оружия: +${sum.set}`, sum.spirit && `дух: +${sum.spirit}`, other.length && `другие бонусы: ${other.length}`].filter(Boolean).join(" · ");
  };
  const chapterOf = z => z.id.split("_")[0];
  const chapterName = ch => ch[0] === "G" ? `Акт ${ch.slice(1)}` : `Интерлюдия ${ch.slice(1)}`;
  root.innerHTML = `<style>
    .lv2-tabs{display:flex;gap:6px;flex-wrap:wrap;margin:10px 0 4px}
    .lv2-tab{padding:6px 12px;border-radius:999px;border:1px solid var(--line);background:var(--sunk);cursor:pointer;font-size:13px}
    .lv2-tab.on{border-color:var(--accent2);background:rgba(139,92,246,.18);font-weight:650}
    .lv2-tab .n{color:var(--k-reward);font-size:11px;margin-left:4px}
    .lv2-must{display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:8px;margin:8px 0 14px}
    .lv2-rw{padding:9px 11px;border-radius:12px;background:rgba(250,204,21,.08);border:1px solid rgba(250,204,21,.25);cursor:pointer}
    .lv2-rw b{display:block;color:#fde68a;font-size:13px;line-height:1.3}.lv2-rw span{font-size:11.5px;color:var(--muted)}
    .lv2-route{position:relative;margin-left:6px}
    .lv2-z{display:grid;grid-template-columns:28px 1fr auto;gap:10px;align-items:center;padding:7px 10px;border-radius:10px;cursor:pointer;position:relative}
    .lv2-z:hover{background:rgba(139,92,246,.08)}.lv2-z.sel{background:rgba(139,92,246,.14)}
    .lv2-z.cur{background:rgba(251,191,36,.10);box-shadow:inset 3px 0 0 var(--amber)}
    .lv2-z .dot{width:26px;height:26px;border-radius:50%;display:grid;place-items:center;font-size:13px;background:var(--sunk);border:2px solid var(--c)}
    .lv2-z .nm{font-weight:600;font-size:14px}.lv2-z .sub{font-size:12px;color:var(--muted);margin-top:1px}
    .lv2-z .rw{font-size:12px;color:#fde68a;margin-top:1px}
    .lv2-z .lv{font-size:11px;color:var(--faint);white-space:nowrap}
    .lv2-z.skip{opacity:.45}.lv2-z.skip .nm{font-weight:500;text-decoration:line-through;text-decoration-color:rgba(148,163,184,.5)}
    .lv2-z.town .nm{color:var(--faint)}
    .lv2-here{font-size:10.5px;font-weight:700;color:#111;background:var(--amber);border-radius:6px;padding:1px 6px;margin-left:6px}
    .lv2-legend{display:flex;gap:12px;flex-wrap:wrap;font-size:12px;color:var(--muted)}
    .lv2-step{display:grid;grid-template-columns:22px 1fr;gap:8px;padding:8px 10px;border-radius:10px;margin-top:6px;background:var(--sunk);border-left:3px solid var(--c)}
    .lv2-step b{font-size:13.5px}.lv2-step .g{font-size:12.5px;color:var(--c);margin-top:1px}.lv2-step .h{font-size:12px;color:var(--muted);margin-top:2px}
    .lv2-step ul{margin:3px 0 0 16px;padding:0;font-size:12.5px}.lv2-step.done{opacity:.45}.lv2-step input{margin:2px 0 0;cursor:pointer}
    .lv2-sec{font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--faint);margin:12px 0 4px}
  </style>
    <div class="card glow" id="lv-banner" hidden style="margin-bottom:16px"></div>
    <div class="card" style="margin-bottom:14px"><div class="row"><h3 style="margin:0">Маршрут кампании</h3><span class="spacer"></span>
      <span class="small muted" id="lv-who"></span><button class="btn sm" id="lv-cur">📍 Где я сейчас</button></div>
      <div class="lv2-tabs" id="lv-tabs"></div>
      <div class="lv2-legend">${["reward", "quest", "optional", "main", "skip"].map(k => `<span>${ST[k].i} ${ST[k].t}</span>`).join("")}</div>
      <div class="small muted" id="lv-note" style="margin-top:6px"></div></div>
    <div class="split-r"><div class="card"><div id="lv-must"></div><div class="lv2-sec">Маршрут по порядку</div>
      <div class="lv2-route" id="lv-list" style="max-height:calc(100vh - 360px);overflow:auto"></div></div>
    <div class="card glow" id="lv-detail" style="position:sticky;top:0"><div class="empty">Нажми на зону — здесь будет, что в ней сделать. Во время игры путеводитель сам откроет зону, где ты сейчас.</div></div></div>`;
  const $ = s => root.querySelector(s);
  let data = null, chapter = null, selected = null, lastArea = null, poll = null;

  function banner() {
    const st = data.guide_status, b = $("#lv-banner"), rs = data.route_status || {};
    if (rs.running || !data.route_ready) {  // the route comes from the community's speedrun guides — said, with progress
      b.hidden = false;
      b.innerHTML = rs.running ? `<div class="row"><span class="spin"></span><b>Собираю маршрут по гайдам спидранеров…</b><span class="muted small">${esc(rs.step || "")}</span></div>`
        : `<div class="row"><b>Маршрут по гайдам спидранеров ещё не собран</b><span class="spacer"></span><button class="btn primary" id="lv-route">Собрать маршрут</button></div>
           <div class="small muted" style="margin-top:6px">Тула найдёт видео-маршруты спидранеров по каждому акту (YouTube, субтитры) и по их словам отметит: нужна по сюжету, награда, по желанию, пропусти — с авторами. Пока маршрут идёт по данным игры и твоим прохождениям.</div>
           ${rs.error ? `<div class="small" style="color:var(--red);margin-top:6px">${esc(rs.error)}</div>` : ""}`;
      const go = $("#lv-route"); if (go) go.onclick = async () => { await api.post("/api/leveling/route/build"); load(); };
      clearTimeout(poll);
      if (rs.running) poll = setTimeout(load, 5000);
      return;
    }
    if (st.running) {
      b.hidden = false;
      b.innerHTML = `<div class="row"><span class="spin"></span><b>Составляю путеводитель по вики…</b><span class="muted small">${st.done} из ${st.total}</span></div>
        <div class="progress" style="margin-top:8px"><i style="width:${st.total ? 100 * st.done / st.total : 0}%"></i></div>`;
    } else if (!data.guide_ready) {
      b.hidden = false;
      b.innerHTML = `<div class="row"><b>Подсказки по зонам ещё не составлены</b><span class="spacer"></span><button class="btn primary" id="lv-build">Составить</button></div>
        <div class="small muted" style="margin-top:6px">Награды и маршрут уже точные (данные игры). Кнопка добавит к зонам «кого убить и что взять» по статьям poe2wiki — пара минут, один раз.</div>
        ${st.error ? `<div class="small" style="color:var(--red);margin-top:6px">${esc(st.error)}</div>` : ""}`;
      $("#lv-build").onclick = async () => { await api.post("/api/leveling/guide/build?force=true"); load(); };
    } else b.hidden = true;
    clearTimeout(poll);
    if (st.running) poll = setTimeout(load, 4000);
  }

  function tabs() {
    const chs = [...new Set(data.zones.map(chapterOf))];
    $("#lv-tabs").innerHTML = chs.map(ch => {
      const n = data.zones.filter(z => chapterOf(z) === ch && z.rewards.length).length;
      return `<span class="lv2-tab ${ch === chapter ? "on" : ""}" data-ch="${ch}">${chapterName(ch)}${n ? `<span class="n">⭐${n}</span>` : ""}</span>`;
    }).join("");
    root.querySelectorAll("[data-ch]").forEach(t => t.onclick = () => { chapter = t.dataset.ch; render(); });
  }

  function render() {
    tabs();
    const zs = data.zones.filter(z => chapterOf(z) === chapter);
    const must = zs.flatMap(z => z.rewards.map(r => ({z, r})));
    const tm = (data.times || {})[chapter];
    const clock = m => m >= 60 ? `${Math.floor(m / 60)} ч ${m % 60} мин` : `${m} мин`;
    const pen = Math.min(...zs.map(z => z.res_penalty ?? 0));
    const penHtml = pen < 0 ? `<div class="small" style="margin-bottom:8px" title="штраф игры к стихийным сопротивлениям по прогрессу (вики PoE2): кап 75 % считается уже после него">🛡 Штраф к стихийным сопротивлениям здесь: <b class="down">${pen}%</b> — держи огонь, холод и молнию с запасом на эту величину</div>` : "";
    $("#lv-must").innerHTML = penHtml + (tm ? `<div class="small muted" style="margin-bottom:8px" title="из лога игры, перерывы не считаются">⏱ Твои проходы: лучший ${clock(tm.best)} (${esc(tm.best_char)})${tm.runs > 1 ? `, в среднем ${clock(tm.avg)}` : ""}. Больше всего времени ушло: ${tm.slowest.map(s => `${esc(s.name)} ${s.min} мин`).join(", ")}</div>` : "") + (must.length ? `<div class="lv2-sec">Нельзя пропустить — постоянные награды</div><div class="small" style="margin-bottom:6px">За главу: <b>${esc(totals(zs))}</b></div>
      <div class="lv2-must">${must.map(({z, r}) => `<div class="lv2-rw" data-id="${z.id}"><b>⭐ ${esc(r)}</b><span>${esc(z.name_ru)}</span></div>`).join("")}</div>`
      : `<div class="small muted">Постоянных наград в этой главе нет — просто беги по маршруту.</div>`);
    $("#lv-list").innerHTML = zs.map(z => {
      const s = ST[z.status] || ST.main;
      return `<div class="lv2-z ${z.status} ${z.id === data.current ? "cur" : ""} ${selected && selected.id === z.id ? "sel" : ""}" data-id="${z.id}" style="--c:${s.c}">
        <div class="dot" title="${s.t}">${s.i}</div>
        <div><div class="nm">${esc(z.name_ru)}${z.id === data.current ? `<span class="lv2-here">ты здесь</span>` : ""}</div>
          ${z.rewards.length ? `<div class="rw">${z.rewards.map(esc).join(" · ")}</div>` : z.status === "quest" ? `<div class="sub">🔑 ${esc(z.why)}</div>`
            : z.status === "main" && !z.steps.length && (z.kill || z.take.length) ? `<div class="sub">${esc(z.kill || z.take.join(", "))}</div>` : ""}
          ${z.steps.some(s => s.kind === "skip") ? `<div class="sub">⏭ мимо: ${z.steps.filter(s => s.kind === "skip").map(s => esc(s.what)).join(", ")}</div>` : ""}</div>
        <div class="lv">${z.town ? "" : `ур. ${z.level}`}${z.spent_min ? `<div class="tiny faint" title="в среднем в твоих проходах, из лога игры">⏱ ${z.spent_min} мин</div>` : ""}</div></div>`;
    }).join("");
    root.querySelectorAll("[data-id]").forEach(el => el.onclick = () => select(el.dataset.id));
  }

  async function load() {
    data = await api.get("/api/leveling/zones");
    const cur = data.zones.find(z => z.id === data.current);
    $("#lv-who").textContent = data.character ? `в игре: ${data.character} · ур. ${data.level}` : "";
    // a character past the campaign gets ~1% experience here: say what the guide is for instead of «XP 1%» on every zone
    $("#lv-note").textContent = data.level >= 65 && !cur ? `${data.character} уже прошёл кампанию — путеводитель пригодится для следующего персонажа.` : "";
    if (!chapter || (cur && data.current !== lastArea)) chapter = cur ? chapterOf(cur) : chapterOf(data.zones[0]);
    render();
    if (cur && data.current !== lastArea) { select(cur.id); root.querySelector(".lv2-z.cur")?.scrollIntoView({block: "center"}); }
    lastArea = data.current;
    banner();
  }

  function select(id) {
    selected = data.zones.find(z => z.id === id);
    if (chapterOf(selected) !== chapter) chapter = chapterOf(selected);
    render();
    const z = selected, s = ST[z.status] || ST.main;
    const xp = z.xp != null && z.xp < 95 && z.xp > 1 ? `<span class="tag ${z.xp < 50 ? "red" : "amber"}" title="Множитель опыта для уровня персонажа в игре">опыт ×${z.xp}%</span>` : "";
    $("#lv-detail").innerHTML = `<div class="row"><h3 style="margin:0">${esc(z.name_ru)}</h3><span class="tag">ур. ${z.level}</span>${xp}</div>
      ${z.name_ru !== z.name ? `<div class="tiny faint">${esc(z.name)}</div>` : ""}
      <div class="kb ${{reward: "reward", quest: "item", skip: "skip"}[z.status] || "info"}" style="margin-top:10px"><span class="ki">${s.i}</span>
        <div class="kt"><b class="kh">${{town: "Город", reward: "Обязательно зайди", quest: "Нужна по заданию", optional: "По желанию", main: "По пути", skip: "Можно пропустить"}[z.status]}</b>${esc(z.why || "")}</div></div>
      ${z.route_tip ? `<div class="lv-r go" style="margin-top:6px">💡 ${esc(z.route_tip)}</div>` : ""}
      ${z.steps.length ? `<div class="lv2-sec">Что делать в локации</div>${stepRows(z)}` : ""}
      ${z.rewards.filter(r => !z.steps.some(s => s.gives && r.startsWith(s.gives))).map(r => `<div class="lv-r reward" style="margin-top:6px">⭐ <b>${esc(r)}</b></div>`).join("")}
      ${!z.steps.length && z.kill ? `<div class="lv-r boss" style="margin-top:6px">⚔ ${esc(z.kill)}</div>` : ""}
      ${z.take.map(t => `<div class="lv-r take" style="margin-top:4px">📦 ${esc(t)}</div>`).join("")}
      ${z.danger ? `<div class="lv-r warn" style="margin-top:4px">⚠ ${esc(z.danger)}</div>` : ""}
      ${z.sources.length ? `<div class="tiny faint" style="margin-top:8px">Маршрут по видео: ${z.sources.map(s => `<a href="${esc(s.url)}" target="_blank">${esc(s.author || s.title)}</a>`).join(" · ")}</div>` : ""}
      <div class="tiny faint" style="margin-top:8px"><a href="act-overlay.html?area=${esc(z.id)}" target="_blank">Как это выглядит в окне поверх игры</a></div>
      ${z.exits.length ? `<div class="small muted" style="margin:10px 0">Выходы: ${z.exits.map(esc).join(" · ")}${z.go ? ` · <b>дальше:</b> ${esc(z.go)}` : ""}</div>` : ""}
      <details style="margin-top:6px"><summary class="small muted">Мои заметки и подробности от ИИ</summary>
        <div class="field" style="margin-top:8px"><textarea class="inp" id="lv-tip" rows="2" placeholder="напр. взять книгу у NPC, не забыть ключ">${esc(z.tip)}</textarea></div>
        <div class="row"><button class="btn sm" id="lv-save">Сохранить заметку</button><span class="spacer"></span><button class="btn sm primary" id="lv-ai">✦ Подробнее от ИИ</button></div>
        <div class="md small" id="lv-out" style="margin-top:12px"></div></details>`;
    $("#lv-detail").querySelectorAll("[data-step]").forEach(c => c.onchange = () => { setDone(z, +c.dataset.step, c.checked); c.closest(".lv2-step").classList.toggle("done", c.checked); });
    $("#lv-save").onclick = async () => { await api.post("/api/leveling/tip", {zone_id: z.id, text: $("#lv-tip").value}); toast("ok", "Сохранено"); z.tip = $("#lv-tip").value; };
    $("#lv-ai").onclick = async () => {
      let acc = ""; const out = $("#lv-out"); out.innerHTML = `<div class="skel"></div>`;
      await stream(`/api/leveling/advice/${z.id}`, {}, {onReplace: t => { acc = t; out.innerHTML = md(acc); }, onText: t => { acc += t; out.innerHTML = md(acc); }, onError: e => out.innerHTML += `<p style="color:var(--red)">${esc(e)}</p>`});
    };
  }
  $("#lv-cur").onclick = () => { lastArea = null; load(); };
  onLive(st => { if (data && st.log && st.log.area && st.log.area !== lastArea) load(); });
  registerModule({id: "leveling", onShow: () => { if (!data) load(); }});
})();
