(function () {
  "use strict";
  const {api, esc, fmt, md, stream, spinBtn, registerModule, toast} = window.P2;
  const root = document.getElementById("pob-root");
  const LABEL = {CombinedDPS: "Общий DPS", TotalDPS: "DPS скилла", FullDPS: "Полный DPS", TotalDot: "Урон со временем", MinionCombinedDPS: "DPS одного приспешника", ActiveMinionLimit: "Приспешников одновременно", ActiveTotemLimit: "Тотемов одновременно", Life: "Здоровье",
    EnergyShield: "Энергощит", Mana: "Мана", Spirit: "Дух", Armour: "Броня", Evasion: "Уклонение", TotalEHP: "EHP",
    FireResist: "Сопр. огню", ColdResist: "Сопр. холоду", LightningResist: "Сопр. молнии", ChaosResist: "Сопр. хаосу",
    PhysicalMaximumHitTaken: "Макс. физ. удар", EffectiveMovementSpeedMod: "Скорость движения", BlockChance: "Блок",
    CritChance: "Шанс крита", Speed: "Скорость атаки/каста"};
  const big = n => n >= 1e6 ? (n / 1e6).toFixed(2) + "M" : n >= 1e4 ? (n / 1e3).toFixed(1) + "k" : Math.round(n).toLocaleString("ru");

  root.innerHTML = `
    <div class="grid g3">
      <div class="card glow" style="grid-column:span 2"><h3>Билд</h3>
        <div class="row"><input class="inp" id="pb-code" placeholder="PoB-код или ссылка pobb.in — или нажми «Copy PoB» на poe.ninja/Maxroll/Mobalytics, тула подхватит сама" style="flex:1">
          <button class="btn primary" id="pb-calc">Посчитать</button></div>
        <div class="row small muted" style="margin-top:10px">Найти билды:
          <a href="https://poe.ninja/poe2/builds" target="_blank">poe.ninja/builds ↗</a>
          <a href="https://maxroll.gg/poe2/build-guides" target="_blank">Maxroll ↗</a>
          <a href="https://mobalytics.gg/poe-2/builds" target="_blank">Mobalytics ↗</a>
          <a href="https://pobb.in" target="_blank">pobb.in ↗</a>
          <span class="faint">→ «Copy PoB / Export» → вернись сюда</span></div></div>
      <div class="card"><h3>Движок PoB</h3><div id="pb-status" class="small"></div></div>
    </div>
    <div class="split-r" style="margin-top:16px">
      <div class="grid">
        <div class="card" id="pb-result"><div class="empty">Загрузи билд — посчитаю его настоящим движком Path of Building: DPS, EHP, резисты, максимальный удар по типам урона.</div></div>
        <div class="card"><h3>Сравнить предмет (как наведение в PoB)</h3>
          <textarea class="inp" id="pb-item" rows="6" placeholder="Вставь предмет (Ctrl+C в игре или с трейда) — покажу, что изменится в билде"></textarea>
          <div class="row" style="margin-top:8px"><select class="inp" id="pb-slot" style="width:auto"><option value="">Слот: авто</option>
            ${[["Weapon 1", "Оружие"], ["Weapon 2", "Вторая рука"], ["Helmet", "Шлем"], ["Body Armour", "Нагрудник"], ["Gloves", "Перчатки"], ["Boots", "Ботинки"], ["Amulet", "Амулет"], ["Ring 1", "Кольцо 1"], ["Ring 2", "Кольцо 2"], ["Belt", "Пояс"]].map(([v, t]) => `<option value="${v}">${t}</option>`).join("")}</select>
            <span class="spacer"></span><button class="btn primary" id="pb-cmp">Сравнить</button></div>
          <div id="pb-diff" style="margin-top:12px"></div></div>
        <div class="card" style="border-color:color-mix(in srgb,var(--k-money) 45%,transparent)"><div class="sec-h" style="--k:var(--k-money)"><span class="si">💰</span>
            <div><h3>Лучшие покупки на бюджет</h3><div class="sd">лоты трейда по всем слотам, каждый посчитан в PoB; подбираю набор с максимальным приростом на твою сумму — сильные вещи не трогаю</div></div></div>
          <div class="row"><input class="inp" id="pb-b-amt" type="number" min="0" step="1" placeholder="сумма" style="width:120px"><button id="pb-b-cur" style="width:170px"></button>
            <button class="btn primary" id="pb-b-go">Подобрать</button><span class="small muted" id="pb-b-prog"></span></div>
          <div id="pb-b-out" style="margin-top:12px"></div></div>
        <div class="card"><h3>📈 Найти апгрейд по PoB</h3>
          <div class="small muted" style="margin-bottom:8px">Беру лоты с трейда в рамках бюджета, прогоняю каждый через PoB на твоём билде и сортирую по реальному приросту урона и защиты на 1 div. Резисты и атрибуты текущего предмета сохраняются в фильтрах, чтобы замена ничего не сломала.</div>
          <div class="row"><select class="inp" id="pb-up-slot" style="width:auto">${[["Weapon 1", "Оружие"], ["Weapon 2", "Вторая рука"], ["Weapon 1 Swap", "Оружие, набор 2"], ["Weapon 2 Swap", "Вторая рука, набор 2"], ["Helmet", "Шлем"], ["Body Armour", "Нательник"], ["Gloves", "Перчатки"], ["Boots", "Ботинки"], ["Amulet", "Амулет"], ["Ring 1", "Кольцо 1"], ["Ring 2", "Кольцо 2"], ["Belt", "Пояс"]].map(([v, l]) => `<option value="${v}">${l}</option>`).join("")}</select>
            <input class="inp" id="pb-up-budget" placeholder="бюджет: 2 div (пусто — кошелёк персонажа)" style="flex:1">
            <button class="btn primary" id="pb-up-go">Найти</button></div>
          <div id="pb-up-out" style="margin-top:12px"></div></div>
      </div>
      <div class="grid">
        <div class="card"><div class="row"><h3 style="margin:0">Мои билды PoB</h3><span class="spacer"></span><button class="btn sm" id="pb-open">Открыть PoB</button></div>
          <div class="tiny faint" style="margin:6px 0 10px">Папка Documents\\Path of Building (PoE2)\\Builds — то, что сохраняешь в PoB, видно здесь.</div>
          <div id="pb-builds" class="sessions"></div></div>
        <div class="card"><div class="row"><h3 style="margin:0">✦ ИИ-разбор по цифрам PoB</h3><span class="spacer"></span><span class="tiny faint" id="pb-who"></span></div>
          <div id="pb-goal" style="margin:10px 0"></div>
          <button class="btn primary" id="pb-ai" style="width:100%" disabled>Разобрать билд</button>
          <div class="md small" id="pb-out" style="margin-top:12px"></div></div>
      </div>
    </div>`;
  const $ = s => root.querySelector(s);
  let src = null;

  function statGrid(stats) {
    // «Full DPS 0» / «DoT DPS 0» read as broken: they are 0 when PoB has no skill marked for Full DPS / the build deals no DoT
    const keys = Object.keys(LABEL).filter(k => stats[k] != null && !(["FullDPS", "TotalDot", "MinionCombinedDPS", "BlockChance"].includes(k) && !stats[k]));
    return `<div class="grid g4">${keys.map(k => {
      let v = stats[k], cls = "";
      if (/Resist$/.test(k)) { cls = v >= 75 ? "up" : k === "ChaosResist" ? "" : "down"; v = v.toFixed(0) + "%"; }
      else if (k === "EffectiveMovementSpeedMod") v = (v * 100).toFixed(0) + "%";
      else if (k === "CritChance") v = v.toFixed(1) + "%";
      else if (k === "Speed") v = v.toFixed(2) + "/с";
      else v = big(v);
      return `<div class="stat"><b class="${cls}" style="font-size:19px">${v}</b><span>${LABEL[k]}</span></div>`;
    }).join("")}</div>`;
  }

  async function calc(s) {
    src = s;
    const btn = $("#pb-calc"); spinBtn(btn, true, "PoB считает…");
    $("#pb-result").innerHTML = `<div class="skel"></div><div class="skel"></div><div class="skel"></div>`;
    try {
      const r = await api.post("/api/pob/calc", s);
      const main = r.skills.find(x => x.main) || r.skills[0];
      $("#pb-result").innerHTML = `<div class="row"><h3 style="margin:0">${esc(r.title_ru || r.ascendancy || r.class || "Билд")} · ур. ${r.level || "?"}</h3><span class="spacer"></span>
          <button class="btn sm" id="pb-save">В PoB</button><button class="btn sm" id="pb-kb">В базу знаний</button></div>
        ${main ? `<div class="small muted" style="margin:6px 0 14px">Основной скилл: <b>${esc((main.gems_ru || main.gems).join(" + "))}</b></div>` : ""}
        ${statGrid(r.stats)}
        <div class="hr"></div><div class="small">${r.skills.filter(x => x.gems.length).map(x => `<div style="padding:2px 0">${x.main ? "★ " : ""}<span class="faint">${esc(x.slot_ru || x.slot || "")}</span> ${esc((x.gems_ru || x.gems).join(" + "))}</div>`).join("")}</div>`;
      $("#pb-ai").disabled = false;
      $("#pb-save").onclick = async () => { const name = await window.P2.dialog({title: "Сохранить в Path of Building", text: "Билд появится в списке PoB (File → Open).",
        input: {value: `${r.ascendancy || r.class} ${r.level}`}, ok: "Сохранить"}); if (!name) return;
        const x = await api.post("/api/pob/save", {...src, name}); toast("ok", "Сохранено в PoB", x.path); loadBuilds(); };
      $("#pb-kb").onclick = async () => { const x = await api.post("/api/pob/to_kb", {...src, name: `${r.ascendancy || r.class} ${r.level}`}); toast("ok", "В базе знаний", `${x.count} фрагм.`); };
    } catch (e) { $("#pb-result").innerHTML = `<div style="color:var(--red)">${esc(e.message)}</div>`; }
    spinBtn(btn, false);
  }

  async function loadBuilds() {
    const [st, list] = await Promise.all([api.get("/api/pob/status"), api.get("/api/pob/builds")]);
    $("#pb-status").innerHTML = st.installed ? `<span class="tag green">PoB ${esc(st.version || "")}</span> ${st.running ? `<span class="tag">движок запущен</span>` : `<span class="tag">запустится по запросу</span>`}
      <div class="tiny faint" style="margin-top:6px">${esc(st.dir)}<br>расчётов: ${st.calls}</div>${st.last_error ? `<div class="tiny" style="color:var(--red)">${esc(st.last_error.slice(0, 200))}</div>` : ""}`
      : `<span class="tag red">PoB не найден</span><div class="tiny faint">Укажи POB_DIR в настройках</div>`;
    // the numbers come from the tool's own measurement on the damage set; the file's own are PoB's of whatever set was open at saving
    const nums = (n, saved) => `${+n.dps ? ` · DPS ${big(+n.dps)}` : ""}${n.life ? ` · Life ${big(+n.life)}` : ""}${saved && (+n.dps || n.life) ? ` <span class="faint" title="как записал PoB при сохранении: набор оружия может быть не тот, что наносит урон">(из файла)</span>` : ""}`;
    $("#pb-builds").innerHTML = list.map(b => `<div class="sess" data-f="${esc(b.file)}"><b>${esc(b.name)}</b><span>${esc(b.ascendancy || b.class || "")} ${b.level || ""}${b.problem ? ` · <span class="down">⚠ ${esc(b.problem)}</span>` : `<span class="pb-n"> · считаю…</span>`}</span></div>`).join("")
      || `<div class="faint small">Пусто. Сохрани билд в PoB или нажми «В PoB» после расчёта.</div>`;
    root.querySelectorAll("[data-f]").forEach(el => el.onclick = () => calc({file: el.dataset.f}));
    const measured = await api.get("/api/pob/builds/measured").catch(() => ({}));
    list.forEach(b => {
      const el = [...root.querySelectorAll("[data-f]")].find(x => x.dataset.f === b.file)?.querySelector(".pb-n");
      if (el) el.innerHTML = measured[b.file] ? nums(measured[b.file], false) : nums(b, true);
    });
  }

  $("#pb-calc").onclick = () => { const v = $("#pb-code").value.trim(); if (v) calc({code: v}); };
  $("#pb-open").onclick = () => api.post("/api/pob/open").catch(e => toast("err", "PoB", e.message));
  $("#pb-cmp").onclick = async e => {
    if (!src) { toast("info", "Сначала загрузи билд"); return; }
    const btn = e.currentTarget; spinBtn(btn, true, "…");
    try {
      const r = await api.post("/api/pob/compare", {...src, item_text: $("#pb-item").value, slot: $("#pb-slot").value});
      $("#pb-diff").innerHTML = `<div class="small muted" style="margin-bottom:6px">${esc(r.item.name)} → слот <b>${esc(r.slot)}</b></div>` + (r.diff.length
        ? `<table class="tbl"><tbody>${r.diff.map(d => `<tr><td>${LABEL[d.stat] || d.stat}</td><td class="num">${big(d.before)}</td><td class="num">${big(d.after)}</td>
            <td class="num ${d.delta >= 0 ? "up" : "down"}">${d.delta >= 0 ? "+" : ""}${big(d.delta)}${d.pct != null ? ` (${d.pct >= 0 ? "+" : ""}${d.pct.toFixed(1)}%)` : ""}</td></tr>`).join("")}</tbody></table>`
        : `<div class="faint small">Ключевые статы не изменились</div>`);
    } catch (err) { $("#pb-diff").innerHTML = `<div style="color:var(--red)">${esc(err.message)}</div>`; }
    spinBtn(btn, false);
  };
  $("#pb-ai").onclick = async () => {
    let acc = ""; const out = $("#pb-out"); out.innerHTML = `<div class="skel"></div>`;
    await stream("/api/pob/analyze", {...src, goal: window.P2.selectValue($("#pb-goal"), "goal")}, {onProvider: p => $("#pb-who").textContent = p,
      onText: t => { acc += t; out.innerHTML = md(acc); }, onReplace: t => { acc = t; out.innerHTML = md(acc); }, onError: e => out.innerHTML += `<p style="color:var(--red)">${esc(e)}</p>`});
  };
  async function upgrade(spec = {}) {
    if (spec.slot) $("#pb-up-slot").value = spec.slot.replace(/^Ring$/, "Ring 1");
    if (spec.budget) $("#pb-up-budget").value = spec.budget;
    const btn = $("#pb-up-go"), out = $("#pb-up-out");
    spinBtn(btn, true, "Ищу и считаю в PoB…");
    out.innerHTML = `<div class="skel"></div><div class="skel"></div><div class="skel"></div>`;
    out.scrollIntoView({behavior: "smooth", block: "nearest"});
    try {
      const r = await api.post("/api/pob/upgrades", {...(src || {}), slot: $("#pb-up-slot").value, mods: spec.mods || [], budget: $("#pb-up-budget").value.trim()});
      const fastSet = r.role && r.role !== "damage";
      out.innerHTML = `${r.role_ru ? `<div class="kb info" style="margin-bottom:6px"><span class="ki">⚔</span><div class="kt">Этот набор оружия: <b>${esc(r.role_ru)}</b>. ${fastSet ? "Лоты сравниваются по скорости, а не по урону." : "Лоты сравниваются по урону на этом наборе."}</div></div>` : ""}<div class="small muted" style="margin-bottom:6px">Сейчас в слоте: <b>${esc(r.current || "пусто")}</b> · фильтры: ${r.filters.map(esc).join(" · ")}
          · <a href="${esc(r.url)}" target="_blank">открыть поиск ↗</a></div>
        <table class="tbl"><thead><tr><th>Лот</th><th style="text-align:right">Цена</th><th style="text-align:right">${fastSet ? "Скорость" : "DPS"}</th><th style="text-align:right">EHP</th><th style="text-align:right">Выгода/div</th><th></th></tr></thead><tbody>
        ${r.rows.filter(x => x.score > 0).map(x => `<tr><td>${esc(x.name || "")} <span class="faint">${esc(x.base || "")}</span>${x.notes.length ? `<div class="tiny" style="color:var(--red)">${x.notes.map(esc).join("; ")}</div>` : ""}
            <div class="tiny muted">${(x.mods_ru || x.mods).slice(0, 3).map(esc).join(" · ")}</div></td>
          <td class="num">${esc(x.price)}</td>${(v => `<td class="num ${v >= 0 ? "up" : "down"}">${v ? (v > 0 ? "+" : "") + v.toFixed(1) + "%" : "0"}</td>`)(fastSet ? (x.speed_pct || 0) : x.dps_pct)}
          <td class="num ${x.ehp_pct >= 0 ? "up" : "down"}">${x.ehp_pct ? (x.ehp_pct > 0 ? "+" : "") + x.ehp_pct.toFixed(1) + "%" : "0"}</td>
          <td class="num"><b>${x.score > 0 ? x.per_div.toFixed(1) : "—"}</b></td>
          <td>${x.whisper ? `<button class="btn sm" data-wh="${esc(x.whisper)}" title="Скопировать сообщение продавцу">✉</button>` : ""}</td></tr>`).join("") || `<tr><td colspan="6" class="muted">В этом бюджете нет лотов сильнее твоего предмета (замер PoB) — подними бюджет или оставь как есть</td></tr>`}</tbody></table>
        ${r.rows.some(x => x.score <= 0) ? `<details class="small muted" style="margin-top:6px"><summary>Хуже твоего предмета: ${fmt.n(r.rows.filter(x => x.score <= 0).length, "лот|лота|лотов")} (не брать)</summary>
          ${r.rows.filter(x => x.score <= 0).map(x => `<div class="tiny">${esc(x.name || "")} ${esc(x.base || "")} — ${esc(x.price)}: DPS ${x.dps_pct.toFixed(1)}%, EHP ${x.ehp_pct.toFixed(1)}%</div>`).join("")}</details>` : ""}`;
      out.querySelectorAll("[data-wh]").forEach(b => b.onclick = () => { navigator.clipboard?.writeText(b.dataset.wh); toast("ok", "Сообщение продавцу скопировано", "в игре: Enter → Ctrl+V → Enter"); });
    } catch (e) { out.innerHTML = `<div style="color:var(--red)">${esc(e.message)}</div>`; }
    spinBtn(btn, false);
  }
  $("#pb-up-go").onclick = () => upgrade();

  let curPick = null;
  $("#pb-b-go").onclick = async e => {
    const amount = +$("#pb-b-amt").value;
    if (!amount) { toast("info", "Впиши сумму"); return; }
    const btn = e.currentTarget, out = $("#pb-b-out");
    spinBtn(btn, true, "Ищу и считаю…");
    out.innerHTML = `<div class="skel"></div><div class="skel"></div><div class="small muted">Это 1–3 минуты: трейд отдаёт лоты с паузами (лимиты GGG), каждый лот считается в PoB.</div>`;
    const prog = setInterval(async () => { try { const p = await api.get("/api/pob/budget/progress"); if (p.running) $("#pb-b-prog").textContent = `слот ${p.slot || "…"} · ${p.done}/${p.total}`; } catch (_) {} }, 1500);
    try {
      const r = await api.post("/api/pob/budget", {...(src || {}), amount, currency: curPick ? curPick.value : "divine"});
      const t = r.total;
      out.innerHTML = `<div class="kb ${t.dps >= 0 && t.ehp >= 0 ? "node" : "warn"}"><span class="ki">🧪</span><div class="kt"><b class="kh">Итог в PoB, если купить всё</b>
          DPS <b class="${t.dps >= 0 ? "up" : "down"}">${t.dps >= 0 ? "+" : ""}${t.dps}%</b> · EHP <b class="${t.ehp >= 0 ? "up" : "down"}">${t.ehp >= 0 ? "+" : ""}${t.ehp}%</b>
          · потрачено <b>${r.spent_div}</b> из ${r.budget_div} div</div></div>
        ${r.picks.map(p => `<div class="pb-pick">${p.icon ? `<img src="${esc(p.icon)}">` : ""}<div style="flex:1;min-width:0"><b>${esc(p.slot)}: ${esc(p.name || "")}</b> <span class="faint">${esc(p.base || "")}</span>
            <div class="small"><span class="pill money">${esc(p.price)}</span> DPS <b class="${p.dps_pct >= 0 ? "up" : "down"}">${p.dps_pct >= 0 ? "+" : ""}${(p.dps_pct || 0).toFixed(1)}%</b> · EHP <b class="${p.ehp_pct >= 0 ? "up" : "down"}">${p.ehp_pct >= 0 ? "+" : ""}${(p.ehp_pct || 0).toFixed(1)}%</b></div>
            <div class="tiny muted">${(p.mods_ru || p.mods || []).slice(0, 4).map(esc).join(" · ")}</div>
            ${p.craft && p.craft.cheaper ? `<div class="tiny" style="color:#fcd34d">⚒ дешевле скрафтить: ≈ ${p.craft.cost_div} div (${esc(p.craft.method)})</div>`
              : p.craft && p.craft.cheaper_if_base_ex ? `<div class="tiny muted">⚒ скрафтить ≈ ${p.craft.cost_div} div без белых баз — дешевле, если база ≤ ${p.craft.cheaper_if_base_ex} ex</div>` : ""}</div>
          <div class="row" style="flex-direction:column;gap:4px">${p.whisper ? `<button class="btn sm primary" data-wh="${esc(p.whisper)}">✉ Написать продавцу</button>` : ""}
            ${p.craft ? `<button class="btn sm" data-p2act="craft" data-spec="${esc(JSON.stringify({base: p.base, slot: p.slot, mods: p.craft.mods}))}">⚒ Крафт</button>` : ""}</div></div>`).join("")
          || `<div class="kb info"><span class="ki">ℹ</span><div class="kt">На эту сумму на рынке нет вещей лучше твоих.</div></div>`}
        ${r.keep.length ? `<div class="bv-sgh" style="--k:var(--k-node);margin-top:10px">Не трогать</div>${r.keep.map(k => `<div class="small" style="padding:2px 0">✓ <b>${esc(k.slot)}</b> — ${esc(k.why)}</div>`).join("")}` : ""}`;
      out.querySelectorAll("[data-wh]").forEach(b => b.onclick = () => { navigator.clipboard?.writeText(b.dataset.wh); toast("ok", "Сообщение продавцу скопировано", "в игре: Enter → Ctrl+V → Enter"); });
    } catch (err) { out.innerHTML = `<div class="kb warn"><span class="ki">⚠</span><div class="kt">${esc(err.message)}</div></div>`; }
    clearInterval(prog); $("#pb-b-prog").textContent = "";
    spinBtn(btn, false);
  };

  registerModule({id: "pob", upgrade, onShow: async () => {
    if (!curPick) {
      curPick = await window.P2.currencyPicker($("#pb-b-cur"), {value: "divine"});
      try { const pr = await api.get("/api/character/profiles"); const a = pr.profiles.find(p => p.id === pr.active);
        if (a && a.budget_amount) { $("#pb-b-amt").value = a.budget_amount; curPick.set(a.budget_currency || "divine"); } } catch (_) {}
    }
    const c0 = await window.P2.choices();
    if (c0.main_build && (!src || src.file !== c0.main_build) && !(src && src.code)) calc({file: c0.main_build});
    if (!$("#pb-goal select")) {
      const c = await window.P2.choices();
      $("#pb-goal").innerHTML = window.P2.selectHtml("goal", c.goals.audit, {custom: true, empty: "— цель —", placeholder: "своя цель"});
      window.P2.wireSelects($("#pb-goal"));
    }
    loadBuilds();
  }, load: code => { $("#pb-code").value = code; calc({code}); }});
})();
