(function () {
  "use strict";
  const {api, esc, md, registerModule} = window.P2;
  const root = document.getElementById("history-root");
  const KEY = "p2.history.section";
  let sections = [], cur = null;
  const when = t => t ? new Date(t * 1000).toLocaleString("ru", {day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit"}) : "—";
  const remember = k => { try { localStorage.setItem(KEY, k); } catch (_) { /* a private window: the first section then */ } };
  const recalled = () => { try { return localStorage.getItem(KEY); } catch (_) { return null; } };

  async function load() {
    try { sections = await api.get("/api/history"); }
    catch (e) { root.innerHTML = `<div class="card" style="color:var(--red)">${esc(e.message)}</div>`; return; }
    const keep = cur || recalled();
    cur = (sections.find(s => s.kind === keep && s.count) || sections.find(s => s.count) || sections[0] || {}).kind;
    list();
  }

  function tabs() {
    return `<div class="card"><div class="small muted" style="margin-bottom:8px">Всё, что тула сгенерировала по твоим запросам, по вкладкам. Номер — порядок, в котором это было сделано; нажми на блок — откроется полностью.</div>
      <div class="row" style="gap:6px;flex-wrap:wrap">${sections.map(s => `<button class="btn sm ${s.kind === cur ? "primary" : ""}" data-k="${s.kind}" ${s.count ? "" : "disabled"}>${esc(s.title)} <span class="tiny faint">${s.count}</span></button>`).join("")}</div></div>`;
  }

  async function list() {
    const sec = sections.find(s => s.kind === cur);
    root.innerHTML = tabs() + `<div class="card"><div class="skel"></div></div>`;
    wireTabs();
    if (!sec || !sec.count) { root.innerHTML = tabs() + `<div class="card empty">Здесь пока ничего нет: всё, что ты закажешь в этой вкладке, появится здесь само.</div>`; wireTabs(); return; }
    let rows;
    try { rows = await api.get(`/api/history/${encodeURIComponent(cur)}`); }
    catch (e) { root.innerHTML = tabs() + `<div class="card" style="color:var(--red)">${esc(e.message)}</div>`; wireTabs(); return; }
    root.innerHTML = tabs() + `<div class="grid g2" style="margin-top:12px">${rows.map(r => `<div class="card h-item" data-id="${esc(r.id)}" style="cursor:pointer">
        <div class="row" style="gap:8px"><span class="pill reward">№ ${r.n}</span><span class="tiny faint">${when(r.t)}</span><span class="spacer"></span>${r.count > 1 ? `<span class="tag">${window.P2.fmt.n(r.count, "ответ|ответа|ответов")}</span>` : ""}</div>
        <b style="display:block;margin:6px 0 4px">${esc(r.title)}</b><div class="small muted">${esc(r.preview || "")}</div></div>`).join("")}</div>`;
    wireTabs();
    root.querySelectorAll(".h-item").forEach(el => el.onclick = () => article(el.dataset.id));
  }

  function wireTabs() {
    root.querySelectorAll("[data-k]").forEach(b => b.onclick = () => { cur = b.dataset.k; remember(cur); list(); });
  }

  async function article(id) {
    root.innerHTML = tabs() + `<div class="card"><div class="skel"></div></div>`;
    wireTabs();
    let a;
    try { a = await api.get(`/api/history/${encodeURIComponent(cur)}/${encodeURIComponent(id)}`); }
    catch (e) { root.innerHTML = tabs() + `<div class="card" style="color:var(--red)">${esc(e.message)}</div>`; wireTabs(); return; }
    const parts = (a.parts || []).map(p => p.role === "user"
      ? `<div class="kb info" style="margin:12px 0"><span class="ki">❓</span><div class="kt"><b class="kh">Запрос</b>${esc(p.text).slice(0, 4000)}</div></div>`
      : `<div style="margin:12px 0">${p.provider ? `<div class="tiny faint">✦ ${esc(p.provider)}</div>` : ""}<div class="md">${md(p.text)}</div></div>`).join("");
    const steps = (a.steps || []).length ? `<h3 style="margin-top:18px">План по шагам</h3>${a.steps.map((s, i) => `<div style="margin:8px 0"><b>${s.done ? "✅" : "▫"} ${i + 1}. ${esc(s.title || "")}</b><div class="md small">${md(s.text || "")}</div></div>`).join("")}` : "";
    const sec = sections.find(s => s.kind === cur) || {};
    root.innerHTML = tabs() + `<article class="card glow" style="margin-top:12px;padding:22px 24px">
      <div class="row" style="gap:8px;flex-wrap:wrap"><button class="btn sm ghost h-back">← к списку</button><span class="spacer"></span>
        <button class="btn sm primary h-open">Открыть во вкладке «${esc(sec.title || a.section)}»</button></div>
      <div class="tiny faint" style="margin-top:12px">${esc(a.section)} · № ${a.n} · ${when(a.t)}</div>
      <h2 style="margin:4px 0 8px">${esc(a.title)}</h2>
      ${a.request ? `<div class="small muted">Запрос: ${esc(a.request)}</div>` : ""}
      ${parts || `<div class="muted small" style="margin-top:12px">Ответов в этой записи нет.</div>`}${steps}</article>`;
    wireTabs();
    root.querySelector(".h-back").onclick = list;
    root.querySelector(".h-open").onclick = () => a.session ? window.P2.openSession(a.tab, cur, a.session) : window.P2.go(a.tab);
  }

  registerModule({id: "history", onShow: load});
})();
