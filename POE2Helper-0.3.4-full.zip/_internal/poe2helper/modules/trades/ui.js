(function () {
  "use strict";
  const {api, esc, toast, registerModule, onLive} = window.P2;
  const root = document.getElementById("trades-root");
  const STATUS = {new: "новый", invited: "приглашён", done: "продано", declined: "отказ"};
  const STEPS = [["invite", "👥 Пригласить"], ["trade", "🤝 Обмен"], ["busy", "⏳ Занят"], ["sold", "✖ Продано"], ["thanks", "🙏 Спасибо"], ["kick", "🚪 Выгнать"]];

  async function load() {
    let d;
    try { d = await api.get("/api/trades"); } catch (e) { root.innerHTML = `<div class="card" style="color:var(--red)">${esc(e.message)}</div>`; return; }
    const head = `<div class="card"><div class="small muted">Тула читает шёпоты из лога игры: кто пишет купить, что, за сколько и в какой ячейке тайника.
      Кнопка копирует одну команду — в игре: <b>Enter → Ctrl+V → Enter</b> (по правилам GGG тула сама ничего в игру не вводит).</div></div>`;
    if (!d.offers.length) {
      root.innerHTML = head + `<div class="card"><div class="muted">Пока никто не писал купить. Новый покупатель появится здесь сам, с уведомлением.</div></div>`;
      return;
    }
    root.innerHTML = head + d.offers.map(o => `<div class="card ${o.status === "new" ? "glow" : ""}" style="opacity:${["done", "declined"].includes(o.status) ? .55 : 1}">
      <div class="row" style="gap:10px;flex-wrap:wrap"><b>${esc(o.buyer)}</b><span class="tag">${STATUS[o.status] || o.status}</span>
        ${o.joined ? `<span class="tag" style="color:var(--green)">● в убежище</span>` : ""}<span class="spacer"></span><span class="tiny faint">${esc(o.time)}</span></div>
      <div style="margin:8px 0"><b>${esc(o.item)}</b> за <span class="pill money">${esc(String(o.amount))} ${esc(o.currency)}</span>
        <span class="small muted">· ${esc(o.league)}${o.tab ? ` · вкладка «${esc(o.tab)}», ${o.x} столбец, ${o.y} ряд` : ""}</span></div>
      <div class="row" style="gap:6px;flex-wrap:wrap">${STEPS.map(([k, l]) => `<button class="btn sm" data-cmd="${esc(o.commands[k])}" data-id="${o.id}" data-k="${k}">${l}</button>`).join("")}</div>
    </div>`).join("");
    root.querySelectorAll("[data-cmd]").forEach(b => b.onclick = async () => {
      await navigator.clipboard?.writeText(b.dataset.cmd);
      toast("ok", "Команда скопирована", `${b.dataset.cmd} — в игре: Enter → Ctrl+V → Enter`);
      const next = {invite: "invited", sold: "declined", thanks: "done"}[b.dataset.k];
      if (next) { try { await api.post(`/api/trades/${b.dataset.id}/status`, {status: next}); load(); } catch (_) { /* the list stays */ } }
    });
  }

  let seen = null;
  onLive(st => {
    const t = st.trades;
    if (!t) return;
    if (seen !== null && t.v !== seen && t.last && t.last.status === "new") {
      toast("ok", `💬 ${t.last.buyer} хочет купить`, `${t.last.item} за ${t.last.amount} ${t.last.currency}`);
    }
    if (seen !== null && t.v !== seen && document.getElementById("trades-root")?.offsetParent) load();
    seen = t.v;
  });
  registerModule({id: "trades", onShow: load});
})();
