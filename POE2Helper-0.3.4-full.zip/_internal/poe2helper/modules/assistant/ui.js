(function () {
  "use strict";
  const {api, registerModule, assistantPanel} = window.P2;
  const root = document.getElementById("assistant-root");
  const panel = assistantPanel(root, {
    kind: "chat", newUrl: "/api/assistant/new", newTitle: "Новый чат", createLabel: "Начать чат",
    formHtml: `<div class="field"><label>Тема (необязательно)</label><input class="inp" name="title" placeholder="Например: апгрейды для маппинга"></div>
      <div class="field"><label>Мой билд (ассистент будет видеть шмот, камни и цифры PoB)</label><div class="a-src"></div></div>
      <div class="small faint">Ассистент видит базу знаний (вики, моды, гемы, цены, патчи, Reddit), твой live-статус из игры и всё, что ты вставишь: предмет (Ctrl+C), PoB-ссылку, скриншот.</div>`,
    onForm: async f => { await window.P2.sourcePicker(f.querySelector(".a-src"), {none: "— без билда —"}); },
    collect: f => ({title: f.querySelector("[name=title]").value || "Общий чат", ...(window.P2.sourceValue(f.querySelector(".a-src")) || {})}),
    kickoffLabel: "Вопрос",
    kickoff: b => (b.title && b.title !== "Общий чат" ? b.title : null),  // a typed topic is the first question
    chips: ["Что мне улучшить в первую очередь?", "Как поднять урон без потери защиты?", "Что сейчас дорого и выгодно продавать?", "Объясни механику, которую я не понимаю"],
    emptyHtml: "Универсальный ассистент: билд, крафт, трейд, фарм, механики. Создай чат слева.",
  });
  // Ctrl+K → «спросить ассистента»
  window.P2.registerModule({id: "assistant", ask: async text => {
    const s = await api.post("/api/assistant/new", {title: text.slice(0, 50)});
    await panel.open(s.id);
    const ta = root.querySelector(".composer textarea");
    ta.value = text; root.querySelector(".ap-send").click();
  }});
})();
