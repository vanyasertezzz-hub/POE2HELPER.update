(function () {
  "use strict";
  const {api, esc, fmt, md, registerModule, toast, assistantPanel, go} = window.P2;
  const root = document.getElementById("audit-root");
  const SEV = {critical: ["red", "Критично"], warn: ["amber", "Внимание"], info: ["", "Инфо"]};
  const big = n => n >= 1e6 ? (n / 1e6).toFixed(2) + "M" : n >= 1e4 ? (n / 1e3).toFixed(1) + "k" : Math.round(n).toLocaleString("ru");

  root.innerHTML = `
    <div class="card glow"><div class="row" style="align-items:flex-end">
      <div class="field" style="margin:0;flex:1.3;min-width:260px"><label>Какой билд анализировать</label><div id="au-src"></div></div>
      <div class="field" style="margin:0;flex:1;min-width:220px"><label>Цель</label><div id="au-goal"></div></div>
      <button class="btn primary" id="au-run" style="height:40px;padding:0 22px">✦ Проанализировать билд</button></div>
      <div class="small faint" style="margin-top:10px">1) PoB считает билд точно → 2) автопроверки по цифрам → 3) древо, шмот, камни и защиту параллельно разбирают разные модели (Ollama + облачные API) → 4) итоговый план «что и где менять».</div></div>
    <div id="au-out" style="margin-top:16px"></div>
    <div style="margin-top:16px" id="au-hist"></div>`;
  const $ = s => root.querySelector(s);

  async function loadSources() {
    const {choices, selectHtml, wireSelects, sourcePicker} = window.P2;
    const c = await choices(true);
    await sourcePicker($("#au-src"));
    $("#au-goal").innerHTML = selectHtml("goal", c.goals.audit, {custom: true, empty: "— универсально —", placeholder: "своя цель"});
    wireSelects($("#au-goal"));
  }

  function statCards(st) {
    const rows = [["CombinedDPS", "DPS"], ["TotalEHP", "EHP"], ["Life", "Life"], ["EnergyShield", "ES"], ["PhysicalMaximumHitTaken", "Max физ. удар"],
      ["FireResist", "Fire"], ["ColdResist", "Cold"], ["LightningResist", "Lightning"], ["ChaosResist", "Chaos"], ["SpiritUnreserved", "Spirit своб."]];
    return `<div class="grid g4" style="grid-template-columns:repeat(5,minmax(0,1fr))">${rows.filter(([k]) => st[k] != null).map(([k, l]) => {
      const v = st[k], res = /Resist$/.test(k);
      return `<div class="stat"><b class="${res ? (v >= 75 ? "up" : k === "ChaosResist" && v >= 0 ? "" : "down") : ""}" style="font-size:20px">${res ? v.toFixed(0) + "%" : big(v)}</b><span>${l}</span></div>`;
    }).join("")}</div>`;
  }

  async function run() {
    let src = window.P2.sourceValue($("#au-src"));
    if (src && src.need) {  // the character has no build yet: pull it from the account first
      try { await window.P2.loadBuild(src.need); } catch (e) { toast("err", "Анализ билда", e.message); return; }
      await window.P2.sourcePicker($("#au-src"));
      src = window.P2.sourceValue($("#au-src"));
    }
    if (!src || src.need) { toast("info", "Выбери билд или вставь PoB-код"); return; }
    const body = {goal: window.P2.selectValue($("#au-goal"), "goal"), ...src};
    const btn = $("#au-run"); btn.disabled = true; btn.textContent = "Анализирую…";
    window.P2.setBusy("audit", true);
    const out = $("#au-out");
    out.innerHTML = `<div class="card"><div class="row"><span class="spin" style="border-top-color:var(--accent2);width:16px;height:16px;border:2px solid var(--line2);border-radius:50%;animation:spin .7s linear infinite"></span><b id="au-stage">Запуск…</b></div></div>`;
    const sec = {};
    let synth = "";
    const r = await fetch(window.P2.lane("/api/audit/run"), {method: "POST", headers: {"Content-Type": "application/json", "X-P2": "1"}, body: JSON.stringify(body)});
    const rd = r.body.getReader(), dec = new TextDecoder(); let buf = "";
    const stage = t => { const el = out.querySelector("#au-stage"); if (el) el.textContent = t; };
    for (;;) {
      const {value, done} = await rd.read(); if (done) break;
      buf += dec.decode(value, {stream: true});
      let i;
      while ((i = buf.indexOf("\n\n")) >= 0) {
        const line = buf.slice(0, i).trim(); buf = buf.slice(i + 2);
        if (!line.startsWith("data:")) continue;
        const ev = JSON.parse(line.slice(5));
        if (ev.stage === "collect" || (ev.stage === "synth" && ev.text)) stage(ev.text);
        else if (ev.stage === "data") {
          out.insertAdjacentHTML("beforeend", `<div class="card" style="margin-top:12px"><div class="row"><h3 style="margin:0">${esc(ev.ascendancy || ev.class)} · ур. ${ev.level}</h3><span class="tag">${esc(ev.label)}</span><span class="tag">${fmt.n(ev.tree_count, "пассивка|пассивки|пассивок")}</span></div>
            <div style="margin-top:12px">${statCards(ev.stats)}</div></div>`);
        } else if (ev.stage === "checks") {
          out.insertAdjacentHTML("beforeend", `<div class="card" style="margin-top:12px"><h3>Автопроверки по цифрам PoB <span class="muted small">${ev.findings.length}</span></h3>
            ${ev.findings.map(f => `<div class="row" style="padding:4px 0"><span class="tag ${SEV[f.severity][0]}">${SEV[f.severity][1]}</span><span class="tag">${esc(f.area)}</span><span class="small">${esc(f.text)}</span>
              ${f.action ? `<span class="spacer"></span><button class="btn sm" data-p2act="trade" data-spec="${esc(JSON.stringify(f.action))}">🔎 Трейд</button><button class="btn sm ghost" data-p2act="craft" data-spec="${esc(JSON.stringify(f.action))}">⚒ Крафт</button>` : ""}</div>`).join("") || `<div class="small up">Явных проблем не найдено</div>`}</div>`);
        } else if (ev.stage === "pob") {
          const G = {strong: ["node", "сильный — не трогать"], ok: ["info", "нормальный"], weak: ["warn", "слабый — менять первым"]};
          const sl = Object.entries(ev.slots || {}).sort((a, b) => a[1].weight - b[1].weight);
          const tp = ev.tree || {};
          out.insertAdjacentHTML("beforeend", `<div class="grid g2" style="margin-top:12px">
            <div class="card"><div class="sec-h" style="--k:var(--k-item)"><span class="si">🧪</span><div><h3>Сила предметов (PoB)</h3><div class="sd">сколько билд теряет без предмета</div></div></div>
              ${sl.map(([s, v]) => `<div class="kb ${G[v.grade][0]}" style="margin:3px 0"><span class="ki">${v.grade === "strong" ? "✓" : v.grade === "weak" ? "↓" : "•"}</span><div class="kt"><b>${esc(s)}</b> — ${G[v.grade][1]}
                <span class="small muted">(без него DPS ${v.dps >= 0 ? "+" : ""}${v.dps}%, EHP ${v.ehp >= 0 ? "+" : ""}${v.ehp}%)</span></div>
                ${v.grade !== "strong" ? `<button class="btn sm" data-p2act="upgrade" data-spec="${esc(JSON.stringify({slot: s}))}">📈 Апгрейд</button>` : ""}</div>`).join("") || "<div class='muted small'>—</div>"}</div>
            <div class="card"><div class="sec-h" style="--k:var(--k-node)"><span class="si">🌳</span><div><h3>Оптимизатор древа (PoB)</h3><div class="sd">${esc(tp.summary || "")}</div></div>
              <span class="spacer"></span><button class="btn sm" data-go-tree>Показать на древе →</button></div>
              ${(tp.remove || []).filter(x => x.main).map(x => `<div class="kb warn" style="margin:3px 0"><span class="ki">−</span><div class="kt"><b>${esc(x.ru || x.name)}</b> <span class="small muted">${esc(x.why)}</span></div></div>`).join("")}
              ${(tp.add || []).filter(x => x.main).map(x => `<div class="kb node" style="margin:3px 0"><span class="ki">＋</span><div class="kt"><b>${esc(x.ru || x.name)}</b> <span class="small muted">${esc(x.why)}</span></div></div>`).join("")}
              ${(tp.best_free || []).slice(0, 4).map(b => `<div class="small" style="padding:2px 0">◇ ${esc(b.ru)}: DPS ${b.dps >= 0 ? "+" : ""}${b.dps}%, EHP ${b.ehp >= 0 ? "+" : ""}${b.ehp}% за ${b.cost} оч.</div>`).join("")}</div></div>`);
          out.querySelector("[data-go-tree]")?.addEventListener("click", () => window.P2.go("tree"));
        } else if (ev.stage === "deep") {
          out.insertAdjacentHTML("beforeend", window.P2.deepHtml(ev.deep));
        } else if (ev.stage === "sections") {
          stage("Разбираю части билда параллельно…");
          out.insertAdjacentHTML("beforeend", `<div class="grid g2" style="margin-top:12px">${ev.sections.map(s => `<div class="card" id="au-s-${s.id}"><div class="row"><h3 style="margin:0">${esc(s.title)}</h3><span class="spacer"></span><span class="tiny faint au-prov">${esc(s.provider || "")}</span></div><div class="md small au-body" style="margin-top:8px;max-height:420px;overflow:auto"><div class="skel"></div></div></div>`).join("")}</div>
            <div class="card glow" style="margin-top:12px" id="au-final"><div class="row"><h3 style="margin:0">✦ Итог: что и где менять</h3><span class="spacer"></span><span class="tiny faint" id="au-fprov"></span></div><div class="md au-body" style="margin-top:8px"><div class="faint small">появится после разборов…</div></div></div>`);
        } else if (ev.stage === "section") {
          const card = out.querySelector(`#au-s-${ev.id}`); if (!card) continue;
          if (ev.provider) card.querySelector(".au-prov").textContent = ev.provider;
          if (ev.t) { sec[ev.id] = (sec[ev.id] || "") + ev.t; card.querySelector(".au-body").innerHTML = md(sec[ev.id]); }
          if (ev.replace !== undefined) { sec[ev.id] = ev.replace; card.querySelector(".au-body").innerHTML = md(sec[ev.id]); }  // made-up lines taken out
          if (ev.error) card.querySelector(".au-body").innerHTML += `<p style="color:var(--red)">${esc(ev.error)}</p>`;
        } else if (ev.stage === "synth") {
          const f = out.querySelector("#au-final");
          if (ev.provider) out.querySelector("#au-fprov").textContent = ev.provider;
          if (ev.t && f) { synth += ev.t; f.querySelector(".au-body").innerHTML = md(synth); }
          if (ev.replace !== undefined && f) { synth = ev.replace; f.querySelector(".au-body").innerHTML = md(synth); }
        } else if (ev.stage === "progress") {
          const rows = Object.entries(ev.delta).map(([k, v]) => {
            const d = (v.after || 0) - (v.before || 0);
            return `<tr><td>${esc(k)}</td><td class="num">${big(v.before || 0)}</td><td class="num">${big(v.after || 0)}</td><td class="num ${d >= 0 ? "up" : "down"}">${d >= 0 ? "+" : ""}${big(d)}</td></tr>`;
          }).join("");
          out.insertAdjacentHTML("beforeend", `<div class="card" style="margin-top:12px"><h3>Прогресс с прошлого аудита <span class="muted small">${new Date(ev.since * 1000).toLocaleDateString()}</span></h3>
            <table class="tbl"><thead><tr><th>Стат</th><th style="text-align:right">Было</th><th style="text-align:right">Стало</th><th style="text-align:right">Δ</th></tr></thead><tbody>${rows}</tbody></table>
            <div class="tiny faint" style="margin-top:6px">Тула запомнила, какие изменения сработали, — следующие советы это учтут.</div></div>`);
        } else if (ev.stage === "done") {
          stage(`Готово за ${ev.seconds} с`);
          out.querySelector("#au-final")?.insertAdjacentHTML("beforeend", `<div class="row" style="margin-top:12px"><button class="btn primary" id="au-chat">Обсудить и составить план →</button></div>`);
          const b = out.querySelector("#au-chat"); if (b) b.onclick = () => { hist.open(ev.session); $("#au-hist").scrollIntoView({behavior: "smooth"}); };
          hist.reload();
        } else if (ev.stage === "error") {
          stage("Ошибка"); out.insertAdjacentHTML("beforeend", `<div class="card" style="margin-top:12px;color:var(--red)">${esc(ev.error)}</div>`);
        }
      }
    }
    btn.disabled = false; btn.textContent = "✦ Проанализировать билд";
    window.P2.setBusy("audit", false);
  }

  const hist = assistantPanel($("#au-hist"), {
    kickoff: false,
    kind: "audit", newUrl: "/api/assistant/new", newTitle: "История аудитов", createLabel: "—",
    formHtml: `<div class="small muted">Каждый анализ сохраняется: открой его, задай вопросы («почему?», «что купить в первую очередь?») или нажми «Составить план».</div>`,
    collect: () => null,
    chips: ["Что сделать прямо сейчас за минимальные деньги?", "Составь список покупок с модами для трейда", "Какие ноды респекнуть первыми?", "Какие саппорты поменять и почему?"],
    emptyHtml: "Открой анализ из истории — здесь появится его разбор и вопросы к нему.",
  });
  $("#au-hist").querySelector(".ap-create").style.display = "none";
  $("#au-run").onclick = run;
  registerModule({id: "audit", onShow: loadSources});
})();
